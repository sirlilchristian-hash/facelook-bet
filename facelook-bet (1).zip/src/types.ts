export interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  status: "LIVE" | "UPCOMING";
  time: string;
  score: string;
  odds: {
    "1": number;
    X: number;
    "2": number;
  };
  trivia: string;
  flActiveCount: number;
}

export interface BetCard {
  match: string;
  type: string;
  prediction: string;
  odds: number;
  totalPool: number;
  stakes: {
    creator: number;
    opponents: number;
  };
  status: "OPEN" | "MATCHED" | "RESOLVED";
}

export interface Comment {
  author: string;
  content: string;
  time: string;
}

export interface Post {
  id: string;
  author: string;
  avatar: string;
  time: string;
  content: string;
  likes: number;
  comments: Comment[];
  betCard?: BetCard;
  hasLiked?: boolean;
  isGlobalChannel?: boolean;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: "online" | "idle" | "offline";
  mutualFriends: number;
}

export interface Group {
  id: string;
  name: string;
  coverImage: string;
  avatar: string;
  membersCount: number;
  description: string;
  posts: Post[];
  category?: string;
}

export interface LookUptoParams {
  matchId: string;
  matchName: string;
  market: string;
  oddName: string;
  oddsValue: number;
  totalPool: number;
  sendoffsCount: number;
  isSendoffEnabled: boolean;
  calculatedCreatorStake: number;
  calculatedOpponentLiability: number;
}
