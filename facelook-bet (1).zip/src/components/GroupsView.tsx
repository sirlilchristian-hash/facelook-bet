import { useState } from "react";
import { Group, Post } from "../types";
import { 
  Users, 
  ShieldCheck, 
  TrendingUp, 
  MessageSquare, 
  Plus, 
  CheckCircle,
  MoreVertical,
  MoreHorizontal,
  Bell,
  BellOff,
  Share2,
  Heart,
  Trash2,
  X,
  Shield,
  Award,
  Lock,
  Clock,
  AlertTriangle,
  ChevronRight,
  Pen,
  Check,
  Eye,
  Image as ImageIcon,
  Copy,
  Link,
  UserPlus,
  ExternalLink
} from "lucide-react";

interface GroupsViewProps {
  walletBalance: number;
  onUpdateWallet: (amt: number) => void;
  activeGroupId: string;
  setActiveGroupId: (id: string) => void;
  groups: Group[];
  setGroups: (groups: Group[]) => void;
  onNavigateTab: (tab: string) => void;
  setCreateGroupModalOpen?: (open: boolean) => void;
}

export default function GroupsView({ 
  walletBalance, 
  onUpdateWallet,
  activeGroupId,
  setActiveGroupId,
  groups,
  setGroups,
  onNavigateTab,
  setCreateGroupModalOpen
}: GroupsViewProps) {
  const [shrunkJoinedPools, setShrunkJoinedPools] = useState<string[]>([]);
  const [typedComment, setTypedComment] = useState("");
  const [confirmingInvestment, setConfirmingInvestment] = useState<{
    poolId: string;
    cost: number;
    matchName: string;
    time: string;
    league: string;
    odds: { "1": number; X: number; "2": number };
    prediction: string;
  } | null>(null);

  // Advanced States for interactions
  const [selectedPoolBells, setSelectedPoolBells] = useState<Record<string, boolean>>({
    "pool-1": false,
    "pool-2": true,
  });
  const [postBells, setPostBells] = useState<Record<string, boolean>>({});
  const [commentInputMap, setCommentInputMap] = useState<Record<string, string>>({});
  const [activePostMenuId, setActivePostMenuId] = useState<string | null>(null);
  const [coverMenuOpen, setCoverMenuOpen] = useState(false);
  const [showMembersModal, setShowMembersModal] = useState(false);
  const [sharedPostsMap, setSharedPostsMap] = useState<Record<string, boolean>>({});
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  // States for Editing Names & Photos
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempGroupName, setTempGroupName] = useState("");
  const [photoEditTarget, setPhotoEditTarget] = useState<"cover" | "profile" | null>(null);
  const [viewingFullscreenPhoto, setViewingFullscreenPhoto] = useState<string | null>(null);
  const [customPhotoUrl, setCustomPhotoUrl] = useState("");

  // Member lists, copying invitation codes, direct friend actions
  const [membersModalTab, setMembersModalTab] = useState<"members" | "admin">("members");
  const [selectedMemberProfile, setSelectedMemberProfile] = useState<any | null>(null);
  const [inviteInput, setInviteInput] = useState("");
  const [copiedLinkFeedback, setCopiedLinkFeedback] = useState(false);

  // Administrative Role Members
  const [clanMembers, setClanMembers] = useState([
    { name: "Marcus_88", role: "Owner & Lead Admin", avatar: "https://ui-avatars.com/api/?name=Marcus&background=9c27b0&color=fff", status: "Active Now", level: "Lvl 99 Matcher", tag: "Founder", color: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-400/20" },
    { name: "Collins Dnego (You)", role: "Co-Admin / Moderator", avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff", status: "Active Now", level: "Lvl 50 Chief Scout", tag: "Co-Admin", color: "bg-blue-500/10 text-[#1877f2] border-blue-400/20" },
    { name: "crypto_expert", role: "VIP Whale Backer", avatar: "https://ui-avatars.com/api/?name=crypto_expert&background=2196f3&color=fff", status: "Active Today", level: "Lvl 88 Ratio Specialist", tag: "VIP Donor", color: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-400/20" },
    { name: "Dandora King", role: "Pool Escrow Auditor", avatar: "https://ui-avatars.com/api/?name=Dandora+King&background=4caf50&color=fff", status: "Online", level: "Lvl 42 Treasurer", tag: "Treasurer", color: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-400/20" },
    { name: "Leopard Keeper", role: "AFC Leopards Scout", avatar: "https://ui-avatars.com/api/?name=Leopard+Keeper&background=ff9800&color=fff", status: "Offline", level: "Lvl 34 Scout", tag: "Scout / Helper", color: "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-400/20" },
    { name: "K'Ogalo Fanatic", role: "Gor Mahia Advisor", avatar: "https://ui-avatars.com/api/?name=Gor+Mahia&background=e91e63&color=fff", status: "Active Yesterday", level: "Lvl 31 Advisor", tag: "Advisor", color: "bg-pink-500/10 text-pink-600 dark:text-pink-400 border-pink-400/20" },
    { name: "P2P Prophet", role: "Math Ratio Expert", avatar: "https://ui-avatars.com/api/?name=P2P+Prophet&background=607d8b&color=fff", status: "Online", level: "Lvl 75 Guru", tag: "Mathematics", color: "bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-400/20" }
  ]);

  const activeGroup = groups.find((g) => g.id === activeGroupId) || groups[0];

  const triggerToast = (text: string) => {
    setNotificationToast(text);
    setTimeout(() => {
      setNotificationToast(null);
    }, 3000);
  };

  const handleUpdateGroupName = (newName: string) => {
    if (!newName || !newName.trim()) {
      triggerToast("Group name cannot be empty!");
      return;
    }
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return { ...g, name: newName.trim() };
      }
      return g;
    }));
    setIsEditingName(false);
    triggerToast("Group name updated successfully!");
  };

  const handleUpdatePhoto = (type: "cover" | "profile", url: string) => {
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        if (type === "cover") {
          return { ...g, coverImage: url };
        } else {
          return { ...g, avatar: url };
        }
      }
      return g;
    }));
    setPhotoEditTarget(null);
    setCustomPhotoUrl("");
    triggerToast(`${type === "cover" ? "Cover photo" : "Profile photo"} updated successfully!`);
  };

  const handleDeletePhoto = (type: "cover" | "profile") => {
    const defaultCover = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1200";
    const defaultProfile = `https://ui-avatars.com/api/?name=${encodeURIComponent(activeGroup.name)}&background=3b82f6&color=fff`;
    handleUpdatePhoto(type, type === "cover" ? defaultCover : defaultProfile);
    triggerToast(`${type === "cover" ? "Cover" : "Profile"} photo deleted.`);
  };

  const handleDirectInviteFriend = () => {
    if (!inviteInput.trim()) {
      triggerToast("Please enter a valid username or email address!");
      return;
    }
    const username = inviteInput.trim();
    
    // Check if already in the clan list
    if (clanMembers.some(m => m.name.toLowerCase() === username.toLowerCase())) {
      triggerToast(`"${username}" is already in this syndicate!`);
      return;
    }

    const newMember = {
      name: username,
      role: "Member / Scout",
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=e2e8f0&color=2563eb`,
      status: "Active Now",
      level: "Lvl 1 Matcher",
      tag: "Invited",
      color: "bg-blue-500/10 text-[#1877f2] border-blue-400/20"
    };

    setClanMembers([...clanMembers, newMember]);
    
    // Increment the active group membersCount
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return { ...g, membersCount: g.membersCount + 1 };
      }
      return g;
    }));

    triggerToast(`Sent invite request! ${username} successfully joined "${activeGroup.name}"!`);
    setInviteInput("");
  };

  const handlePostInGroup = (text: string) => {
    if (!text.trim()) return;
    const newPost: Post = {
      id: `gp-${Date.now()}`,
      author: "Collins Dnego (You)",
      avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff",
      time: "Just now",
      content: text,
      likes: 0,
      comments: []
    };
    
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return { ...g, posts: [newPost, ...g.posts] };
      }
      return g;
    }));
    triggerToast("Your discussion topic has been published to the feed!");
  };

  const joinSyndicatePool = (poolId: string, poolCost: number) => {
    if (walletBalance < poolCost) {
      alert("Insufficient wallet balance to join syndicate pool. Deposit via Wallet shortcuts first.");
      return;
    }
    onUpdateWallet(-poolCost);
    setShrunkJoinedPools([...shrunkJoinedPools, poolId]);
    
    // Auto turn pool notifications on standard setting
    setSelectedPoolBells(prev => ({ ...prev, [poolId]: true }));
    triggerToast(`💳 Backed successfully! Notification tracking activated automatically.`);
  };

  // Interactions callbacks
  const handleToggleLike = (postId: string) => {
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return {
          ...g,
          posts: g.posts.map(p => {
            if (p.id === postId) {
              const isAlreadyLiked = (p as any).isLikedByMe;
              const nextLikes = isAlreadyLiked ? Math.max(0, p.likes - 1) : p.likes + 1;
              return {
                ...p,
                likes: nextLikes,
                isLikedByMe: !isAlreadyLiked
              };
            }
            return p;
          })
        };
      }
      return g;
    }));
    triggerToast("Upvoted thread sentiment!");
  };

  const handleAddComment = (postId: string) => {
    const text = commentInputMap[postId];
    if (!text || !text.trim()) return;
    
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return {
          ...g,
          posts: g.posts.map(p => {
            if (p.id === postId) {
              return {
                ...p,
                comments: [
                  ...p.comments,
                  {
                    author: "Collins Dnego (You)",
                    content: text.trim(),
                    time: "Just now"
                  }
                ]
              };
            }
            return p;
          })
        };
      }
      return g;
    }));

    setCommentInputMap({
      ...commentInputMap,
      [postId]: ""
    });
    triggerToast("Comment published to thread!");
  };

  const handleSharePost = (postId: string) => {
    setSharedPostsMap({
      ...sharedPostsMap,
      [postId]: true
    });
    triggerToast("🔗 Matched Syndicate post link copied to your clipboard!");
    setTimeout(() => {
      setSharedPostsMap(prev => ({ ...prev, [postId]: false }));
    }, 3000);
  };

  const handleDeletePost = (postId: string) => {
    setGroups(groups.map(g => {
      if (g.id === activeGroupId) {
        return {
          ...g,
          posts: g.posts.filter(p => p.id !== postId)
        };
      }
      return g;
    }));
    setActivePostMenuId(null);
    triggerToast("Post removed from discussion feed.");
  };

  const handleLeaveGroup = () => {
    setCoverMenuOpen(false);
    triggerToast(`🚪 Left '${activeGroup.name}' successfully.`);
  };

  const handleUnfollowGroup = () => {
    setCoverMenuOpen(false);
    triggerToast(`🔕 Stopped notification updates stream from '${activeGroup.name}'.`);
  };

  const handleToggleCoverNotifications = () => {
    setCoverMenuOpen(false);
    triggerToast(`🔔 Alerts for group updates disabled.`);
  };

  const handleReportGroup = () => {
    setCoverMenuOpen(false);
    triggerToast(`⚠️ Support report filed. Syndicate queued for administrative review.`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 px-4 py-3">
        {/* Cover Poster Banner */}
        <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md overflow-hidden border border-gray-200 dark:border-[#3e4042] relative">
          
          {/* Cover Header More-Options dropdown nav */}
          <div className="absolute top-4 right-4 z-20">
            <div className="relative">
              <button
                onClick={() => setCoverMenuOpen(!coverMenuOpen)}
                className="p-2 bg-black/60 hover:bg-black/85 text-white rounded-full transition-all border border-white/10 hover:scale-105 cursor-pointer shadow-md flex items-center justify-center"
                title="Group settings & Administration tools"
              >
                <MoreHorizontal className="w-5 h-5" />
              </button>

              {coverMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-800 rounded-2xl shadow-2xl z-30 overflow-hidden font-sans py-1.5 animate-in fade-in zoom-in-95 duration-100 text-left">
                  <div className="px-3.5 py-1.5 border-b border-gray-100 dark:border-zinc-800/80 mb-1">
                    <p className="text-[10px] uppercase font-mono font-bold text-gray-400 tracking-wider">Clan Operations</p>
                  </div>
                  <button
                    onClick={() => {
                      setShowMembersModal(true);
                      setCoverMenuOpen(false);
                    }}
                    className="w-full px-4 py-2 hover:bg-gray-50 dark:hover:bg-[#323334] text-gray-700 dark:text-gray-200 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>👥</span> Administration & Members
                  </button>
                  <button
                    onClick={handleToggleCoverNotifications}
                    className="w-full px-4 py-2 hover:bg-gray-50 dark:hover:bg-[#323334] text-gray-700 dark:text-gray-200 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>🔔</span> Mute Group Activity
                  </button>
                  <button
                    onClick={handleUnfollowGroup}
                    className="w-full px-4 py-2 hover:bg-gray-50 dark:hover:bg-[#323334] text-gray-700 dark:text-gray-200 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>🔇</span> Unfollow Updates
                  </button>
                  <button
                    onClick={handleLeaveGroup}
                    className="w-full px-4 py-2 hover:bg-red-50 dark:hover:bg-red-955 text-red-600 dark:text-red-400 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>🚪</span> Leave Group
                  </button>
                  
                  <div className="border-t border-gray-100 dark:border-zinc-805 my-1"></div>
                  
                  <button
                    onClick={handleReportGroup}
                    className="w-full px-4 py-2 hover:bg-orange-50 dark:hover:bg-orange-950/20 text-orange-600 dark:text-orange-400 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>⚠️</span> Report Syndicate
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="h-44 w-full relative group/cover">
            <img src={activeGroup.coverImage} className="w-full h-full object-cover" alt="Cover" />
            
            {/* Cover photo edit pen overlay */}
            <button
              onClick={() => setPhotoEditTarget("cover")}
              className="absolute bottom-3 right-3 p-2 bg-black/60 hover:bg-black text-white hover:scale-105 border border-white/20 rounded-full transition-all cursor-pointer shadow-lg flex items-center gap-1.5 text-xs font-bold"
              title="Edit Cover Photo"
            >
              <Pen className="w-3.5 h-3.5 text-amber-400" />
              <span>Edit Cover</span>
            </button>

            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex items-end p-5">
              <div className="flex items-center gap-4 text-white">
                
                {/* Profile photo with edit pen overlay */}
                <div className="relative group/avatar">
                  <img src={activeGroup.avatar} className="w-16 h-16 rounded-xl border-4 border-white/20 shadow-md object-cover" alt={activeGroup.name} />
                  <button
                    onClick={() => setPhotoEditTarget("profile")}
                    className="absolute -bottom-1 -right-1 p-1.5 bg-blue-600 hover:bg-blue-700 hover:scale-110 border-2 border-white dark:border-[#242526] text-white rounded-full transition-all cursor-pointer shadow-md flex items-center justify-center"
                    title="Edit Group Profile Photo"
                  >
                    <Pen className="w-3 h-3 text-white" />
                  </button>
                </div>

                <div>
                  {isEditingName ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={tempGroupName}
                        onChange={(e) => setTempGroupName(e.target.value)}
                        className="bg-black/60 border border-white/30 text-white text-xl font-bold px-2.5 py-1 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent max-w-[240px]"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleUpdateGroupName(tempGroupName);
                          if (e.key === "Escape") setIsEditingName(false);
                        }}
                      />
                      <button
                        onClick={() => handleUpdateGroupName(tempGroupName)}
                        className="p-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg cursor-pointer transition-colors"
                        title="Save name"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setIsEditingName(false)}
                        className="p-1.5 bg-gray-600 hover:bg-gray-700 text-white rounded-lg cursor-pointer transition-colors"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <h1 className="text-2xl font-black tracking-tight">{activeGroup.name}</h1>
                      <button
                        onClick={() => {
                          setTempGroupName(activeGroup.name);
                          setIsEditingName(true);
                        }}
                        className="p-1 hover:bg-white/20 text-white/80 hover:text-white rounded-lg transition-all cursor-pointer"
                        title="Edit group name"
                      >
                        <Pen className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                  <span className="text-xs font-mono bg-blue-500/30 text-blue-300 px-2 py-0.5 rounded border border-blue-400/40 mt-1 inline-block">{activeGroup.category}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 dark:border-[#3e4042] bg-gray-55/40">
            <div className="flex-1">
              <p className="text-sm text-gray-500 dark:text-gray-300 font-medium leading-relaxed">{activeGroup.description}</p>
            </div>
            {/* Clickable members badge linked to the administration page / members modal */}
            <button
              onClick={() => setShowMembersModal(true)}
              className="flex items-center gap-1.5 shrink-0 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-950/70 text-[#1877f2] px-4 py-2.5 rounded-xl text-xs font-black border border-blue-100 dark:border-blue-900/40 transition-all transform hover:scale-[1.02] cursor-pointer"
            >
              <Users className="w-4 h-4" /> 👥 {activeGroup.membersCount.toLocaleString()} Members & Administration
            </button>
          </div>
        </div>

        {/* Dynamic Syndicate Crowdfunded Betting Pools */}
        <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-5 border border-gray-200 dark:border-[#3e4042]">
          <h3 className="text-lg font-black text-gray-800 dark:text-white flex items-center gap-2 mb-1">
            ⚽ Group Syndicate Pools <span className="bg-green-500 text-white text-[10px] uppercase font-mono px-2 py-0.5 rounded-full">ACTIVE MATCHING</span>
          </h3>
          <p className="text-xs text-gray-500 mb-4 leading-relaxed">
            Cooperative pools allow clan partners to bundle stakes together securely. Our look-upto escrow will match liabilities with opposing syndicates automatically once filled.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Pool A */}
            <div className="p-4 bg-gray-50 dark:bg-[#18191a] rounded-xl border border-gray-150 dark:border-zinc-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono font-bold bg-[#1877f2]/10 text-[#1877f2] dark:text-blue-400 px-2.5 py-1 rounded">MATCH: MAN CITY VS ARSENAL</span>
                  <span className="text-xs text-red-500 font-medium font-mono">1 spot left</span>
                </div>
                <h4 className="font-extrabold text-sm text-gray-800 dark:text-gray-200 mb-1">Syndicate Combo Odds Prediction</h4>
                <p className="text-xs text-gray-500 mb-3 font-mono">Prediction: Man City Home Win (@2.65)</p>
                <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full overflow-hidden mb-3">
                  <div className="bg-green-500 h-full w-[80%] transition-all" />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="block text-[10px] text-gray-400 font-bold uppercase">COMMUNITY CONTRIBS</span>
                  <span className="font-black text-sm text-gray-700 dark:text-gray-300">$80 / $100</span>
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Syndicate Bet Tracker Bell */}
                  <button
                    onClick={() => {
                      const isBellOn = !!selectedPoolBells["pool-1"];
                      setSelectedPoolBells({
                        ...selectedPoolBells,
                        "pool-1": !isBellOn
                      });
                      triggerToast(
                        !isBellOn 
                          ? "🔔 Bet Tracker Activated: You will be notified instantly when Man City vs Arsenal bet matches and gets settled by escrow." 
                          : "🔕 Stopped tracking Man City vs Arsenal match status."
                      );
                    }}
                    className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center justify-center ${
                      selectedPoolBells["pool-1"]
                        ? "bg-amber-100 hover:bg-amber-150 border-amber-300 dark:bg-amber-955 dark:border-amber-900 text-amber-600 dark:text-amber-400"
                        : "bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 border-zinc-200 dark:border-zinc-800 text-gray-400 hover:text-gray-650 dark:hover:text-gray-300"
                    }`}
                    title={selectedPoolBells["pool-1"] ? "Notifications active" : "Enable settlement alerts"}
                  >
                    <Bell className={`w-3.5 h-3.5 ${selectedPoolBells["pool-1"] ? "fill-amber-500 text-amber-500 font-bold animate-bounce" : ""}`} />
                  </button>

                  {shrunkJoinedPools.includes("pool-1") ? (
                    <span className="py-1.5 px-3 bg-emerald-600 text-white text-[11px] font-bold rounded-lg flex items-center gap-1 shadow-sm">
                      <CheckCircle className="w-3.5 h-3.5" /> Backed Spot!
                    </span>
                  ) : (
                    <button
                      onClick={() => setConfirmingInvestment({
                        poolId: "pool-1",
                        cost: 20,
                        matchName: "Man City vs Arsenal",
                        time: "Today, 18:30 UTC",
                        league: "English Premier League",
                        odds: { "1": 2.10, X: 3.40, "2": 3.20 },
                        prediction: "Man City Home Win (@2.65)"
                      })}
                      className="py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-sm cursor-pointer"
                    >
                      Invest $20
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Pool B */}
            <div className="p-4 bg-gray-50 dark:bg-[#18191a] rounded-xl border border-gray-150 dark:border-zinc-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono font-bold bg-[#1877f2]/10 text-[#1877f2] dark:text-blue-400 px-2.5 py-1 rounded">MATCH: MASHEMEJI DERBY LIVE</span>
                  <span className="text-xs text-emerald-500 font-bold font-mono">OPEN SHIELDS</span>
                </div>
                <h4 className="font-extrabold text-sm text-gray-800 dark:text-gray-200 mb-1">Local Ligi Bigi Massive Pool</h4>
                <p className="text-xs text-gray-500 mb-3 font-mono">Prediction: Draw Match (@2.80)</p>
                <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full overflow-hidden mb-3">
                  <div className="bg-green-500 h-full w-[40%] transition-all" />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="block text-[10px] text-gray-400 font-bold uppercase">COMMUNITY CONTRIBS</span>
                  <span className="font-black text-sm text-gray-700 dark:text-gray-300">$200 / $500</span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Syndicate Bet Tracker Bell */}
                  <button
                    onClick={() => {
                      const isBellOn = !!selectedPoolBells["pool-2"];
                      setSelectedPoolBells({
                        ...selectedPoolBells,
                        "pool-2": !isBellOn
                      });
                      triggerToast(
                        !isBellOn 
                          ? "🔔 Bet Tracker Activated: You will be notified instantly when AFC Leopards v Gor Mahia matches/settles." 
                          : "🔕 Stopped tracking local derby match statuses."
                      );
                    }}
                    className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center justify-center ${
                      selectedPoolBells["pool-2"]
                        ? "bg-amber-100 hover:bg-amber-150 border-amber-300 dark:bg-amber-955 dark:border-amber-900 text-amber-600 dark:text-amber-400"
                        : "bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 border-zinc-200 dark:border-zinc-800 text-gray-400 hover:text-gray-650 dark:hover:text-gray-300"
                    }`}
                    title={selectedPoolBells["pool-2"] ? "Notifications active" : "Enable settlement alerts"}
                  >
                    <Bell className={`w-3.5 h-3.5 ${selectedPoolBells["pool-2"] ? "fill-amber-500 text-amber-500 font-bold animate-bounce" : ""}`} />
                  </button>

                  {shrunkJoinedPools.includes("pool-2") ? (
                    <span className="py-1.5 px-3 bg-emerald-600 text-white text-[11px] font-bold rounded-lg flex items-center gap-1 shadow-sm">
                      <CheckCircle className="w-3.5 h-3.5" /> Backed Spot!
                    </span>
                  ) : (
                    <button
                      onClick={() => setConfirmingInvestment({
                        poolId: "pool-2",
                        cost: 50,
                        matchName: "Gor Mahia vs AFC Leopards (Mashemeji Derby)",
                        time: "Today, 15:00 UTC",
                        league: "Kenya Ligi Bigi",
                        odds: { "1": 2.50, X: 2.80, "2": 3.10 },
                        prediction: "Draw Match (@2.80)"
                      })}
                      className="py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-sm cursor-pointer"
                    >
                      Invest $50
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Group Post Composer */}
        <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-4 border border-gray-200 dark:border-[#3e4042]">
          <div className="flex gap-3 mb-3">
            <img src="https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff" className="w-10 h-10 rounded-full" alt="User Avatar" />
            <input
              type="text"
              value={typedComment}
              onChange={(e) => setTypedComment(e.target.value)}
              placeholder={`Write something to this group, Collins...`}
              className="flex-1 bg-gray-100 dark:bg-[#323334] rounded-full px-4 text-sm text-gray-800 dark:text-gray-100 placeholder-gray-400 outline-none border-none focus:ring-1 focus:ring-blue-500"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handlePostInGroup(typedComment);
                  setTypedComment("");
                }
              }}
            />
          </div>
          <div className="flex justify-between items-center pt-2.5 border-t border-gray-100 dark:border-[#3e4042]">
            <span className="text-xs text-gray-400 font-mono">Hit Enter to publish to clan wall</span>
            <button
              onClick={() => {
                handlePostInGroup(typedComment);
                setTypedComment("");
              }}
              className="py-1.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-md transition-colors"
            >
              Post
            </button>
          </div>
        </div>

        {/* Group Posts feed */}
        <div className="space-y-4">
          {activeGroup.posts.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-[#242526] rounded-xl shadow-sm text-gray-500 text-sm">
              No general discussions yet. Be the first to post advice or ratio bets to that clan wall!
            </div>
          ) : (
            activeGroup.posts.map((post) => (
              <div key={post.id} className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-5 border border-gray-200 dark:border-[#3e4042] relative">
                
                {/* 3-Dots Post Navigation with active bells and delete options */}
                <div className="absolute top-5 right-5 z-10">
                  <div className="relative">
                    <button
                      onClick={() => setActivePostMenuId(activePostMenuId === post.id ? null : post.id)}
                      className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-[#323334] rounded-full transition-all cursor-pointer"
                      title="Post configuration options"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activePostMenuId === post.id && (
                      <div className="absolute right-0 mt-1 w-48 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-800 rounded-xl shadow-xl z-30 overflow-hidden text-left py-1 font-sans animate-in fade-in zoom-in-95 duration-75">
                        
                        {post.author.includes("(You)") ? (
                          <div className="px-3 py-1 bg-blue-50 dark:bg-blue-950/25 text-[#1877f2] font-mono text-[9px] font-black uppercase tracking-wider border-b border-gray-100 dark:border-zinc-800/60">
                            ★ Your Post
                          </div>
                        ) : (
                          <div className="px-3 py-1 bg-gray-50 dark:bg-[#18191a]/40 text-gray-400 font-mono text-[9px] font-black uppercase tracking-wider border-b border-gray-100 dark:border-zinc-800/60">
                            From: {post.author.replace(/ \((You)\)/, '')}
                          </div>
                        )}

                        <button
                          onClick={() => {
                            const isBellOn = !!postBells[post.id];
                            setPostBells({
                              ...postBells,
                              [post.id]: !isBellOn
                            });
                            setActivePostMenuId(null);
                            triggerToast(
                              !isBellOn 
                                ? "🔔 Turn on notification: Enabled alerts for new comments under this thread." 
                                : "🔕 Muted thread comments notifications."
                            );
                          }}
                          className="w-full px-3 py-1.5 hover:bg-gray-50 dark:hover:bg-[#323334] text-gray-700 dark:text-gray-200 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
                        >
                          {postBells[post.id] ? "🔕 Turn Off Alerts" : "🔔 Turn On Alerts"}
                        </button>

                        <button
                          onClick={() => handleDeletePost(post.id)}
                          className="w-full px-3 py-1.5 hover:bg-red-50 dark:hover:bg-red-950/25 text-red-650 dark:text-red-400 text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors border-t border-gray-100 dark:border-zinc-804/60"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-500" /> 
                          <span>{post.author.includes("(You)") ? "Delete Post (Owner)" : "Remove Post (Admin)"}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-3.5">
                  <img src={post.avatar} className="w-10 h-10 rounded-full" alt="Avatar" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-extrabold text-[#050505] dark:text-[#e4e6eb] text-sm leading-none">{post.author}</h4>
                      {postBells[post.id] && (
                        <span className="p-0.5 bg-amber-500/10 text-amber-500 rounded" title="Thread notifications enabled">
                          <Bell className="w-3 h-3 fill-amber-500 text-amber-500" />
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] font-mono text-gray-400">{post.time}</span>
                  </div>
                </div>

                <p className="text-sm text-gray-850 dark:text-gray-200 leading-relaxed mb-4">{post.content}</p>

                {/* Interactions Row Counter */}
                <div className="flex items-center gap-4 pt-3 text-xs text-gray-400 font-mono border-t border-gray-100/60 dark:border-zinc-800/40">
                  <span>👍 {post.likes} Likes</span>
                  <span>💬 {post.comments.length} Comments</span>
                </div>

                {/* Interactive Engagement Row */}
                <div className="flex items-center justify-between border-t border-b border-gray-100 dark:border-[#3e4042] py-2 my-2.5 text-xs font-sans">
                  <button
                    onClick={() => handleToggleLike(post.id)}
                    className={`flex items-center justify-center gap-1.5 flex-1 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800/80 transition-colors font-bold cursor-pointer ${
                      (post as any).isLikedByMe ? "text-[#1877f2]" : "text-gray-500 dark:text-gray-400"
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${ (post as any).isLikedByMe ? "fill-red-500 text-red-500 stroke-red-500" : ""}`} />
                    <span>{(post as any).isLikedByMe ? "Liked!" : "Like"}</span>
                  </button>

                  <button
                    onClick={() => {
                      const inputElement = document.getElementById(`comment-input-${post.id}`);
                      inputElement?.focus();
                    }}
                    className="flex items-center justify-center gap-1.5 flex-1 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800/80 text-gray-500 dark:text-gray-400 transition-colors font-bold cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Comment</span>
                  </button>

                  <button
                    onClick={() => handleSharePost(post.id)}
                    className={`flex items-center justify-center gap-1.5 flex-1 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800/80 transition-colors font-bold cursor-pointer ${
                      sharedPostsMap[post.id] ? "text-emerald-600 dark:text-emerald-400" : "text-gray-500 dark:text-gray-400"
                    }`}
                  >
                    <Share2 className="w-4 h-4" />
                    <span>{sharedPostsMap[post.id] ? "Shared!" : "Share"}</span>
                  </button>
                </div>

                {/* Direct Comment Lists */}
                {post.comments.length > 0 && (
                  <div className="mt-4 space-y-3 bg-gray-50 dark:bg-[#18191a] p-3.5 rounded-xl border border-gray-100 dark:border-zinc-800">
                    {post.comments.map((comment, cIdx) => (
                      <div key={cIdx} className="text-xs text-left">
                        <span className="font-extrabold text-gray-750 dark:text-gray-200 mr-1.5">{comment.author}</span>
                        <span className="text-gray-600 dark:text-gray-300 leading-relaxed">{comment.content}</span>
                        <span className="block text-[10px] text-gray-400 mt-0.5">{comment.time}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Direct Reply Composer */}
                <div className="mt-3.5 flex gap-2 pt-2 border-t border-gray-100/40 dark:border-zinc-800/40">
                  <input
                    id={`comment-input-${post.id}`}
                    type="text"
                    value={commentInputMap[post.id] || ""}
                    onChange={(e) => setCommentInputMap({
                      ...commentInputMap,
                      [post.id]: e.target.value
                    })}
                    placeholder="Write a peer response..."
                    className="flex-1 bg-gray-50 dark:bg-[#18191a] text-xs font-sans rounded-xl px-3 py-2 border border-gray-200 dark:border-[#3e4042] text-gray-800 dark:text-gray-100 placeholder-gray-400 outline-none focus:ring-1 focus:ring-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleAddComment(post.id);
                      }
                    }}
                  />
                  <button
                    onClick={() => handleAddComment(post.id)}
                    className="py-1.5 px-3.5 bg-[#1877f2] hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0"
                  >
                    Reply
                  </button>
                </div>

              </div>
            ))
          )}
        </div>

      {/* ADMINISTRATION & MEMBERS OVERLAY MODAL */}
      {showMembersModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[120] p-4 font-sans animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-800 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-100 dark:border-zinc-850 flex items-center justify-between bg-gray-55 dark:bg-[#1c1d1e]">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-500/10 text-[#1877f2] rounded-xl">
                  <Users className="w-5 h-5 text-[#1877f2]" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-gray-900 dark:text-white leading-tight">
                    Syndicate Directory Workspace
                  </h3>
                  <p className="text-xs text-gray-400">{activeGroup.name}</p>
                </div>
              </div>
              <button 
                onClick={() => setShowMembersModal(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-150 dark:hover:bg-[#323334] rounded-full transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* TAB SELECTORS */}
            <div className="flex border-b border-gray-150 dark:border-zinc-800 px-4 bg-gray-50/70 dark:bg-[#1a1b1c]">
              <button
                onClick={() => setMembersModalTab("members")}
                className={`flex-1 py-3 text-xs font-black transition-all border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                  membersModalTab === "members" ? "border-[#1877f2] text-[#1877f2]" : "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Members Directory ({clanMembers.length})</span>
              </button>
              
              <button
                onClick={() => setMembersModalTab("admin")}
                className={`flex-1 py-3 text-xs font-black transition-all border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                  membersModalTab === "admin" ? "border-[#1877f2] text-[#1877f2]" : "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Administration & Controls</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-left">
              
              {membersModalTab === "members" ? (
                // TAB 1: MEMBERS DIRECTORY VIEW WITH INVITE SHORTCUTS
                <div className="space-y-4 font-sans">
                  
                  {/* Invite Friends Shortcut Box */}
                  <div className="p-4 bg-blue-500/5 dark:bg-blue-500/10 border border-blue-500/10 dark:border-blue-400/10 rounded-2xl space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-[#1877f2]/10 text-[#1877f2] dark:text-blue-400 rounded-xl">
                        <UserPlus className="w-4 h-4 shrink-0" />
                      </div>
                      <div className="leading-tight">
                        <h4 className="text-xs font-black text-gray-900 dark:text-white uppercase tracking-wider">Invite Friends & Partners</h4>
                        <p className="text-[10px] text-gray-400">Share connection link to secure collective liability backing</p>
                      </div>
                    </div>

                    {/* Copy Link Row */}
                    <div className="flex gap-2">
                      <div className="flex-1 flex bg-white dark:bg-[#18191a] border border-gray-200 dark:border-zinc-800 rounded-xl px-3 py-2 items-center gap-2 overflow-hidden">
                        <Link className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <input 
                          type="text" 
                          readOnly 
                          value={`https://lookupto.bet/invite/g/${activeGroup.id}`}
                          className="bg-transparent border-none text-[10px] font-mono text-gray-500 dark:text-gray-300 outline-none w-full select-all leading-normal"
                        />
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(`https://lookupto.bet/invite/g/${activeGroup.id}`);
                          setCopiedLinkFeedback(true);
                          triggerToast("Syndicate invitation link copied to clipboard!");
                          setTimeout(() => setCopiedLinkFeedback(false), 2000);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-[10.5px] font-black transition-all flex items-center gap-1 cursor-pointer shrink-0 border border-transparent shadow-xs ${
                          copiedLinkFeedback 
                            ? "bg-emerald-600 hover:bg-emerald-700 text-white" 
                            : "bg-[#1877f2] hover:bg-blue-600 text-white"
                        }`}
                      >
                        {copiedLinkFeedback ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLinkFeedback ? "Copied" : "Copy Link"}</span>
                      </button>
                    </div>

                    {/* Direct Search Input Invite */}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter partner name (e.g., keller_99, sarah_t)..."
                        value={inviteInput}
                        onChange={(e) => setInviteInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            handleDirectInviteFriend();
                          }
                        }}
                        className="flex-1 bg-white dark:bg-[#18191a] text-xs rounded-xl px-3 py-2 border border-gray-205 dark:border-zinc-800 text-gray-800 dark:text-gray-100 placeholder-gray-400 outline-none focus:ring-1 focus:ring-[#1877f2]"
                      />
                      <button
                        onClick={handleDirectInviteFriend}
                        disabled={!inviteInput.trim()}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          inviteInput.trim() 
                            ? "bg-[#1877f2] hover:bg-blue-600 text-white shadow" 
                            : "bg-gray-100 dark:bg-zinc-800 text-gray-450 dark:text-zinc-600 cursor-not-allowed"
                        }`}
                      >
                        Direct Add
                      </button>
                    </div>

                  </div>

                  {/* Members Grid list */}
                  <div className="space-y-2">
                    <p className="text-[10px] font-mono font-black uppercase text-gray-405 tracking-wider mb-2">👥 Click member card to view live profile page portal:</p>
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {clanMembers.map((m, idx) => (
                        <div 
                          key={idx}
                          onClick={() => setSelectedMemberProfile({
                            ...m,
                            winRate: idx === 0 ? "82.4%" : idx === 1 ? "91.8%" : idx === 2 ? "74.2%" : "68.6%",
                            matchedVolume: idx === 0 ? "$2,350" : idx === 1 ? "$5,000" : idx === 2 ? "$1,200" : "$420",
                            reputation: idx === 0 ? "+495 Rep" : idx === 1 ? "+950 Elite" : idx === 2 ? "+210 Peer" : "+50 Buddy"
                          })}
                          className="p-3 bg-gray-50 dark:bg-[#18191a] border border-gray-150 dark:border-zinc-800/80 rounded-2xl flex items-center justify-between hover:border-[#1877f2]/50 hover:bg-[#1877f2]/5 dark:hover:bg-[#1877f2]/10 transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <img src={m.avatar} className="w-10 h-10 rounded-full border-2 border-white dark:border-zinc-800 shadow" alt={m.name} />
                              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white dark:border-[#18191a]" />
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-xs font-black text-gray-950 dark:text-gray-100 group-hover:text-[#1877f2] transition-colors">{m.name}</span>
                                <span className={`text-[8.5px] px-1.5 py-0.5 rounded-md border font-mono font-black lowercase tracking-tight ${m.color}`}>
                                  {m.tag}
                                </span>
                              </div>
                              <p className="text-[10px] text-gray-400 font-medium font-sans">{m.role}</p>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="block text-[10px] font-mono text-[#1877f2] font-extrabold bg-[#1877f2]/10 px-2 py-0.5 rounded-md">
                              {m.level}
                            </span>
                            <span className="text-[9px] text-[#1877f2] font-black hover:underline mt-1 block">View Profile →</span>
                          </div>

                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              ) : (
                // TAB 2: ORIGINAL TRUSTWORTHY ESCROW ADMINISTRATION CONTROLS
                <div className="space-y-4">
                  {/* Clan Statistics bar */}
                  <div className="grid grid-cols-3 gap-2.5 p-3 bg-blue-50/40 dark:bg-[#18191a] rounded-2xl border border-blue-100/30 dark:border-zinc-800">
                    <div className="text-center">
                      <span className="block text-[9px] font-mono text-gray-400 uppercase font-black">Members Count</span>
                      <strong className="text-sm text-[#1877f2] font-black">{activeGroup.membersCount.toLocaleString()}</strong>
                    </div>
                    <div className="text-center border-l border-gray-200 dark:border-zinc-800">
                      <span className="block text-[9px] font-mono text-gray-400 uppercase font-black">Matched Capital</span>
                      <strong className="text-sm text-green-500 font-black">$4,850+</strong>
                    </div>
                    <div className="text-center border-l border-gray-200 dark:border-zinc-800">
                      <span className="block text-[9px] font-mono text-gray-400 uppercase font-black">Match Success Ratio</span>
                      <strong className="text-sm text-amber-500 font-black">98.4%</strong>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-purple-500" /> Active Roles & Administration Staff ({clanMembers.length})
                    </h4>

                    <div className="space-y-2.5">
                      {clanMembers.map((m, idx) => (
                        <div key={idx} className="p-3 bg-gray-50 dark:bg-[#18191a] border border-gray-150 dark:border-zinc-800/80 rounded-2xl flex items-center justify-between hover:border-gray-350 dark:hover:border-zinc-700 transition-all">
                          <div className="flex items-center gap-3">
                            <img src={m.avatar} className="w-10 h-10 rounded-full border-2 border-white dark:border-zinc-800 shadow" alt={m.name} />
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-xs font-extrabold text-gray-950 dark:text-gray-100">{m.name}</span>
                                <span className={`text-[9px] px-2 py-0.5 rounded-full border font-mono font-bold lowercase tracking-tight ${m.color}`}>
                                  {m.tag}
                                </span>
                              </div>
                              <p className="text-[11px] text-gray-400 font-sans">{m.role} • <span className="text-emerald-500">{m.status}</span></p>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="block text-[10px] font-mono text-[#1877f2] font-semibold bg-[#1877f2]/10 px-2 py-0.5 rounded-md">
                              {m.level}
                            </span>
                            
                            {/* Simulated action button */}
                            {m.name !== "Collins Dnego (You)" && (
                              <button 
                                onClick={() => triggerToast(`Role authority management request sent to ${m.name}`)}
                                className="text-[9px] font-mono font-bold text-gray-400 hover:text-[#1877f2] mt-1 hover:underline cursor-pointer"
                              >
                                Propose Swap
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Clan Security escrow protocol warning box */}
                  <div className="p-3.5 bg-amber-50 dark:bg-amber-950/20 border border-amber-250/20 dark:border-amber-900/40 rounded-2xl text-amber-800 dark:text-amber-300 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold uppercase font-mono">
                      <Shield className="w-3.5 h-3.5" /> Clan Security Measures
                    </div>
                    <p className="text-[11px] leading-relaxed opacity-95">
                      Syndicates are secure local vaults controlled by multivariable smart contract codes. Only registered Admins shown above can initiate match combinations or authorize look-upto peer trades.
                    </p>
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-gray-50 dark:bg-[#1c1d1e] border-t border-gray-100 dark:border-zinc-800 flex justify-end gap-3.5">
              <button
                onClick={() => setShowMembersModal(false)}
                className="px-4 py-2 bg-gray-250 hover:bg-gray-300 dark:bg-zinc-800 dark:hover:bg-[#323334] text-gray-800 dark:text-gray-200 text-xs font-extrabold rounded-xl transition-all cursor-pointer"
              >
                Close View
              </button>
              {membersModalTab === "admin" && (
                <button
                  onClick={() => {
                    triggerToast("Drafting proposal for group adjustments...");
                    setShowMembersModal(false);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl transition-all cursor-pointer shadow"
                >
                  Propose Role Change
                </button>
              )}
            </div>

          </div>
        </div>
      )}

      {/* FLOATING INTERACTIVE MEMBER PROFILE CARD LIGHTBOX */}
      {selectedMemberProfile && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center z-[140] p-4 font-sans animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-800 rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col relative animate-in zoom-in-95 duration-100">
            
            {/* Background design cover */}
            <div className="h-24 bg-gradient-to-r from-blue-600 to-indigo-700 relative flex items-end justify-between px-5 pb-3">
              <span className="text-[9px] text-white/70 font-mono tracking-widest uppercase">SYNDICATE CITIZENCARD</span>
              <button 
                onClick={() => setSelectedMemberProfile(null)}
                className="absolute top-3 right-3 p-1.5 bg-black/20 hover:bg-black/40 text-white rounded-full transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            {/* Avatar container */}
            <div className="px-5 -mt-10 relative flex justify-between items-end">
              <img 
                src={selectedMemberProfile.avatar} 
                className="w-20 h-20 rounded-full border-4 border-white dark:border-[#242526] bg-[#242526] shadow-lg object-cover" 
                alt="Avatar" 
              />
              <span className="text-[10px] bg-emerald-500/10 text-emerald-500 font-mono border border-emerald-400/20 px-2 py-0.5 rounded-full font-bold mb-1">
                ONLINE NOW
              </span>
            </div>

            {/* Profile fields */}
            <div className="p-5 text-left space-y-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-lg text-gray-950 dark:text-white leading-none">{selectedMemberProfile.name}</h3>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full border font-mono font-bold lowercase tracking-tight ${selectedMemberProfile.color}`}>
                    {selectedMemberProfile.tag}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-1">{selectedMemberProfile.role} • {selectedMemberProfile.level}</p>
              </div>

              {/* Statistics Grid */}
              <div className="grid grid-cols-3 gap-2 bg-gray-50 dark:bg-[#1c1d1e] border border-gray-150 dark:border-zinc-800/85 p-3 rounded-2xl text-center">
                <div>
                  <span className="block text-[8px] font-mono text-gray-400 uppercase">Win Ratio</span>
                  <strong className="text-sm text-green-500 font-black">{selectedMemberProfile.winRate}</strong>
                </div>
                <div className="border-l border-gray-200 dark:border-zinc-800">
                  <span className="block text-[8px] font-mono text-gray-400 uppercase">Volume</span>
                  <strong className="text-sm text-blue-500 font-black">{selectedMemberProfile.matchedVolume}</strong>
                </div>
                <div className="border-l border-gray-200 dark:border-zinc-800">
                  <span className="block text-[8px] font-mono text-gray-400 uppercase">Reputation</span>
                  <strong className="text-sm text-amber-500 font-black">{selectedMemberProfile.reputation}</strong>
                </div>
              </div>

              {/* Profile Details body */}
              <div className="space-y-1.5 text-xs text-gray-500 dark:text-gray-300 bg-gray-50 dark:bg-[#1c1d1e] p-3 rounded-2xl border border-gray-100 dark:border-zinc-800/50">
                <p className="font-extrabold text-gray-900 dark:text-gray-150 mb-1">LookUpto Syndicate Ledger</p>
                <div className="flex justify-between">
                  <span>Registered:</span> <span className="font-mono text-gray-700 dark:text-gray-300 font-bold">2026 Season</span>
                </div>
                <div className="flex justify-between">
                  <span>Matched Slips:</span> <span className="font-mono text-gray-700 dark:text-gray-300 font-bold">142 matched trades</span>
                </div>
                <div className="flex justify-between">
                  <span>Prefers:</span> <span className="font-mono text-gray-700 dark:text-gray-300 font-bold font-medium">Asian Handicap odds</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    triggerToast(`Challenging "${selectedMemberProfile.name}" to lookupto 1v1 duel...`);
                    setSelectedMemberProfile(null);
                  }}
                  className="flex-1 py-2.5 bg-[#1877f2] hover:bg-blue-600 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow text-center uppercase tracking-wide"
                >
                  ⚔️ challenge 1v1
                </button>
                <button
                  onClick={() => {
                    triggerToast(`Tip jar connected! Gas fee estimation loaded successfully.`);
                    setSelectedMemberProfile(null);
                  }}
                  className="py-2.5 px-3.5 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-750 dark:text-gray-200 font-black text-xs rounded-xl transition-all cursor-pointer"
                  title="Send tip"
                >
                  💰 Tip
                </button>
              </div>
            </div>

            <div className="p-3 bg-gray-50 dark:bg-[#1c1d1e] border-t border-gray-100 dark:border-zinc-800 text-center">
              <button 
                onClick={() => setSelectedMemberProfile(null)}
                className="text-[10px] text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 font-bold uppercase transition-all cursor-pointer"
              >
                Close Profile
              </button>
            </div>

          </div>
        </div>
      )}

      {/* PHOTO EDIT OPTIONS MODAL */}
      {photoEditTarget && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[130] p-4 font-sans animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#242526] border border-gray-200 dark:border-[#3e4042] rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
            
            <div className="p-5 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-gray-50 dark:bg-[#1a1b1c]">
              <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-blue-500" />
                <span>Manage {photoEditTarget === "cover" ? "Cover" : "Profile"} Photo</span>
              </h3>
              <button 
                onClick={() => {
                  setPhotoEditTarget(null);
                  setCustomPhotoUrl("");
                }}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-150 dark:hover:bg-zinc-800 rounded-full transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-left">
              
              {/* Option 1: View Photo */}
              <button
                onClick={() => {
                  setViewingFullscreenPhoto(photoEditTarget === "cover" ? activeGroup.coverImage : activeGroup.avatar);
                  setPhotoEditTarget(null);
                }}
                className="w-full p-3.5 bg-gray-50 hover:bg-gray-100 dark:bg-[#18191a] dark:hover:bg-zinc-805 border border-gray-200 dark:border-zinc-800 rounded-2xl flex items-center gap-3 transition-all cursor-pointer"
              >
                <div className="p-2.5 bg-blue-500/10 text-blue-650 dark:text-blue-400 rounded-xl">
                  <Eye className="w-4 h-4" />
                </div>
                <div className="text-left leading-tight">
                  <strong className="block text-xs font-bold text-gray-900 dark:text-white">View Current Photo</strong>
                  <span className="text-[10px] text-gray-400">Open full size preview lightbox</span>
                </div>
              </button>

              {/* Option 2: Predefined Presets & Custom URL Change */}
              <div className="p-4 bg-gray-50 dark:bg-[#18191a] border border-gray-200 dark:border-zinc-805 rounded-2xl space-y-3">
                <div>
                  <strong className="block text-xs font-bold text-gray-800 dark:text-gray-200 mb-1">
                    Change Photo URL
                  </strong>
                  <span className="text-[10px] text-gray-400">Paste any public web image address to update immediately:</span>
                </div>

                <div className="flex gap-2">
                  <input
                    type="url"
                    value={customPhotoUrl}
                    onChange={(e) => setCustomPhotoUrl(e.target.value)}
                    placeholder="https://example.com/sport-image.jpg"
                    className="flex-1 bg-white dark:bg-[#242526] text-xs font-sans rounded-xl px-3 py-2 border border-gray-200 dark:border-zinc-700 text-gray-850 dark:text-gray-100 placeholder-gray-450 outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <button
                    onClick={() => {
                      if (!customPhotoUrl.trim()) {
                        triggerToast("Please supply a valid image URL first!");
                        return;
                      }
                      handleUpdatePhoto(photoEditTarget, customPhotoUrl.trim());
                    }}
                    className="py-1.5 px-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Apply
                  </button>
                </div>

                {/* Preconfigured Fast Preset Recommendations */}
                <div>
                  <span className="block text-[9px] font-mono font-bold text-gray-450 uppercase mb-2">Cool Sport Presets:</span>
                  <div className="grid grid-cols-4 gap-2">
                    {photoEditTarget === "cover" ? (
                      <>
                        <button
                          onClick={() => handleUpdatePhoto("cover", "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=600")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Football Stadium"
                        >
                          <img src="https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=200" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("cover", "https://images.unsplash.com/photo-1540747737956-37872404a82f?q=80&w=600")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Arena Lights"
                        >
                          <img src="https://images.unsplash.com/photo-1540747737956-37872404a82f?q=80&w=200" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("cover", "https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=600")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Green Field"
                        >
                          <img src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=200" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("cover", "https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="VIP Glow Pattern"
                        >
                          <img src="https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=200" className="w-full h-full object-cover" />
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => handleUpdatePhoto("profile", "https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=150")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Athlete Crest"
                        >
                          <img src="https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=100" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("profile", "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=150")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Athletic Spark"
                        >
                          <img src="https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=100" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("profile", "https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=150")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-250 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Lion Shield"
                        >
                          <img src="https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=100" className="w-full h-full object-cover" />
                        </button>
                        <button
                          onClick={() => handleUpdatePhoto("profile", "https://images.unsplash.com/photo-1484406566174-9da000fda645?q=80&w=150")}
                          className="h-10 rounded-lg overflow-hidden border border-gray-200 dark:border-zinc-700 cursor-pointer hover:opacity-85 transition-opacity"
                          title="Deer Stag"
                        >
                          <img src="https://images.unsplash.com/photo-1484406566174-9da000fda645?q=80&w=100" className="w-full h-full object-cover" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

              </div>

              {/* Option 3: Delete Current Photo */}
              <button
                onClick={() => handleDeletePhoto(photoEditTarget)}
                className="w-full p-3 bg-red-50 hover:bg-red-100 dark:bg-red-950/10 dark:hover:bg-red-950/30 border border-red-100 dark:border-red-905 rounded-2xl flex items-center gap-3 transition-all cursor-pointer text-red-650 dark:text-red-400 group"
              >
                <div className="p-2 bg-red-105 dark:bg-red-900/30 text-red-650 dark:text-red-400 rounded-xl group-hover:scale-105 transition-transform">
                  <Trash2 className="w-4 h-4" />
                </div>
                <div className="text-left leading-none">
                  <strong className="block text-xs font-bold">Delete Photo</strong>
                  <span className="text-[10px] opacity-80 mt-1 inline-block font-sans">Revert photo back to system default spacer</span>
                </div>
              </button>

            </div>

            <div className="p-4 bg-gray-50 dark:bg-[#1a1b1c] border-t border-gray-100 dark:border-zinc-800 flex justify-end">
              <button
                onClick={() => {
                  setPhotoEditTarget(null);
                  setCustomPhotoUrl("");
                }}
                className="px-4 py-2 bg-gray-250 hover:bg-gray-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-850 dark:text-gray-200 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Close Settings
              </button>
            </div>

          </div>
        </div>
      )}

      {/* FULLSCREEN PHOTO LIGHTBOX PREVIEW */}
      {viewingFullscreenPhoto && (
        <div 
          onClick={() => setViewingFullscreenPhoto(null)}
          className="fixed inset-0 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center z-[200] p-4 cursor-zoom-out animate-in fade-in duration-200"
        >
          <button 
            onClick={() => setViewingFullscreenPhoto(null)}
            className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all border border-white/10 cursor-pointer"
            title="Exit light box"
          >
            <X className="w-6 h-6" />
          </button>
          
          <img 
            src={viewingFullscreenPhoto} 
            className="max-w-full max-h-[80vh] rounded-2xl object-contain shadow-2xl select-none" 
            alt="Fullscreen Preview" 
            onClick={(e) => e.stopPropagation()} 
          />
          <p className="text-xs text-gray-400 font-mono mt-4">Click anywhere outside to close preview</p>
        </div>
      )}

      {/* Toast notifications */}
      {notificationToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-gray-900/95 dark:bg-zinc-900/95 text-white text-xs px-4 py-3 rounded-2xl border border-zinc-850 shadow-2xl z-[150] flex items-center gap-2 max-w-sm animate-in fade-in slide-in-from-bottom-5 font-sans">
          <span className="text-sm select-none">🔔</span>
          <span className="font-medium">{notificationToast}</span>
        </div>
      )}

    </div>
  );
}
