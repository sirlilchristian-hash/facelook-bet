import { useState, useEffect, useRef } from "react";
import { Match } from "../types";
import { 
  Play, Pause, RefreshCw, Volume2, Sparkles, Trophy, 
  MoreVertical, Heart, Share2, MessageCircle, Compass, 
  Award, ExternalLink, Calendar, CheckCircle2, ShieldCheck, 
  HelpCircle, ChevronRight, Video, Flag, Star, BookOpen, UserCheck, Check, X, ShieldAlert, BadgeInfo, Bookmark
} from "lucide-react";

interface WatchViewProps {
  selectedMatch: Match | null;
  onSelectOdd: (match: Match, oddName: string, oddValue: number) => void;
  walletBalance: number;
  onSaveItem?: (type: string, content: string, thumb?: string) => void;
  onTagItem?: () => void;
}

interface VideoItem {
  id: string;
  title: string;
  creator: string;
  creatorAvatar: string;
  views: string;
  likes: number;
  liked?: boolean;
  commentsCount: number;
  tags: string[];
  duration: string;
  videoUrl?: string; // high-quality mock video thumbnail or mock interactive play
  thumbnailGradient: string;
  summary: string;
}

export default function WatchView({
  selectedMatch,
  onSelectOdd,
  walletBalance,
  onSaveItem,
  onTagItem,
}: WatchViewProps) {
  // Navigation Tabs at the top of Watch Tab
  const [watchSubTab, setWatchSubTab] = useState<"videos" | "success_factory">("videos");
  
  // Existing soccer game simulation state (Collapsible interactive widget)
  const [showMatchTracker, setShowMatchTracker] = useState(true);
  const [activeMatch, setActiveMatch] = useState<Match | null>(selectedMatch);
  const [isPlaying, setIsPlaying] = useState(true);
  const [matchMinute, setMatchMinute] = useState<number>(70);
  const [scoreHome, setScoreHome] = useState<number>(2);
  const [scoreAway, setScoreAway] = useState<number>(1);
  const [ballPos, setBallPos] = useState({ x: 50, y: 50 });
  const [homePlayerPos, setHomePlayerPos] = useState({ x: 40, y: 48 });
  const [awayPlayerPos, setAwayPlayerPos] = useState({ x: 60, y: 52 });
  const [commentaryList, setCommentaryList] = useState<Array<{ time: string; text: string; type: "ai" | "tactical" | "system" }>>([
    { time: "65'", text: "Yellow card issued to Chelsea midfielder for a technical foul on Bruno.", type: "system" },
    { time: "60'", text: "TACTICAL BRIEF: Manchester United has consolidated into a mid-block pivot, trying to close half-spaces.", type: "tactical" },
    { time: "58'", text: "GOAL! Bruno Fernandes clinical finish into the bottom right corner! Assist by Garnacho.", type: "ai" }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Interaction dropdown menus
  const [activeMenuVideoId, setActiveMenuVideoId] = useState<string | null>(null);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  
  // Partners Program Application State
  const [hasAppliedPartner, setHasAppliedPartner] = useState(false);
  const [appliedStatusText, setAppliedStatusText] = useState("");

  // Videos Data Store
  const [videosList, setVideosList] = useState<VideoItem[]>([
    {
      id: "v-1",
      title: "How I hit 100% Correct Score on Nairobi Derby Live Stream 🏆",
      creator: "Zephaniah Mwangi",
      creatorAvatar: "https://ui-avatars.com/api/?name=Zephaniah+Mwangi&background=a855f7&color=fff&bold=true",
      views: "14.2K",
      likes: 1240,
      liked: false,
      commentsCount: 382,
      tags: ["#lookupto", "#correctscore", "#nairobi_soccer", "#derby"],
      duration: "3:42",
      thumbnailGradient: "from-blue-600 to-indigo-900",
      summary: "Amazing high-stakes tactical review of local odds and betting parameters live."
    },
    {
      id: "v-2",
      title: "Leeds vs Man Utd Betting Ratio Analytics (Live commentary & public tips)",
      creator: "Metrine Karandini",
      creatorAvatar: "https://ui-avatars.com/api/?name=Metrine+Karandini&background=ec4899&color=fff&bold=true",
      views: "8.9K",
      likes: 642,
      liked: false,
      commentsCount: 119,
      tags: ["#predictions", "#leeds", "#ratios", "#facelook"],
      duration: "5:12",
      thumbnailGradient: "from-purple-600 to-pink-700",
      summary: "Step-by-step ratio analysis detailing P2P wagering triggers."
    },
    {
      id: "v-3",
      title: "Standard betting slips copycat tutorial from seasoned lookupto partners",
      creator: "Collo Dnego Page",
      creatorAvatar: "https://ui-avatars.com/api/?name=Collo+Dnego&background=059669&color=fff&bold=true",
      views: "4.5K",
      likes: 310,
      liked: false,
      commentsCount: 45,
      tags: ["#partnership", "#earnings", "#lookupto_clan"],
      duration: "2:15",
      thumbnailGradient: "from-emerald-600 to-teal-800",
      summary: "How to copy and synchronize daily staker layouts perfectly."
    },
    {
      id: "v-4",
      title: "English Premier League Weekend Projections & live odds breakdown",
      creator: "Hon Amini O. Junior",
      creatorAvatar: "https://ui-avatars.com/api/?name=Hon+Amini&background=f59e0b&color=fff&bold=true",
      views: "22.1K",
      likes: 2190,
      liked: false,
      commentsCount: 994,
      tags: ["#football_fever", "#epl_odds", "#betting_tips"],
      duration: "8:05",
      thumbnailGradient: "from-amber-600 to-red-800",
      summary: "Comprehensive look at match schedules, injured player rosters, and live broadcast odds."
    }
  ]);

  // Success Factory Videos (Stories from Users who found Facelook/LookUpto important)
  const [successFactoryList, setSuccessFactoryList] = useState<VideoItem[]>([
    {
      id: "sf-1",
      title: "My $3,200 payout milestone story using Facelook Pages! 💸🌸",
      creator: "Collins Dnego",
      creatorAvatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff&bold=true",
      views: "34.5K",
      likes: 4120,
      liked: true,
      commentsCount: 890,
      tags: ["#success_story", "#wallet_withdrawn", "#payout_milestone", "#facelook"],
      duration: "4:50",
      thumbnailGradient: "from-indigo-600 to-violet-955 shadow-inner",
      summary: "How setting up and syncing 'Baridi SANA Page' allowed automatic payouts and decentralized sports predictions!"
    },
    {
      id: "sf-2",
      title: "From standard bettor to elite clan-lead: My journey 📈🏆",
      creator: "Baridi SANA Page admin",
      creatorAvatar: "https://ui-avatars.com/api/?name=Baridi+Sana&background=1877f2&color=fff&bold=true",
      views: "18.7K",
      likes: 1980,
      liked: false,
      commentsCount: 410,
      tags: ["#facelook_important", "#clan_influence", "#sport_predictions"],
      duration: "6:10",
      thumbnailGradient: "from-sky-700 to-blue-900",
      summary: "Why Facelook Pages provided the crucial user interface to build community sports syndicates."
    }
  ]);

  // Interactive Tutorial Videos and Advertisements
  const tutorials = [
    {
      id: "tut-1",
      title: "Tutorial: Fast path to synchronize Pages & switch accounts",
      instructor: "Collins Dnego (Elite Partner)",
      length: "3 mins",
      views: "5,410 views",
      stepsCount: 4,
      desc: "Detailed visual guide demonstrating the See All Profiles switcher and how user profiles handle pages without overlapping layouts."
    },
    {
      id: "tut-2",
      title: "Tutorial: Navigating LookGroups & Staking syndicate ratios",
      instructor: "Zephaniah Mwangi (Veteran)",
      length: "5 mins",
      views: "8,209 views",
      stepsCount: 5,
      desc: "Learn about the peer-to-peer LookUpto engine, live odds calculators, and setting community goals for sports predictions."
    }
  ];

  // Sync state if selectedMatch changes from outside (e.g. Game Hub)
  useEffect(() => {
    if (selectedMatch) {
      setActiveMatch(selectedMatch);
      const parts = selectedMatch.score.split("-");
      if (parts.length === 2) {
        setScoreHome(parseInt(parts[0]) || 0);
        setScoreAway(parseInt(parts[1]) || 0);
      }
      const min = parseInt(selectedMatch.time.replace("'", ""));
      setMatchMinute(isNaN(min) ? 45 : min);
    }
  }, [selectedMatch]);

  // Football pitch live simulation ticker
  useEffect(() => {
    let timer: any;
    if (isPlaying && activeMatch && activeMatch.status === "LIVE") {
      timer = setInterval(() => {
        setMatchMinute((prev) => {
          if (prev >= 90) {
            setIsPlaying(false);
            return 90;
          }
          const bx = 30 + Math.random() * 40;
          const by = 20 + Math.random() * 60;
          setBallPos({ x: bx, y: by });
          setHomePlayerPos({ x: bx - 4 - Math.random() * 6, y: by + (Math.random() - 0.5) * 10 });
          setAwayPlayerPos({ x: bx + 4 + Math.random() * 6, y: by + (Math.random() - 0.5) * 10 });

          if (Math.random() > 0.85) {
            const randomEvents = [
              "Fierce tackle wins possession in the wide spaces!",
              "Spectacular save from the goalkeeper tipping it over the crossbar!",
              "Sensational counter-attack on the left-wing flank!",
              "Offside flag ruins a beautiful through-ball chance.",
              "The crowd chant intensifies as the attack builds up!",
              "Shouts of hand-ball are waved away by the referee."
            ];
            const eventText = randomEvents[Math.floor(Math.random() * randomEvents.length)];
            setCommentaryList((prevList) => [
              { time: `${prev + 1}'`, text: eventText, type: "system" },
              ...prevList.slice(0, 15)
            ]);
          }

          if (Math.random() > 0.985) {
            const isHomeScoring = Math.random() > 0.5;
            if (isHomeScoring) {
              setScoreHome((s) => s + 1);
              setCommentaryList((pl) => [
                { time: `${prev + 1}'`, text: `🎉 GOAL! Beautiful combination play leads to a stunner into the top corner for ${activeMatch.homeTeam}!`, type: "ai" },
                ...pl
              ]);
            } else {
              setScoreAway((s) => s + 1);
              setCommentaryList((pl) => [
                { time: `${prev + 1}'`, text: `🎉 GOAL! Sensational counter strikes the net for ${activeMatch.awayTeam}! Deflection caught the keeper off-balance.`, type: "ai" },
                ...pl
              ]);
            }
          }
          return prev + 1;
        });
      }, 3500);
    }
    return () => clearInterval(timer);
  }, [isPlaying, activeMatch]);

  // AI generated broadcaster insights
  const fetchAiCommentary = async () => {
    if (!activeMatch) return;
    setIsAiLoading(true);
    try {
      const response = await fetch("/api/generate-commentary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          homeTeam: activeMatch.homeTeam,
          awayTeam: activeMatch.awayTeam,
          minute: `${matchMinute}'`,
          score: `${scoreHome} - ${scoreAway}`,
        }),
      });
      const data = await response.json();
      if (data) {
        setCommentaryList((prev) => [
          { time: `${matchMinute}'`, text: `🎙️ BROADCASTER: ${data.leadCommentary}`, type: "ai" },
          { time: `${matchMinute}'`, text: `🍻 PUB BANTER: ${data.crowdBanter}`, type: "system" },
          { time: `${matchMinute}'`, text: `📊 TACTICAL: ${data.tacticalAnalysis}`, type: "tactical" },
          ...prev
        ]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleLikeVideo = (id: string, listType: "videos" | "sf") => {
    if (listType === "videos") {
      setVideosList(prev => prev.map(v => {
        if (v.id === id) {
          return { ...v, liked: !v.liked, likes: v.liked ? v.likes - 1 : v.likes + 1 };
        }
        return v;
      }));
    } else {
      setSuccessFactoryList(prev => prev.map(v => {
        if (v.id === id) {
          return { ...v, liked: !v.liked, likes: v.liked ? v.likes - 1 : v.likes + 1 };
        }
        return v;
      }));
    }
  };

  const handleApplyPartnership = () => {
    setHasAppliedPartner(true);
    setAppliedStatusText("Applying model credentials... Checking compliance metrics... Your profile holds 1,209 followers which exceeds the 1,000 threshold requirement! Application is now under pending administrative view.");
    alert("Application successfully submitted! You've met all eligibility rules.");
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto px-1 py-1 font-sans text-left">
      
      {/* 1. APPLET WATCH TAB HEADER CONTROL - Two Sub-Tabs with pristine spacing and layout */}
      <div className="flex flex-col bg-white dark:bg-[#1c1d1e] rounded-2xl shadow-sm border border-gray-200/55 dark:border-zinc-800 p-2 text-left space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-2">
          <div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
              <h2 className="text-lg font-black text-gray-900 dark:text-gray-100 flex items-center gap-1.5 font-sans">
                <Video className="w-5 h-5 text-blue-500" />
                <span>Facelook Watch Hub</span>
              </h2>
            </div>
            <p className="text-[11px] text-gray-400 font-medium">
              Explore user-generated soccer broadcasts, success stories, and tutorial courses.
            </p>
          </div>

          <div className="flex bg-gray-100 dark:bg-zinc-800 p-1 rounded-xl w-full sm:w-auto self-start">
            <button
              onClick={() => setWatchSubTab("videos")}
              className={`flex-1 sm:flex-initial py-2 px-4 rounded-lg text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-all ${
                watchSubTab === "videos"
                  ? "bg-white dark:bg-[#242526] text-blue-600 shadow-sm"
                  : "text-gray-500 hover:text-gray-800 dark:hover:text-gray-200"
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Videos / Reels</span>
            </button>
            <button
              onClick={() => setWatchSubTab("success_factory")}
              className={`flex-1 sm:flex-initial py-2 px-4 rounded-lg text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-all ${
                watchSubTab === "success_factory"
                  ? "bg-white dark:bg-[#242526] text-amber-600 shadow-sm"
                  : "text-gray-500 hover:text-gray-800 dark:hover:text-gray-200"
              }`}
            >
              <Star className="w-3.5 h-3.5" />
              <span>Success Factory</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. LIVE SOCCER PITCH COLLAPSIBLE CONTAINER (Featured live broadcast stream match simulator) */}
      {showMatchTracker && activeMatch ? (
        <div className="bg-white dark:bg-[#242526] rounded-2xl shadow-sm overflow-hidden border border-gray-200 dark:border-[#3e4042] transition-colors duration-300">
          <div className="bg-gradient-to-r from-blue-700 via-indigo-900 to-slate-900 px-4 py-2.5 flex items-center justify-between text-white text-xs select-none">
            <div className="flex items-center gap-2.5 font-bold">
              <span className="bg-red-500 animate-pulse text-[10px] font-black px-1.5 py-0.5 rounded leading-none">LIVE</span>
              <span className="opacity-90">{activeMatch.league} • Match Analyzer Overlay</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline bg-white/10 text-white/80 font-mono scale-90 px-2 py-0.5 rounded">Broadcast</span>
              <button 
                onClick={() => setShowMatchTracker(false)}
                className="hover:bg-white/15 px-1.5 py-0.5 rounded text-white/70 hover:text-white transition-colors"
                title="Hide Match Tracker"
              >
                ✕
              </button>
            </div>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-[#1a1b1c] grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Live interactive match pitch representation */}
            <div className="md:col-span-8 flex flex-col space-y-3">
              
              <div className="flex items-center justify-between px-2 bg-white dark:bg-[#242526] p-2.5 rounded-xl border border-gray-150 dark:border-zinc-800">
                <div className="text-right flex-1 truncate">
                  <span className="font-extrabold text-sm text-gray-900 dark:text-white">{activeMatch.homeTeam}</span>
                  <span className="block text-[10px] text-gray-400 capitalize">Home team</span>
                </div>
                
                <div className="flex flex-col items-center px-4 shrink-0">
                  <div className="bg-blue-105 dark:bg-blue-952/50 text-blue-600 dark:text-blue-400 font-black text-xl px-4 py-1.5 rounded-xl border border-blue-500/10 flex items-center gap-2">
                    <span>{scoreHome}</span>
                    <span className="opacity-30">:</span>
                    <span>{scoreAway}</span>
                  </div>
                  <span className="mt-1 text-[11px] font-black text-red-500 font-mono tracking-widest">{matchMinute}'</span>
                </div>

                <div className="text-left flex-1 truncate font-sans">
                  <span className="font-extrabold text-sm text-gray-900 dark:text-white">{activeMatch.awayTeam}</span>
                  <span className="block text-[10px] text-gray-400 capitalize">Away team</span>
                </div>
              </div>

              {/* Pitch markup visualizer */}
              <div 
                className="relative w-full h-52 bg-emerald-700 overflow-hidden rounded-xl border border-emerald-600 flex items-center justify-center"
                style={{
                  backgroundImage: `radial-gradient(circle, rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(180deg, #15803d 0%, #166534 100%)`,
                  backgroundSize: "16px 16px, 100% 100%"
                }}
              >
                <div className="absolute inset-2 border border-white/10 pointer-events-none rounded flex items-center justify-center">
                  <div className="w-16 h-16 border border-white/10 rounded-full flex items-center justify-center">
                    <div className="w-1 h-1 bg-white/20 rounded-full" />
                  </div>
                  <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-white/10" />
                  <div className="absolute left-0 top-1/4 bottom-1/4 w-8 border border-l-0 border-white/10" />
                  <div className="absolute right-0 top-1/4 bottom-1/4 w-8 border border-r-0 border-white/10" />
                </div>

                {/* Simulated live elements */}
                <div 
                  className="absolute w-3 h-3 bg-white rounded-full border border-black shadow transition-all duration-500 ease-out flex items-center justify-center text-[5px]"
                  style={{ left: `${ballPos.x}%`, top: `${ballPos.y}%`, transform: 'translate(-50%, -50%)' }}
                >
                  ⚽
                </div>

                <div 
                  className="absolute w-5 h-5 rounded-full bg-blue-600 border border-white text-[8px] text-white flex items-center justify-center font-black transition-all duration-500 ease-out shadow"
                  style={{ left: `${homePlayerPos.x}%`, top: `${homePlayerPos.y}%`, transform: 'translate(-50%, -50%)' }}
                >
                  H
                </div>

                <div 
                  className="absolute w-5 h-5 rounded-full bg-red-600 border border-white text-[8px] text-white flex items-center justify-center font-black transition-all duration-500 ease-out shadow"
                  style={{ left: `${awayPlayerPos.x}%`, top: `${awayPlayerPos.y}%`, transform: 'translate(-50%, -50%)' }}
                >
                  A
                </div>

                {/* Audio label */}
                <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[9px] text-green-400 font-mono flex items-center gap-1 select-none">
                  <Volume2 className="w-3 h-3 text-green-400" /> Broadcast Feed Live
                </div>

                {/* Simulated controls Overlay */}
                <div className="absolute bottom-2 right-2 bg-black/60 text-white rounded p-1 flex items-center gap-1.5 select-none scale-90">
                  <button onClick={() => setIsPlaying(!isPlaying)} className="p-1 hover:bg-white/20 rounded" title="Pause simulation">
                    {isPlaying ? <Pause className="w-3 h-3 fill-white" /> : <Play className="w-3 h-3 fill-white" />}
                  </button>
                  <button onClick={() => { setScoreHome(2); setScoreAway(1); setMatchMinute(70); }} className="p-1 hover:bg-white/20 rounded" title="Reset score mockup">
                    <RefreshCw className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Ratios selection buttons */}
              <div className="bg-white dark:bg-[#242526] p-2.5 rounded-xl border border-gray-150 dark:border-zinc-800 space-y-1.5">
                <span className="text-[9px] text-gray-400 font-mono tracking-wider font-bold">LIVE STAKING RATIOS SYNC</span>
                <div className="grid grid-cols-3 gap-2">
                  <button onClick={() => onSelectOdd(activeMatch, activeMatch.homeTeam, activeMatch.odds["1"])} className="p-1.5 hover:bg-blue-50 hover:border-blue-500 dark:hover:bg-blue-900/10 border border-gray-200 dark:border-zinc-800 text-[11px] font-bold rounded flex flex-col items-center">
                    <span className="text-[9px] text-gray-400">1 (Home)</span>
                    <span className="text-sm font-black text-gray-800 dark:text-gray-100">{activeMatch.odds["1"].toFixed(2)}</span>
                  </button>
                  <button onClick={() => onSelectOdd(activeMatch, "Draw", activeMatch.odds.X)} className="p-1.5 hover:bg-blue-50 hover:border-blue-500 dark:hover:bg-blue-900/10 border border-gray-200 dark:border-zinc-800 text-[11px] font-bold rounded flex flex-col items-center">
                    <span className="text-[9px] text-gray-400">X (Draw)</span>
                    <span className="text-sm font-black text-gray-800 dark:text-gray-100">{activeMatch.odds.X.toFixed(2)}</span>
                  </button>
                  <button onClick={() => onSelectOdd(activeMatch, activeMatch.awayTeam, activeMatch.odds["2"])} className="p-1.5 hover:bg-blue-50 hover:border-blue-500 dark:hover:bg-blue-900/10 border border-gray-200 dark:border-zinc-800 text-[11px] font-bold rounded flex flex-col items-center">
                    <span className="text-[9px] text-gray-400">2 (Away)</span>
                    <span className="text-sm font-black text-gray-800 dark:text-gray-100">{activeMatch.odds["2"].toFixed(2)}</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Live broadcast commentary panel */}
            <div className="md:col-span-4 flex flex-col space-y-2 max-h-[300px] overflow-hidden">
              <div className="flex items-center justify-between pb-1.5 border-b border-gray-100 dark:border-zinc-850">
                <span className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest">Commentary (AI)</span>
                <button onClick={fetchAiCommentary} disabled={isAiLoading} className="py-1 px-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-xs transition-colors">
                  <Sparkles className={`w-2.5 h-2.5 ${isAiLoading ? "animate-spin" : ""}`} /> Ask AI
                </button>
              </div>

              <div className="flex-1 overflow-y-auto pr-1 space-y-2 text-xs">
                {commentaryList.map((comm, index) => (
                  <div key={index} className={`p-2 rounded-lg border text-[11px] leading-relaxed text-left ${
                    comm.type === "ai" 
                      ? "bg-blue-50/50 dark:bg-blue-950/15 border-blue-200/50 dark:border-blue-900/30 text-blue-900 dark:text-blue-100" 
                      : comm.type === "tactical"
                      ? "bg-zinc-100/50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-gray-300 font-mono"
                      : "bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/50 dark:border-emerald-900/30 text-emerald-900 dark:text-emerald-100"
                  }`}>
                    <span className="font-black text-gray-500 mr-1">[{comm.time}]</span>
                    {comm.text}
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      ) : activeMatch ? (
        <div className="flex justify-start px-2">
          <button 
            onClick={() => setShowMatchTracker(true)}
            className="py-1 px-3 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-650 dark:text-gray-300 font-mono font-bold text-[10px] rounded-lg border border-gray-200 dark:border-zinc-800 flex items-center gap-1 select-none transition-colors"
          >
            📊 Show Interactive Soccer Simulation Feed
          </button>
        </div>
      ) : null}

      {/* 3. CONDITIONAL RENDER BY ACTIVE WATCH TAB SUB-SELECTION */}
      
      {/* ======================= SUB-TAB: VIDEOS ======================= */}
      {watchSubTab === "videos" && (
        <div className="space-y-6">
          
          {/* Section banner */}
          <div className="p-4 bg-blue-50 dark:bg-blue-950/15 rounded-2xl border border-blue-150 dark:border-[#3e4042] flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-sans">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-mono font-black text-blue-600 dark:text-blue-400 bg-white dark:bg-blue-950 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-900">
                Live Creator Feed
              </span>
              <h3 className="text-sm font-black text-blue-950 dark:text-blue-200">
                Reels & Clips shared by Predictors
              </h3>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                Track how lookupto champions analyze high ratios in their respective regions. Click play overlay to buffer.
              </p>
            </div>
            <div className="bg-white dark:bg-zinc-850 p-2 rounded-xl text-center shadow-xs shrink-0 font-mono text-[10px] font-bold text-gray-550 border border-gray-150 dark:border-zinc-800 flex items-center gap-1.5 h-fit select-none">
              <Video className="w-3.5 h-3.5 text-blue-500" />
              <span>{videosList.length} clips synchronized</span>
            </div>
          </div>

          {/* Videos Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {videosList.map((video) => {
              const menuOpen = activeMenuVideoId === video.id;
              const isPlayingNow = activeVideoId === video.id;
              
              return (
                <div 
                  key={video.id}
                  className="bg-white dark:bg-[#242526] rounded-2xl shadow-sm border border-gray-200/55 dark:border-zinc-800 overflow-hidden font-sans relative flex flex-col transition-all duration-200 hover:shadow-md"
                >
                  
                  {/* Aspect video Thumbnail mock-up */}
                  <div className={`aspect-video w-full bg-gradient-to-br ${video.thumbnailGradient} relative flex items-center justify-center overflow-hidden`}>
                    
                    {/* Background visual element */}
                    <div className="absolute inset-0 opacity-15 pointer-events-none flex items-center justify-center">
                      <Compass className="w-64 h-64 animate-spin-slow" />
                    </div>

                    {/* Simulated stream video loading buffer overlay */}
                    {isPlayingNow ? (
                      <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-4">
                        <div className="w-8 h-8 rounded-full border-2 border-t-blue-500 border-gray-600 animate-spin mb-2" />
                        <span className="text-[11px] font-mono font-bold text-blue-400">CONNECTING TO VIDEO BUFFER...</span>
                        <p className="text-[10px] text-gray-500 text-center max-w-xs mt-1.5">
                          "{video.summary}"
                        </p>
                        <button 
                          onClick={() => setActiveVideoId(null)} 
                          className="mt-4 py-1 px-3 bg-red-650 hover:bg-red-700 text-white rounded-lg text-[9px] font-black uppercase font-mono"
                        >
                          Stop Buffer
                        </button>
                      </div>
                    ) : (
                      <div className="text-center p-4 relative z-10 space-y-3">
                        <button 
                          onClick={() => setActiveVideoId(video.id)}
                          className="w-12 h-12 rounded-full bg-white/90 hover:bg-white text-gray-950 flex items-center justify-center shadow-lg active:scale-95 transition-transform cursor-pointer relative mx-auto"
                        >
                          <Play className="w-5 h-5 translate-x-0.5 fill-current text-blue-600" />
                          <span className="absolute -inset-1 rounded-full border-2 border-white/40 animate-ping pointer-events-none" />
                        </button>
                        <span className="inline-block px-2 py-0.5 bg-black/40 text-white/90 text-[10px] font-sans font-extrabold tracking-wide rounded-md backdrop-blur-xs select-none">
                          {video.duration} Live Clip
                        </span>
                      </div>
                    )}

                    {/* Overlay Tag Labels */}
                    <div className="absolute top-3 left-3 flex gap-1 items-center shrink-0">
                      <span className="bg-[#1877f2] hover:bg-blue-600 text-white font-black text-[9px] px-1.5 py-0.5 rounded leading-none uppercase select-none shadow-xs">
                        {video.views} Views
                      </span>
                    </div>

                    {/* THREE DOTS SHORTCUT TOOLBAR BUTTON NEXT TO VIDEO */}
                    <div className="absolute top-3 right-3">
                      <button
                        onClick={() => setActiveMenuVideoId(menuOpen ? null : video.id)}
                        className="p-1.5 bg-black/45 hover:bg-black/85 text-white rounded-full transition-colors backdrop-blur-xs relative cursor-pointer"
                        title="Video options Menu"
                        id={`menu-trigger-${video.id}`}
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>

                      {/* Dropdown popup overlay */}
                      {menuOpen && (
                        <div className="absolute right-0 mt-1.5 w-48 bg-white dark:bg-[#1c1d1e] rounded-xl shadow-xl border border-gray-150 dark:border-zinc-800 py-1.5 z-40 text-xs animate-in slide-in-from-top-2 duration-150">
                          <div className="px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest text-gray-400 font-extrabold border-b border-gray-100 dark:border-zinc-85/50 mb-1 leading-none select-none">
                            Shortcut Options
                          </div>
                          
                          <button
                            onClick={() => {
                              if (onSaveItem) {
                                onSaveItem('video', video.title);
                              } else {
                                alert(`Successfully saved: "${video.title}" to your Facelook favorites list.`);
                              }
                              setActiveMenuVideoId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-250 flex items-center gap-2 cursor-pointer font-bold"
                          >
                            <Bookmark className="w-4 h-4 text-purple-400" /> Save to Bookmarks
                          </button>

                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(window.location.href);
                              alert("Video reference URL copied to clipboard!");
                              setActiveMenuVideoId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-250 flex items-center gap-2 cursor-pointer font-bold"
                          >
                            🔗 Copy video link
                          </button>

                          <button
                            onClick={() => {
                              if (onTagItem) onTagItem();
                              setActiveMenuVideoId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-250 flex items-center gap-2 cursor-pointer font-bold"
                          >
                            <UserCheck className="w-4 h-4 text-blue-500" /> Tag Friends
                          </button>

                          <button
                            onClick={() => {
                              alert(`Sharing live clip by creator ${video.creator} to the community sport feeds.`);
                              setActiveMenuVideoId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-250 flex items-center gap-2 cursor-pointer font-bold"
                          >
                            🚀 Share in LookGroups
                          </button>

                          <button
                            onClick={() => {
                              alert(`Creator flag registered. Compliance team will verify "${video.title}" statistics.`);
                              setActiveMenuVideoId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-red-500 flex items-center gap-2 cursor-pointer font-bold"
                          >
                            🚨 Report Violation
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Creator and Metadata */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    
                    <div className="space-y-2">
                      {/* Avatar metadata */}
                      <div className="flex items-center gap-2.5">
                        <img 
                          src={video.creatorAvatar} 
                          alt="creator" 
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-full border border-gray-200 dark:border-zinc-800" 
                        />
                        <div className="text-left font-sans">
                          <p className="text-xs font-black text-gray-800 dark:text-gray-250">{video.creator}</p>
                          <span className="text-[9px] text-gray-400">Shared recently</span>
                        </div>
                      </div>

                      {/* Video Title */}
                      <h4 className="text-sm font-black text-gray-900 dark:text-white leading-snug">
                        {video.title}
                      </h4>

                      {/* Video Summary Description */}
                      <p className="text-[11px] text-gray-650 dark:text-gray-400">
                        {video.summary}
                      </p>

                      {/* Display hashtags */}
                      <div className="flex flex-wrap gap-1 pt-1 select-none">
                        {video.tags.map(t => (
                          <span key={t} className="text-[10px] text-blue-500 hover:underline cursor-pointer">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Bottom Action buttons */}
                    <div className="mt-4 pt-3 border-t border-gray-100 dark:border-zinc-805 flex items-center justify-between text-xs font-bold font-sans">
                      <button 
                        onClick={() => handleLikeVideo(video.id, "videos")}
                        className={`flex items-center gap-1.5 py-1 px-3.5 rounded-lg border cursor-pointer select-none transition-all ${
                          video.liked 
                            ? "bg-red-50 dark:bg-red-950/20 text-red-500 border-red-200" 
                            : "hover:bg-gray-100 dark:hover:bg-zinc-800 border-transparent text-gray-500 dark:text-gray-400"
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${video.liked ? "fill-current scale-110" : ""}`} />
                        <span>{video.likes} Likes</span>
                      </button>

                      <button 
                        onClick={() => alert(`Enter comment modal for ${video.title}: Type below to provide tipping feedback.`)}
                        className="hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-gray-400 py-1 px-3.5 rounded-lg flex items-center gap-1.5 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>{video.commentsCount} Comments</span>
                      </button>

                      <button 
                        onClick={() => alert("Links synchronized: Shared this predictor video to your Lookfeed wall!")}
                        className="hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-gray-400 py-1 px-2 rounded-lg flex items-center gap-1"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share</span>
                      </button>
                    </div>

                  </div>

                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* ======================= SUB-TAB: SUCCESS FACTORY ======================= */}
      {watchSubTab === "success_factory" && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Main Hero Header */}
          <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 p-6 rounded-2xl text-black relative overflow-hidden shadow-md">
            <div className="absolute right-0 top-0 opacity-10 transform translate-x-8 -translate-y-8">
              <Trophy className="w-80 h-80 text-black fill-current" />
            </div>
            
            <div className="relative z-10 max-w-2xl space-y-2 font-sans">
              <div className="inline-flex items-center gap-1 bg-black text-amber-500 font-extrabold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider font-mono shadow-xs">
                ⭐ Community Accomplishment Engine
              </div>
              <h2 className="text-2xl font-black tracking-tight text-black">
                The Facelook Success Factory
              </h2>
              <p className="text-xs font-semibold text-amber-950 leading-relaxed">
                Loading videos & testimonies from elite users who have found <strong>Facelook / LookUpto</strong> critical to their daily sports connection, staking clans, and real-time news management. See what's possible and check your partnership requirements.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Col - Success Story Video items & Tutorials */}
            <div className="lg:col-span-8 space-y-6">
              
              <div className="space-y-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5 px-1">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Success Showcase (High-Impact Videos)</span>
                </h3>

                <div className="grid grid-cols-1 gap-4">
                  {successFactoryList.map((story) => {
                    const isPlayingNow = activeVideoId === story.id;
                    const menuOpen = activeMenuVideoId === story.id;

                    return (
                      <div 
                        key={story.id} 
                        className="bg-white dark:bg-[#242526] p-4 rounded-2xl border border-gray-150 dark:border-zinc-800 flex flex-col sm:flex-row gap-4 relative transition-all duration-200 hover:shadow-sm"
                      >
                        
                        {/* Interactive aspect thumbnail */}
                        <div className={`w-full sm:w-44 h-32 bg-gradient-to-tr ${story.thumbnailGradient} rounded-xl relative flex items-center justify-center shrink-0`}>
                          
                          {isPlayingNow ? (
                            <div className="absolute inset-0 bg-black/95 rounded-xl flex flex-col items-center justify-center text-center p-2">
                              <div className="w-5 h-5 rounded-full border-2 border-t-amber-500 border-gray-700 animate-spin mb-1" />
                              <span className="text-[10px] font-mono text-amber-400 font-bold uppercase">Streaming...</span>
                            </div>
                          ) : (
                            <button 
                              onClick={() => setActiveVideoId(story.id)}
                              className="w-10 h-10 rounded-full bg-white text-amber-600 flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-transform"
                            >
                              <Play className="w-4 h-4 fill-current translate-x-0.5" />
                            </button>
                          )}

                          <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded">
                            {story.duration}
                          </span>
                        </div>

                        {/* Story text info */}
                        <div className="flex-1 flex flex-col justify-between text-left">
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 text-[10px] uppercase font-black tracking-wide font-mono px-2 py-0.5 rounded leading-none shrink-0">
                                User Story
                              </span>
                              <span className="text-[11px] text-gray-400 font-sans">
                                {story.views} views
                              </span>
                            </div>

                            <h4 className="text-sm font-black text-gray-900 dark:text-white leading-tight">
                              {story.title}
                            </h4>
                            
                            <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
                              {story.summary}
                            </p>
                          </div>

                          <div className="flex items-center justify-between pt-2 mt-2 border-t border-gray-100 dark:border-zinc-805 text-xs text-gray-400">
                            <div className="flex items-center gap-1.5 text-gray-800 dark:text-gray-200">
                              <img src={story.creatorAvatar} alt="cr" className="w-5 h-5 rounded-full" />
                              <span className="font-extrabold text-[11px]">{story.creator}</span>
                            </div>

                            <button 
                              onClick={() => handleLikeVideo(story.id, "sf")}
                              className={`flex items-center gap-1 hover:text-red-500 ${story.liked ? "text-red-500 font-bold" : ""}`}
                            >
                              <Heart className={`w-3.5 h-3.5 ${story.liked ? "fill-current" : ""}`} />
                              <span>{story.likes}</span>
                            </button>
                          </div>

                        </div>

                        {/* Three dots option */}
                        <div className="absolute top-3 right-3">
                          <button
                            onClick={() => setActiveMenuVideoId(menuOpen ? null : story.id)}
                            className="p-1 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full"
                          >
                            <MoreVertical className="w-4 h-4 text-gray-400" />
                          </button>

                          {menuOpen && (
                            <div className="absolute right-0 mt-1.5 w-44 bg-white dark:bg-[#1a1b1c] rounded-xl shadow-xl border border-gray-150 dark:border-zinc-800 py-1.5 z-40 text-xs">
                              <button
                                onClick={() => {
                                  alert(`Copied link to ${story.creator}'s success testimony!`);
                                  setActiveMenuVideoId(null);
                                }}
                                className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-200 font-medium"
                              >
                                🔗 Copy story link
                              </button>
                              <button
                                onClick={() => {
                                  alert(`Successfully saved this story reference context.`);
                                  setActiveMenuVideoId(null);
                                }}
                                className="w-full text-left px-3 py-1.5 hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-200 font-medium"
                              >
                                🔖 Save story bookmark
                              </button>
                            </div>
                          )}
                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>

              {/* TUTORIAL AND ADVERTISEMENT VIDEOS */}
              <div className="space-y-3 font-sans border-t border-gray-150 dark:border-zinc-800 pt-5">
                <div className="flex justify-between items-center px-1">
                  <h3 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-emerald-500" />
                    <span>Tutorial Lessons & Partner Course Guides</span>
                  </h3>
                  <span className="text-[10px] bg-green-50 dark:bg-green-950/40 text-green-600 dark:text-green-400 font-bold px-2 py-0.5 rounded-full select-none">
                    Free access
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {tutorials.map((tut, idx) => (
                    <div 
                      key={tut.id} 
                      className="bg-gray-50 dark:bg-[#1c1d1e] p-4 rounded-2xl border border-gray-200/55 dark:border-zinc-800 flex flex-col justify-between text-left space-y-3.5 transition-all hover:border-emerald-500/30"
                    >
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-black tracking-widest uppercase font-mono px-1.5 py-0.5 rounded leading-none">
                            Tutorial Video
                          </span>
                          <span className="text-[11px] text-gray-400 font-mono font-bold">
                            {tut.length}
                          </span>
                        </div>

                        <h4 className="text-xs font-black text-gray-900 dark:text-white leading-tight">
                          {tut.title}
                        </h4>

                        <p className="text-[11px] text-gray-500 dark:text-gray-450 leading-relaxed font-sans">
                          {tut.desc}
                        </p>
                      </div>

                      <div className="pt-2.5 border-t border-gray-150 dark:border-zinc-805 flex justify-between items-center">
                        <div className="text-[9px] leading-tight text-gray-450">
                          <span className="block font-black text-gray-600 dark:text-gray-300 truncate max-w-[120px]">{tut.instructor}</span>
                          <span className="block">{tut.views}</span>
                        </div>

                        <button 
                          onClick={() => alert(`Launching training content for: ${tut.title}. Syncing guidelines...`)}
                          className="py-1 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black transition-transform active:scale-95 cursor-pointer leading-normal shrink-0"
                        >
                          Play Lesson
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* MOCK ADVERTISEMENT INTERSTITIAL PANEL */}
              <div className="p-4 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 rounded-2xl border border-purple-500/20 text-white relative h-36 flex items-center justify-between shadow-xs overflow-hidden select-none">
                <div className="absolute left-0 top-0 opacity-10 font-mono font-black scale-150 tracking-widest text-[#1877f2] ml-12">
                  SPONSOR
                </div>
                <div className="relative z-10 max-w-sm space-y-1">
                  <span className="bg-purple-500 text-white text-[9px] font-bold uppercase py-0.5 px-1.5 rounded">
                    Sponsored AD
                  </span>
                  <h4 className="text-sm font-black tracking-tight flex items-center gap-1">
                    <span>LookUpto AI Pro Prediction Scanner</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  </h4>
                  <p className="text-[10px] text-gray-300 leading-normal">
                    Gain exclusive real-time access to odds scanners, global syndicater margins, and automatic Mashemeji Derby odds calculators. Get 10% bonus today!
                  </p>
                </div>

                <button 
                  onClick={() => alert("Redirecting safely to official partner portal. Thanks for supporting Facelook sponsors!")}
                  className="relative z-10 py-1.5 px-3.5 rounded-xl bg-white hover:bg-gray-100 text-black font-black text-[11px] shadow-sm select-none shrink-0"
                >
                  Unlock Scanner
                </button>
              </div>

            </div>

            {/* Right Col - Partnership Requirements Checklist */}
            <div className="lg:col-span-4 space-y-4">
              
              <div className="bg-white dark:bg-[#242526] p-4.5 rounded-2xl border border-gray-150 dark:border-zinc-800 shadow-sm text-left font-sans space-y-4">
                
                <h3 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5 border-b border-gray-100 dark:border-zinc-800 pb-2">
                  <Award className="w-4 h-4 text-amber-500" />
                  <span>Facelook Partner Program</span>
                </h3>

                <p className="text-[11px] text-gray-505 dark:text-gray-400 leading-relaxed leading-normal">
                  Earn revenue payouts directly from staker volume, share sponsored advice reels, and receive secondary page validation checks by joining our elite compliance network.
                </p>

                {/* Progress Requirements checklist */}
                <div className="space-y-4 pt-1 text-xs">
                  
                  {/* Status checklist item 1 */}
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-extrabold text-gray-800 dark:text-gray-200">1. Followers Metric</span>
                      <span className="font-mono text-green-500 font-extrabold flex items-center gap-0.5">
                        <Check className="w-3 h-3" />
                        <span>1,209 / 1,000</span>
                      </span>
                    </div>
                    {/* Visual Progress bar */}
                    <div className="w-full bg-gray-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full w-full rounded-full" />
                    </div>
                    <span className="text-[9px] text-gray-400 font-mono">Status: Met by Collins Dnego Profile</span>
                  </div>

                  {/* Status checklist item 2 */}
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-extrabold text-gray-800 dark:text-gray-200">2. Active Bets Shared</span>
                      <span className="font-mono text-green-500 font-extrabold flex items-center gap-0.5">
                        <Check className="w-3 h-3" />
                        <span>5 / 5 Shared</span>
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full w-full rounded-full" />
                    </div>
                    <span className="text-[9px] text-gray-400 font-mono">Status: Standard predictor post checklist clear</span>
                  </div>

                  {/* Status checklist item 3 */}
                  <div className="space-y-1 pt-1.5">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-extrabold text-gray-800 dark:text-gray-200">3. Community Trust Score</span>
                      <span className="font-mono text-green-500 font-extrabold flex items-center gap-0.5">
                        <Check className="w-3 h-3" />
                        <span>Excellent</span>
                      </span>
                    </div>
                    <span className="text-[9px] text-gray-400 leading-normal block">Verified non-destructive account. No reports flagged.</span>
                  </div>

                  {/* Status checklist item 4 */}
                  <div className="space-y-1 pt-1.5 border-t border-gray-100 dark:border-zinc-850 pt-2 pb-1.5">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-extrabold text-gray-850 dark:text-gray-200">4. Page Connection Check</span>
                      <span className="text-amber-500 font-extrabold font-mono text-[10px] tracking-wide uppercase px-1.5 py-0.5 bg-amber-50 dark:bg-amber-955/25 rounded">
                        Synchronized
                      </span>
                    </div>
                    <span className="text-[10px] text-gray-400 leading-normal block font-normal">
                      Connected to <strong>Baridi SANA Page</strong> and <strong>Collo Dnego Page</strong>.
                    </span>
                  </div>

                </div>

                {/* Application action area */}
                <div className="pt-2 border-t border-gray-150 dark:border-zinc-800 space-y-2">
                  <button 
                    onClick={handleApplyPartnership}
                    disabled={hasAppliedPartner}
                    className={`w-full py-2.5 px-3 rounded-xl font-black text-xs text-center transition-all ${
                      hasAppliedPartner 
                        ? "bg-gray-100 dark:bg-zinc-800 text-gray-400 cursor-default" 
                        : "bg-blue-600 hover:bg-blue-700 text-white shadow-sm active:scale-95 cursor-pointer"
                    }`}
                  >
                    {hasAppliedPartner ? "✓ Application Submitted" : "Apply for Facelook Partnership"}
                  </button>
                  <p className="text-[9px] text-gray-450 text-center font-normal">
                    Applications will remain under 1-3 business days review by official lookupto administrators.
                  </p>
                </div>

              </div>

              {/* Applying Compliance Warnings */}
              {hasAppliedPartner && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950/20 text-blue-900 dark:text-blue-200 border border-blue-200 dark:border-blue-900 rounded-2xl text-[11px] space-y-1 text-left animate-in fade-in duration-200">
                  <div className="flex items-center gap-1.5 font-bold">
                    <ShieldCheck className="w-4 h-4 text-blue-500 shrink-0" />
                    <span>Compliance Verification Success</span>
                  </div>
                  <p className="leading-relaxed text-gray-650 dark:text-gray-300">
                    {appliedStatusText}
                  </p>
                </div>
              )}

              {/* Informative Partner Guide Box */}
              <div className="bg-gray-50 dark:bg-[#1c1d1e] p-4 rounded-2xl border border-gray-150 dark:border-zinc-800 text-left text-xs font-sans space-y-2.5 select-none">
                <span className="font-mono text-[9px] text-amber-500 font-extrabold uppercase bg-amber-50 dark:bg-[#242526] px-2 py-0.5 rounded border border-amber-500/20">
                  Did you know?
                </span>
                <h4 className="text-xs font-black text-gray-900 dark:text-white leading-tight">
                  Tippers with synchronized pages gain 5x more syndicate followers
                </h4>
                <p className="text-[11px] text-gray-500 dark:text-gray-450 leading-relaxed font-normal">
                  Standard profiles are only seen by sports connections. Pages appear in the public <strong>Discover</strong> tab automatically, allowing players from any clan to join.
                </p>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
