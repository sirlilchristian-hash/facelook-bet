import React, { useState, useEffect } from "react";
import { 
  Home as HomeIcon, 
  Tv, 
  Users, 
  Gamepad2, 
  Search, 
  Menu, 
  Wallet, 
  Moon, 
  Sun, 
  MessageSquare, 
  Bell, 
  Lock, 
  Plus, 
  ThumbsUp, 
  Share2, 
  Send, 
  Sparkles, 
  Trophy, 
  Grid,
  ChevronRight,
  LogOut,
  Info,
  Settings, 
  CircleDot, 
  Smartphone,
  CheckCircle,
  HelpCircle,
  UserPlus,
  Compass,
  RefreshCw,
  TrendingUp,
  X,
  Copy,
  Link,
  Check,
  User,
  ChevronDown,
  ChevronUp,
  History,
  Bookmark,
  Film,
  Store,
  Gift,
  Calendar,
  Rss,
  Smile,
  CreditCard,
  Flag,
  Activity,
  MessageCircle,
  Camera,
  CheckCircle2,
  Heart,
  Star,
  UserCheck
} from "lucide-react";

// Sub-components
import WatchView from "./components/WatchView";
import GroupsView from "./components/GroupsView";
import PasswordModal from "./components/PasswordModal";
import FLPoolModal from "./components/FLPoolModal";
import InviteModal from "./components/InviteModal";
import GameHubModal from "./components/GameHubModal";
import WalletModal from "./components/WalletModal";
import AuthModal from "./components/AuthModal";
import ProfileView from "./components/ProfileView";

// Types
import { Match, Post, Friend, LookUptoParams, Group } from "./types";

export const PROFILES: Record<string, { name: string; type: "user" | "page"; avatar: string; desc: string }> = {
  "Collins Dnego": {
    name: "Collins Dnego",
    type: "user",
    avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff&bold=true",
    desc: "Elite LookUpto Bettor"
  },
  "Zephaniah Mwangi": {
    name: "Zephaniah Mwangi",
    type: "user",
    avatar: "https://ui-avatars.com/api/?name=Zephaniah+Mwangi&background=a855f7&color=fff&bold=true",
    desc: "Veteran Predictor Clan-Lead"
  },
  "Baridi SANA": {
    name: "Baridi SANA",
    type: "page",
    avatar: "https://ui-avatars.com/api/?name=Baridi+Sana&background=1877f2&color=fff&bold=true",
    desc: "Official News & Betting Pool"
  },
  "Collo Dnego": {
    name: "Collo Dnego",
    type: "page",
    avatar: "https://ui-avatars.com/api/?name=Collo+Dnego&background=059669&color=fff&bold=true",
    desc: "Managed Fan Club Page"
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "watch" | "groups" | "hub" | "profile" | "pages" | "memo">("home");
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("lookupto_dark_mode");
      if (saved !== null) {
        return saved === "true";
      }
    } catch (e) {
      // safe fallback
    }
    return false;
  });
  const [hamburgerOpen, setHamburgerOpen] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [menuExpanded, setMenuExpanded] = useState(false);
  const [pagesMenuOpen, setPagesMenuOpen] = useState(false);
  
  // Custom auth state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ phoneNumber?: string; email?: string; provider?: string } | null>(null);

  // Elevated LookGroups states for synchronization across sidebars & Group Wall
  const [activeGroupId, setActiveGroupId] = useState("g-1");
  const [createGroupModalOpen, setCreateGroupModalOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupCategory, setNewGroupCategory] = useState("Local Leagues");
  const [newGroupDescription, setNewGroupDescription] = useState("");
  const [newGroupCoverImage, setNewGroupCoverImage] = useState("");
  const [newGroupAvatar, setNewGroupAvatar] = useState("");

  // Interactive Facebook Popovers & Menu States
  const [launcherOpen, setLauncherOpen] = useState(false);
  const [messengerOpen, setMessengerOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  
  // Custom Popover sub-filters and interactive state variables
  const [notificationsFilterTab, setNotificationsFilterTab] = useState<"all" | "unread">("all");
  const [notifOptionsMenuOpen, setNotifOptionsMenuOpen] = useState(false);
  const [notificationList, setNotificationList] = useState([
    {
      id: "noti-spec-1",
      names: "Hon Amini O. Junior, Metrine Karandini and 1,071 other people",
      action: "liked your reel: \"Peter Selasysi...\"",
      time: "1m",
      read: true,
      category: "new",
      type: "like",
      avatar: "https://images.unsplash.com/photo-1544256718-3bcf237f3974?q=80&w=150"
    },
    {
      id: "noti-spec-2",
      names: "Erick Chelody, Hezz Jakoyugi and 3 others",
      action: "followed you.",
      time: "2h",
      read: true,
      category: "new",
      type: "follow",
      avatar: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=150"
    },
    {
      id: "noti-spec-3",
      names: "Ashôkâ Ïñçôginitä AI, Matrine Sakwa and Shims M Aggrey",
      action: "started following you from your suggested list.",
      time: "3h",
      read: false,
      category: "new",
      type: "follow",
      avatar: "https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=150"
    },
    {
      id: "noti-spec-4",
      names: "Samuel Werunga",
      action: "followed you.",
      time: "15h",
      read: false,
      category: "new",
      type: "follow_btn",
      avatar: "https://images.unsplash.com/photo-1500305060288-0f6d4b83002b?q=80&w=150"
    },
    {
      id: "noti-spec-5",
      names: "Wananda Dickson",
      action: "mentioned you and other followers in a comment.",
      time: "4h",
      read: false,
      category: "new",
      type: "mention",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=150"
    },
    {
      id: "noti-spec-6",
      names: "Wananda Dickson",
      action: "mentioned you and other followers in a comment.",
      time: "8h",
      read: false,
      category: "new",
      type: "mention",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=150"
    },
    // Earlier Section
    {
      id: "noti-spec-7",
      names: "Wananda Dickson",
      action: "mentioned you and other followers in his comments.",
      time: "18h",
      read: false,
      category: "earlier",
      type: "mention",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=150"
    },
    {
      id: "noti-spec-8",
      names: "Wananda Dickson",
      action: "mentioned you and other followers in a comment.",
      time: "18h",
      read: false,
      category: "earlier",
      type: "mention",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=150"
    }
  ]);

  const [samuelWerungaStatus, setSamuelWerungaStatus] = useState<"follow" | "following" | "dismissed">("follow");

  // Game Hub Modal States
  const [gameHubModalOpen, setGameHubModalOpen] = useState(false);
  const [selectedMatchForHub, setSelectedMatchForHub] = useState<Match | null>(null);
  const [showOtherLiveShortcuts, setShowOtherLiveShortcuts] = useState(false);

  // Inline Game Hub Visual States
  const [inlineHubTab, setInlineHubTab] = useState<"All Markets" | "Main" | "First Half" | "Goals" | "Cards and Corners">("All Markets");
  const [inlineHubCollapsed, setInlineHubCollapsed] = useState({
    oneXtwo: false,
    nextGoal: false,
    totalOverUnder: false,
    btts: false,
    corners: false,
  });

  // Resizable Challenge Window States
  const [challengeWindowOpen, setChallengeWindowOpen] = useState(false);
  const [challengeWindowData, setChallengeWindowData] = useState<{
    oppUser: string;
    oppStake: number;
    matchName: string;
    prediction: string;
  } | null>(null);
  const [challengeWindowWidth, setChallengeWindowWidth] = useState(550);
  const [challengeWindowHeight, setChallengeWindowHeight] = useState(480);
  const [isRequestingChange, setIsRequestingChange] = useState(false);
  const [requestedMarketInput, setRequestedMarketInput] = useState("");

  const startResize = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = challengeWindowWidth;
    const startHeight = challengeWindowHeight;

    const doDrag = (moveEvent: MouseEvent) => {
      const newWidth = Math.max(420, startWidth + (moveEvent.clientX - startX));
      const newHeight = Math.max(400, startHeight + (moveEvent.clientY - startY));
      setChallengeWindowWidth(newWidth);
      setChallengeWindowHeight(newHeight);
    };

    const stopDrag = () => {
      document.removeEventListener("mousemove", doDrag);
      document.removeEventListener("mouseup", stopDrag);
    };

    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
  };

  // Messenger Interactive states
  const [messengerSearchQuery, setMessengerSearchQuery] = useState("");
  const [messengerActiveTab, setMessengerActiveTab] = useState<"all" | "unread" | "groups" | "communities">("all");
  const [messengerPin, setMessengerPin] = useState(["", "", "", "", "", ""]);
  const [messengerUnlocked, setMessengerUnlocked] = useState(false);
  const [messengerChats, setMessengerChats] = useState([
    { id: "msg-1", name: "Margaret Wainoi", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "4w", color: "bg-pink-500", status: "offline" },
    { id: "msg-2", name: "Mercy Mutiso", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "4w", color: "bg-amber-500", status: "offline" },
    { id: "msg-3", name: "Sushy Macha", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "4w", color: "bg-teal-500", status: "offline" },
    { id: "msg-4", name: "Cheru Too Faith", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "4w", color: "bg-sky-500", status: "offline" },
    { id: "msg-5", name: "Mamake Alex", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "2h", color: "bg-indigo-500", status: "online" },
    { id: "msg-6", name: "Dantez Demaish", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "5h", color: "bg-rose-500", status: "online" },
    { id: "msg-7", name: "Abuu Kiprotich", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "1d", color: "bg-emerald-500", status: "online" },
    { id: "msg-8", name: "Emily Shee", text: "Messages and calls are secured with end-to-end encryption. Only people in this chat can read them.", time: "3d", color: "bg-purple-500", status: "online" }
  ]);

  // App Launcher interactive states
  const [launcherSearch, setLauncherSearch] = useState("");

  // Switchable page profiles for the Profile switcher dropdown
  const [activeProfilePage, setActiveProfilePage] = useState("Collins Dnego");

  // Tagging & Saved States
  const [tagModalOpen, setTagModalOpen] = useState(false);
  const [composerTaggedFriends, setComposerTaggedFriends] = useState<string[]>([]);
  const [savedItems, setSavedItems] = useState([
    { id: "s1", type: "post", title: "Saved post from Alex Morgan: Thanks for the great business on the Chelsea vs Arsenal bet!", date: "Yesterday", thumb: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=400&q=80" },
    { id: "s2", type: "memo", title: "Success Memo: Look-upto engine win", date: "2 days ago", thumb: "https://images.unsplash.com/photo-1518605368461-1e2474f8846c?w=400&q=80" },
    { id: "s3", type: "video", title: "Reel: Mashemeji Derby Highlights", date: "1 week ago", icon: "Tv" },
  ]);

  // ⭐ AI Chat State
  const [nyotaChatOpen, setNyotaChatOpen] = useState(false);
  const [nyotaMessages, setNyotaMessages] = useState<{role: 'user'|'model', content: string}[]>([
    { role: 'model', content: "Hello! I am ⭐ AI. How can I help you with FaceLook Bet, betting inquiries, research, generating pictures, or anything else today?" }
  ]);
  const [nyotaInput, setNyotaInput] = useState("");
  const [nyotaLoading, setNyotaLoading] = useState(false);

  const handleMemoPhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMemoIsCompressing(true);
      // Simulate photo compression and validation
      setTimeout(() => {
        setMemoIsCompressing(false);
        setMemoComposePhoto(URL.createObjectURL(file));
      }, 1500);
    }
  };

  const handleMemoSubmit = () => {
    if (!memoComposePhoto || !memoComposeText.trim()) {
      alert("A memo MUST be accompanied by a high-quality camera photo and a description.");
      return;
    }
    
    const newMemo = {
      id: `m-${Date.now()}`,
      author: activeProfilePage,
      type: memoComposeType,
      text: memoComposeText,
      photo: memoComposePhoto,
      timestamp: "Just now",
      tagged: memoComposeTagged.trim() !== "" ? memoComposeTagged : undefined
    };
    
    setMemos([newMemo, ...memos]);
    setMemoFeedMode("feed");
    setMemoComposeText("");
    setMemoComposePhoto(null);
    setMemoComposeTagged("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleDropdown = (dropdown: "launcher" | "messenger" | "notifications" | "profile") => {
    setLauncherOpen(dropdown === "launcher" ? !launcherOpen : false);
    setMessengerOpen(dropdown === "messenger" ? !messengerOpen : false);
    setNotificationsOpen(dropdown === "notifications" ? !notificationsOpen : false);
    setProfileMenuOpen(dropdown === "profile" ? !profileMenuOpen : false);
  };

  const handleSaveItem = (itemType: string, itemContent: string, thumb?: string) => {
    setSavedItems([{
      id: `s-${Date.now()}`,
      type: itemType,
      title: itemContent,
      date: "Just now",
      thumb,
      icon: itemType === "video" ? "Tv" : undefined
    }, ...savedItems]);
    alert("Saved to your collection.");
  };

  const handleNyotaSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!nyotaInput.trim() || nyotaLoading) return;

    const userMessage = { role: 'user' as const, content: nyotaInput };
    setNyotaMessages(prev => [...prev, userMessage]);
    setNyotaInput("");
    setNyotaLoading(true);

    try {
      const response = await fetch("/api/nyota-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...nyotaMessages, userMessage] })
      });
      const data = await response.json();
      setNyotaMessages(prev => [...prev, { role: 'model', content: data.reply }]);
    } catch (err) {
      setNyotaMessages(prev => [...prev, { role: 'model', content: "My connection to the server was interrupted. Please try again." }]);
    } finally {
      setNyotaLoading(false);
    }
  };

  const handlePinChange = (idx: number, value: string) => {
    const updated = [...messengerPin];
    updated[idx] = value;
    setMessengerPin(updated);

    // Focus next pin box
    if (value && idx < 5) {
      const nextBox = document.getElementById(`msg-pin-${idx + 1}`);
      if (nextBox) (nextBox as HTMLInputElement).focus();
    }

    // Try to auto lock/unlock
    if (updated.every(v => v !== "")) {
      setMessengerUnlocked(true);
      alert("🔒 Congratulations! Secure PIN recognized. Encrypted conversations have been decrypted successfully!");
    }
  };

  const [notifications, setNotifications] = useState<Array<{ id: string; text: string; time: string; read: boolean }>>([
    { id: "noti-1", text: "You have been elected as Co-Admin of Mashemeji Derby Clan (Ligi Bigi)!", time: "1 hour ago", read: false },
    { id: "noti-2", text: "Marcus_88 launched Premier League High Rollers Syndicate Pool #1", time: "2 hours ago", read: false },
    { id: "noti-3", text: "Welcome to Zero House Edge Syndicate! Click members count to invite partners.", time: "1 day ago", read: true }
  ]);
  const [groups, setGroups] = useState<Group[]>([
    {
      id: "g-1",
      name: "Premier League High Rollers Syndicate",
      avatar: "https://ui-avatars.com/api/?name=Premier+League+High+Rollers+Syndicate&background=e91e63&color=fff",
      coverImage: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1200",
      membersCount: 14205,
      description: "A private club composed exclusively of high liability look-upto matchers. Zero house margins, pure mathematical calculations only. Join active syndicates!",
      posts: [
        {
          id: "gp-1",
          author: "Marcus_88",
          avatar: "https://ui-avatars.com/api/?name=Marcus&background=9c27b0&color=fff",
          time: "10 mins ago",
          content: "Just loaded the global pool for Man City vs Arsenal. I'm taking Man City to secure the win. Sponsoring 5 sendoffs of $100 each. Get in while the lookupto is open!",
          likes: 38,
          comments: [
            { author: "crypto_expert", content: "Already backed you on 2 spots. Ratios are beautiful.", time: "8 mins ago" }
          ]
        }
      ]
    },
    {
      id: "g-2",
      name: "Mashemeji Derby Clan (Ligi Bigi)",
      avatar: "https://ui-avatars.com/api/?name=Mashemeji+Derby&background=4caf50&color=fff",
      coverImage: "https://images.unsplash.com/photo-1518063319789-7217e6706b04?q=80&w=1200",
      membersCount: 8430,
      description: "The home of local tier sports betting, focused entirely on Ligi Bigi, Mashemeji Derbies, and Gor Mahia vs AFC Leopards insights.",
      posts: [
        {
          id: "gp-2",
          author: "Collins Dnego",
          avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff",
          time: "1 hour ago",
          content: "Ligi Bigi Mashemeji derby is crazy! 1-1 right now. Gor Mahia must score, AFC leopards middle defense has deep gaps. Anyone going P2P?",
          likes: 42,
          comments: []
        }
      ]
    },
    {
      id: "g-3",
      name: "Zero House Edge Syndicate",
      avatar: "https://ui-avatars.com/api/?name=Zero+Edge&background=2196f3&color=fff",
      coverImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1200",
      membersCount: 22100,
      description: "No bookmakers, no hidden juice, no losses to the middleman. Community-voted peer-to-peer matched pools with mathematical ratios.",
      posts: []
    }
  ]);

  // Real sports live/upcoming matches loaded dynamically
  const [matches, setMatches] = useState<Match[]>([]);
  const [isFeedLoading, setIsFeedLoading] = useState(false);
  const [selectedHubSport, setSelectedHubSport] = useState("Soccer");
  const [selectedMatchForEscrowPool, setSelectedMatchForEscrowPool] = useState<Match | null>(null);

  // Memo Tab State
  const [memoFeedMode, setMemoFeedMode] = useState<"feed" | "compose">("feed");
  const [memoComposeType, setMemoComposeType] = useState<"fundraising" | "thanksgiving" | "success">("success");
  const [memoComposeText, setMemoComposeText] = useState("");
  const [memoComposePhoto, setMemoComposePhoto] = useState<string | null>(null);
  const [memoComposeTagged, setMemoComposeTagged] = useState<string>("");
  const [memoIsCompressing, setMemoIsCompressing] = useState(false);
  const [memos, setMemos] = useState<{id: string; author: string; type: string; text: string; photo: string; timestamp: string; tagged?: string}[]>([
    {
      id: "m-1",
      author: "Alex Morgan",
      type: "thanksgiving",
      text: "Thanks for the great business on the Chelsea vs Arsenal bet! You honored the escrow perfectly.",
      photo: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=400&q=80",
      timestamp: "2 hours ago",
      tagged: "Collins Dnego"
    },
    {
      id: "m-2",
      author: "Sarah Chen",
      type: "success",
      text: "Secured a massive win using the Look-upto engine! Grateful for this amazing platform.",
      photo: "https://images.unsplash.com/photo-1518605368461-1e2474f8846c?w=400&q=80",
      timestamp: "5 hours ago"
    }
  ]);

  // Authentication Pin locks
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [authReturnAction, setAuthReturnAction] = useState<"wallet" | "interactions" | null>(null);
  const [interactionsUnlocked, setInteractionsUnlocked] = useState(false);

  // General Escrow Modals
  const [flModalOpen, setFlModalOpen] = useState(false);
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [walletModalOpen, setWalletModalOpen] = useState(false);

  // States for user funds & transaction history
  const [walletBalance, setWalletBalance] = useState<number>(1500.00);
  const [transactions, setTransactions] = useState<Array<{ id: string; type: "deposit" | "withdraw" | "bet_stake" | "bet_win"; amount: number; time: string; target: string }>>([
    { id: "tx-1", type: "deposit", amount: 1500.00, time: "Just now", target: "Free Virtual Signup Credits" }
  ]);

  // Selected live watch simulator match
  const [watchSelectedMatch, setWatchSelectedMatch] = useState<Match | null>(null);

  // Open-ended Search prompt (connected to search-grounded tips!)
  const [searchPrompt, setSearchPrompt] = useState("");
  const [searchResponse, setSearchResponse] = useState("");
  const [isSearchLoading, setIsSearchLoading] = useState(false);

  // Ratio-Engine inputs
  const [ratioOpponent, setRatioOpponent] = useState<Friend | null>(null);
  const [ratioMatchName, setRatioMatchName] = useState("");
  const [ratioOddName, setRatioOddName] = useState("");
  const [ratioOddValue, setRatioOddValue] = useState<number>(0);
  const [ratioTotalPool, setRatioTotalPool] = useState<number>(100);
  const [sendoffsCount, setSendoffsCount] = useState<number>(1);
  const [isSendoffEnabled, setIsSendoffEnabled] = useState(false);
  const [postToGlobal, setPostToGlobal] = useState(false);
  const [ratioMatch, setRatioMatch] = useState<Match | null>(null);
  const [ratioSelection, setRatioSelection] = useState<"1" | "X" | "2">("1");
  const [numOpponents, setNumOpponents] = useState<1 | 2>(1);
  const [opponentSelection, setOpponentSelection] = useState<"1" | "X" | "2">("X");

  const [composerText, setComposerText] = useState("");
  const [isRatioEscrowCollapsed, setIsRatioEscrowCollapsed] = useState(false);

  // Game Hub custom Hamburger Menu states
  const [isHubMenuOpen, setIsHubMenuOpen] = useState(false);
  const [hubActiveFilter, setHubActiveFilter] = useState<string>("all");
  const [hubExpandedCountry, setHubExpandedCountry] = useState<string | null>(null);
  const [hubExpandedLeagueRanking, setHubExpandedLeagueRanking] = useState<string | null>(null);

  // Friends list with live activities
  const [friendsList] = useState<Friend[]>([
    { id: "fr-1", name: "David T.", avatar: "https://ui-avatars.com/api/?name=David+T&background=ff5722&color=fff", status: "online", mutualFriends: 12 },
    { id: "fr-2", name: "Sarah L.", avatar: "https://ui-avatars.com/api/?name=Sarah+L&background=4caf50&color=fff", status: "online", mutualFriends: 8 },
    { id: "fr-3", name: "Michael B.", avatar: "https://ui-avatars.com/api/?name=Michael+B&background=e91e63&color=fff", status: "idle", mutualFriends: 15 },
    { id: "fr-4", name: "Emma W.", avatar: "https://ui-avatars.com/api/?name=Emma+W&background=3f51b5&color=fff", status: "offline", mutualFriends: 3 }
  ]);

  // Unified community feed posts has state for likes/comments
  const [feedPosts, setFeedPosts] = useState<Post[]>([]);

  // League Rankings/Standings data for the countries/leagues directory dropdowns
  const leagueStandings: Record<string, Array<{ pos: number; team: string; played: number; points: number; form: string[] }>> = {
    "English Premier League": [
      { pos: 1, team: "Arsenal", played: 34, points: 77, form: ["W", "W", "L", "W", "W"] },
      { pos: 2, team: "Manchester City", played: 33, points: 76, form: ["W", "W", "W", "W", "W"] },
      { pos: 3, team: "Liverpool", played: 34, points: 74, form: ["D", "L", "W", "D", "W"] },
      { pos: 4, team: "Manchester United", played: 34, points: 68, form: ["W", "W", "W", "D", "L"] },
      { pos: 5, team: "Chelsea", played: 34, points: 64, form: ["W", "L", "W", "W", "D"] },
    ],
    "Spanish La Liga": [
      { pos: 1, team: "Real Madrid", played: 34, points: 84, form: ["W", "W", "W", "W", "W"] },
      { pos: 2, team: "Barcelona", played: 34, points: 73, form: ["W", "L", "W", "L", "W"] },
      { pos: 3, team: "Girona", played: 34, points: 71, form: ["W", "W", "W", "W", "L"] },
      { pos: 4, team: "Atletico Madrid", played: 34, points: 64, form: ["W", "W", "L", "W", "W"] },
    ],
    "Kenya Premier League (Ligi Bigi)": [
      { pos: 1, team: "Gor Mahia", played: 28, points: 60, form: ["W", "W", "D", "W", "W"] },
      { pos: 2, team: "Kenya Police", played: 28, points: 51, form: ["W", "D", "W", "W", "D"] },
      { pos: 3, team: "Tusker FC", played: 28, points: 49, form: ["L", "W", "W", "L", "W"] },
      { pos: 4, team: "AFC Leopards", played: 28, points: 47, form: ["W", "W", "W", "D", "D"] },
    ],
    "NBA Playoffs": [
      { pos: 1, team: "Boston Celtics", played: 82, points: 64, form: ["W", "W", "W", "L", "W"] },
      { pos: 2, team: "Dallas Mavericks", played: 82, points: 50, form: ["W", "W", "W", "W", "L"] },
      { pos: 3, team: "New York Knicks", played: 82, points: 50, form: ["W", "W", "L", "W", "L"] },
      { pos: 4, team: "LA Lakers", played: 82, points: 47, form: ["L", "L", "W", "L", "W"] },
    ],
    "German Bundesliga": [
      { pos: 1, team: "Bayer Leverkusen", played: 32, points: 84, form: ["W", "D", "D", "W", "W"] },
      { pos: 2, team: "Bayern Munich", played: 32, points: 69, form: ["L", "W", "W", "W", "L"] },
      { pos: 3, team: "VfB Stuttgart", played: 32, points: 67, form: ["W", "L", "D", "W", "W"] },
    ],
    "Italian Serie A": [
      { pos: 1, team: "Inter Milan", played: 34, points: 89, form: ["W", "W", "D", "W", "W"] },
      { pos: 2, team: "AC Milan", played: 34, points: 70, form: ["D", "L", "D", "L", "W"] },
      { pos: 3, team: "Juventus", played: 34, points: 65, form: ["D", "D", "D", "W", "D"] },
    ]
  };

  const getCountryForLeague = (league: string): string => {
    const l = (league || "").toLowerCase();
    if (l.includes("english") || l.includes("premier league") || l.includes("manchester") || l.includes("chelsea") || l.includes("arsenal")) {
      if (l.includes("kenya")) return "Kenya";
      return "England";
    }
    if (l.includes("la liga") || l.includes("spanish") || l.includes("real madrid") || l.includes("barcelona") || l.includes("girona")) return "Spain";
    if (l.includes("serie a") || l.includes("italian") || l.includes("inter milan") || l.includes("juventus")) return "Italy";
    if (l.includes("bundesliga") || l.includes("german") || l.includes("bayern") || l.includes("leverkusen")) return "Germany";
    if (l.includes("kenya") || l.includes("ligi bigi") || l.includes("kpl") || l.includes("gor mahia") || l.includes("afc leopard")) return "Kenya";
    if (l.includes("nba") || l.includes("playoff") || l.includes("basketball") || l.includes("celtics") || l.includes("lakers") || l.includes("mavericks")) return "USA";
    return "International";
  };

  // Helper computes the matches that qualify under active Filters
  const getFilteredMatches = () => {
    return matches.filter((m) => {
      if (hubActiveFilter === "highlights") {
        return m.flActiveCount > 1300; // Match count representing our active stakers threshold
      }
      if (hubActiveFilter === "upcoming") {
        return m.status === "UPCOMING";
      }
      if (hubActiveFilter === "live") {
        return m.status === "LIVE";
      }
      if (hubActiveFilter.startsWith("league:")) {
        const targetLeague = hubActiveFilter.replace("league:", "");
        return m.league && m.league.toLowerCase().trim() === targetLeague.toLowerCase().trim();
      }
      if (hubActiveFilter.startsWith("country:")) {
        const targetCountry = hubActiveFilter.replace("country:", "");
        return getCountryForLeague(m.league).toLowerCase().trim() === targetCountry.toLowerCase().trim();
      }
      
      // Default: show currently selected sport tabs in standard Soccer, Basketball...
      const sportKey = selectedHubSport === "Soccer" ? "Football" : selectedHubSport;
      return m.sport?.toLowerCase() === sportKey.toLowerCase() || m.sport === sportKey;
    });
  };

  // Fetch real-world up-to-the-minute games and upcoming matches
  const fetchRealSportsGames = async () => {
    setIsFeedLoading(true);
    try {
      const response = await fetch("/api/sports-feed?league=Premier League & Champions League & World Cup");
      const data = await response.json();
      if (data && data.matches) {
        setMatches(data.matches);
        // Default the watching game target to the first active live match if not selected yet
        const liveMatch = data.matches.find((m: Match) => m.status === "LIVE");
        if (liveMatch) {
          setWatchSelectedMatch(liveMatch);
        }
      }
    } catch (err) {
      console.error("Error loading sports games:", err);
    } finally {
      setIsFeedLoading(false);
    }
  };

  // Load social posts feed
  const fetchSocialPostsFeed = async () => {
    try {
      const response = await fetch("/api/generate-posts");
      const data = await response.json();
      if (data && data.posts) {
        setFeedPosts(data.posts);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchRealSportsGames();
    fetchSocialPostsFeed();
  }, []);

  // Theme support: React reactive system with automatic state synchronization and DOM manipulation
  useEffect(() => {
    const html = document.documentElement;
    if (isDarkMode) {
      html.setAttribute("data-theme", "dark");
      html.classList.add("dark");
    } else {
      html.setAttribute("data-theme", "light");
      html.classList.remove("dark");
    }
    try {
      localStorage.setItem("lookupto_dark_mode", String(isDarkMode));
    } catch (e) {
      // safe fallback
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
  };

  // Auth unlock callback
  const handleAuthSuccess = () => {
    if (authReturnAction === "wallet") {
      setWalletModalOpen(true);
    } else if (authReturnAction === "interactions") {
      setInteractionsUnlocked(true);
    }
  };

  // Trigger PIN modal
  const triggerPinCheck = (action: "wallet" | "interactions") => {
    if (action === "interactions" && interactionsUnlocked) {
      return;
    }
    setAuthReturnAction(action);
    setPasswordModalOpen(true);
  };

  // Create Group Submit handler
  const handleCreateGroupSubmit = () => {
    if (!newGroupName.trim()) {
      return;
    }

    const defaultCover = "https://images.unsplash.com/photo-1540747737956-37872404a82f?q=80&w=1200";
    const defaultAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(newGroupName)}&background=3b82f6&color=fff`;

    const created: Group = {
      id: "g-" + Date.now(),
      name: newGroupName.trim(),
      category: newGroupCategory,
      description: newGroupDescription.trim() || "A customized private sports betting syndicate club with matched liabilities.",
      coverImage: newGroupCoverImage.trim() || defaultCover,
      avatar: newGroupAvatar.trim() || defaultAvatar,
      membersCount: 1, // You are the founder
      posts: []
    };

    setGroups([...groups, created]);
    setActiveGroupId(created.id);
    setActiveTab("groups");
    setCreateGroupModalOpen(false);

    // Reset fields
    setNewGroupName("");
    setNewGroupCategory("Local Leagues");
    setNewGroupDescription("");
    setNewGroupCoverImage("");
    setNewGroupAvatar("");

    setNotifications(prev => [
      { id: `noti-${Date.now()}`, text: `Successfully created and launched group: "${created.name}"`, time: "Just now", read: false },
      ...prev
    ]);
  };

  // Select an opponent for 1v1 lookupto
  const handleSelectOpponent = (fr: Friend) => {
    if (!interactionsUnlocked) {
      triggerPinCheck("interactions");
      return;
    }
    setRatioOpponent(fr);
    setComposerText(`Hey @${fr.name}, I am challenging you to a ratio bet! Let's lock in.`);
  };

  // Select Live Odd selection triggering P2P calculation immediately
  const handleSelectOdd = (m: Match, oddName: string, oddValue: number) => {
    setRatioMatch(m);
    setRatioMatchName(`${m.homeTeam} vs ${m.awayTeam}`);
    setRatioOddName(oddName);
    setRatioOddValue(oddValue);
    setIsRatioEscrowCollapsed(false);
    
    // Choose selection mapping
    if (oddName === m.homeTeam) {
      setRatioSelection("1");
      setOpponentSelection("X");
    } else if (oddName === "Draw") {
      setRatioSelection("X");
      setOpponentSelection("2");
    } else {
      setRatioSelection("2");
      setOpponentSelection("1");
    }
    
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Post Open / Lookupto Bet Challenge dynamically on the social feed
  const handlePostBetChallenge = () => {
    if (!ratioMatchName || !ratioOddName || ratioOddValue <= 0) {
      alert("Please select a live match odd from the widget or Sports hub center first.");
      return;
    }

    const creatorRatio = getCreatorRatio();
    const creatorStake = getCreatorStake();
    const opponentLiability = getOpponentLiability();
    const marketingExpense = isSendoffEnabled ? ratioTotalPool * 0.01 : 0;
    const totalRequired = creatorStake + marketingExpense;

    if (walletBalance < totalRequired) {
      alert(`Your wallet balance ($${walletBalance.toFixed(2)}) is insufficient to cover your portion of this look-upto pool ($${creatorStake.toFixed(2)})${isSendoffEnabled ? ` and the 1% sendoff global marketing expense ($${marketingExpense.toFixed(2)}). Total: $${totalRequired.toFixed(2)}` : ''}. Fund your wallet first.`);
      return;
    }

    // Deduct creator stake and marketing fee, log transaction
    setWalletBalance((prev) => prev - totalRequired);
    const txId = `tx-${Date.now()}`;
    const newTxList: Array<{ id: string; type: "deposit" | "withdraw" | "bet_stake" | "bet_win"; amount: number; time: string; target: string }> = [
      {
        id: txId,
        type: "bet_stake",
        amount: creatorStake,
        time: "Just now",
        target: `Ratio Bet Slip: ${ratioMatchName}`,
      }
    ];

    if (marketingExpense > 0) {
      newTxList.push({
        id: `tx-mkt-${Date.now()}`,
        type: "withdraw" as const,
        amount: marketingExpense,
        time: "Just now",
        target: `1% Sendoff Global Channel Marketing Fee (${isSendoffEnabled ? sendoffsCount * 5 : 1} positions)`,
      });
    }

    setTransactions([...newTxList, ...transactions]);

    const newPost: Post = {
      id: `p-${Date.now()}`,
      author: "Collins Dnego (You)",
      avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff",
      time: "Just now",
      content: composerText || `Just proposed an open peer-to-peer challenge ticket! Calculated ratio-stakes holding. Who's backing my opponent?`,
      likes: 0,
      comments: [],
      isGlobalChannel: isSendoffEnabled && postToGlobal,
      betCard: {
        match: ratioMatchName,
        type: `Ratio Challenge: ${ratioOddName} (@${ratioOddValue.toFixed(2)})`,
        prediction: ratioOddName,
        odds: ratioOddValue,
        totalPool: ratioTotalPool,
        stakes: { creator: parseFloat(creatorStake.toFixed(2)), opponents: parseFloat(opponentLiability.toFixed(2)) },
        status: "OPEN",
      },
    };

    setFeedPosts([newPost, ...feedPosts]);
    setComposerText("");
    
    // Reset Engine variables
    setRatioMatchName("");
    setRatioOddName("");
    setRatioOddValue(0);
    setRatioOpponent(null);

    // Bounce home
    setActiveTab("home");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Join/Match peer-to-peer liability posted by others
  const handleAcceptBetFromPost = (post: Post) => {
    if (!post.betCard) return;
    const stakeRequired = post.betCard.stakes.opponents;
    const totalTax = post.betCard.totalPool * 0.02;
    
    // In handleAcceptBetFromPost, the user takes the entire opponent side of the match, 
    // so they pay the entire tax amount as the sole opponent for this match.
    const opponentTax = totalTax;
    const totalRequiredToPay = stakeRequired + opponentTax;

    if (walletBalance < totalRequiredToPay) {
      alert(`Insufficient funds. This challenge requires matching a liability stake of $${stakeRequired.toFixed(2)} + $${opponentTax.toFixed(2)} Org Tax.`);
      return;
    }

    // Deduct
    setWalletBalance((prev) => prev - totalRequiredToPay);
    setTransactions([
      {
        id: `tx-${Date.now()}`,
        type: "bet_stake",
        amount: stakeRequired,
        time: "Just now",
        target: `Matched P2P Challenge with @${post.author}`,
      },
      {
        id: `tx-tax-${Date.now()}`,
        type: "withdraw" as const,
        amount: opponentTax,
        time: "Just now",
        target: `Org. Escrow Tax (2% full hold)`,
      },
      ...transactions,
    ]);

    // Update Post Bet Card to matched status
    setFeedPosts(feedPosts.map((p) => {
      if (p.id === post.id && p.betCard) {
        return {
          ...p,
          betCard: {
            ...p.betCard,
            status: "MATCHED",
          },
        };
      }
      return p;
    }));

    alert(`Challenge Accepted! You matched @${post.author}'s P2P bet for $${stakeRequired.toFixed(2)}. Escrow contract is active.`);
  };

  // accepting bid from the FL Escrow modal
  const handleMatchFromFlModal = (oppUser: string, oppStake: number, matchName: string, prediction: string) => {
    // Open the resizable challenge window instead of immediate debit
    setChallengeWindowData({ oppUser, oppStake, matchName, prediction });
    setIsRequestingChange(false);
    setRequestedMarketInput("");
    setChallengeWindowOpen(true);
  };

  // Invite buddies and lock stakes
  const handleInviteFriendsCallback = (invitedCount: number, friends: string[]) => {
    const creatorRatio = getCreatorRatio();
    const costPerMatch = ratioTotalPool * creatorRatio;
    const matchedMultiplier = isSendoffEnabled ? sendoffsCount * 5 : 1;
    const totalHeldCost = costPerMatch * matchedMultiplier;
    const marketingExpense = isSendoffEnabled ? ratioTotalPool * 0.01 : 0;
    const totalRequired = totalHeldCost + marketingExpense;

    if (walletBalance < totalRequired) {
      alert(`The requested Sendoff parameters requires $${totalRequired.toFixed(2)} total hold ($${totalHeldCost.toFixed(2)} stakes + $${marketingExpense.toFixed(2)} global channels promo fee), but you only have $${walletBalance.toFixed(2)}.`);
      return;
    }

    setWalletBalance((prev) => prev - totalRequired);
    const newTxList: Array<{ id: string; type: "deposit" | "withdraw" | "bet_stake" | "bet_win"; amount: number; time: string; target: string }> = [
      {
        id: `tx-${Date.now()}`,
        type: "bet_stake",
        amount: totalHeldCost,
        time: "Just now",
        target: `Sendoff Friends Challenge: Sponsoring ${matchedMultiplier} matches`,
      }
    ];

    if (marketingExpense > 0) {
      newTxList.push({
        id: `tx-mkt-${Date.now()}`,
        type: "withdraw" as const,
        amount: marketingExpense,
        time: "Just now",
        target: `1% Sendoff Global Channel Marketing Fee (${invitedCount} invited)`,
      });
    }

    setTransactions([...newTxList, ...transactions]);

    // Create a feed post with isGlobalChannel too if postToGlobal is enabled on sendoff!
    const newPost: Post = {
      id: `p-inv-${Date.now()}`,
      author: "Collins Dnego (You)",
      avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff",
      time: "Just now",
      content: composerText || `Just proposed an invite-only peer-to-peer challenge to my circle of ${friends.join(", ")}! Sponsoring ${matchedMultiplier} sendoff matches on: ${ratioMatchName || "Match Prediction"}. Join the escrow now!`,
      likes: 0,
      comments: [],
      isGlobalChannel: isSendoffEnabled && postToGlobal,
      betCard: {
        match: ratioMatchName || "Direct Invitation Event",
        type: `Friends Invite Challenge: ${ratioOddName || "Match Prediction"}`,
        prediction: ratioOddName || "Selected Prediction",
        odds: ratioOddValue || 2.0,
        totalPool: ratioTotalPool,
        stakes: { creator: parseFloat(totalHeldCost.toFixed(2)), opponents: parseFloat((ratioTotalPool - costPerMatch).toFixed(2)) },
        status: "OPEN",
      },
    };

    setFeedPosts([newPost, ...feedPosts]);
    setComposerText("");

    alert(`Challenges proposal sent to ${invitedCount} friends! Co-stake contract was initialized, locking $${totalHeldCost.toFixed(2)} in virtual assets${marketingExpense > 0 ? ` and $${marketingExpense.toFixed(2)} marketing fee deducted.` : '.'}`);
  };

  // Submit standard social posts from our Composer
  const handlePublishStandardPost = () => {
    if (!composerText.trim()) return;

    const standardPost: Post = {
      id: `std-p-${Date.now()}`,
      author: "Collins Dnego (You)",
      avatar: "https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff",
      time: "Just now",
      content: composerText,
      likes: 0,
      comments: [],
    };

    setFeedPosts([standardPost, ...feedPosts]);
    setComposerText("");
  };

  // Like a social post
  const handleLikePost = (postId: string) => {
    setFeedPosts(feedPosts.map((p) => {
      if (p.id === postId) {
        const liked = !p.hasLiked;
        return {
          ...p,
          likes: liked ? p.likes + 1 : p.likes - 1,
          hasLiked: liked,
        };
      }
      return p;
    }));
  };

  // Submit search query directly to automated crawler with Gemini search groundings
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchPrompt.trim()) return;

    setIsSearchLoading(true);
    setSearchResponse("");
    try {
      // Prompt server to generate real insights
      const response = await fetch("/api/sports-feed?league=" + encodeURIComponent(searchPrompt));
      const data = await response.json();
      if (data && data.matches && data.matches.length > 0) {
        setMatches(data.matches);
        setSearchResponse(`Found ${data.matches.length} matches currently scheduled or active. Check the Sports Hub center!`);
      } else {
        setSearchResponse("We looked up current schedules, but found no active matches matching that criteria in the instant feed. Loading default schedules.");
      }
    } catch {
      setSearchResponse("Failed to establish sync with external sports APIs. Serving cached odds and simulations.");
    } finally {
      setIsSearchLoading(false);
    }
  };

  // LookUpto Engine calculations based on user inputs
  const calculateLookuptoStakes = () => {
    // We fall back to standard odds if ratioMatch is null
    const odds1 = ratioMatch?.odds["1"] ?? 2.0;
    const oddsX = ratioMatch?.odds.X ?? 3.0;
    const odds2 = ratioMatch?.odds["2"] ?? 4.0;

    if (numOpponents === 2) {
      // 3 outcomes total (Creator + 2 opponents)
      let userOddsVal = odds1;
      let opp1OddsVal = oddsX;
      let opp2OddsVal = odds2;

      let userSelName = "Home Win";
      let opp1SelName = "Draw";
      let opp2SelName = "Away Win";

      if (ratioSelection === "1") {
        userOddsVal = odds1; userSelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        opp1OddsVal = oddsX; opp1SelName = "Draw";
        opp2OddsVal = odds2; opp2SelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
      } else if (ratioSelection === "X") {
        userOddsVal = oddsX; userSelName = "Draw";
        opp1OddsVal = odds1; opp1SelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        opp2OddsVal = odds2; opp2SelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
      } else if (ratioSelection === "2") {
        userOddsVal = odds2; userSelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
        opp1OddsVal = odds1; opp1SelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        opp2OddsVal = oddsX; opp2SelName = "Draw";
      }

      // Inverse probability ratio formula
      const ipUser = userOddsVal > 0 ? 1 / userOddsVal : 0;
      const ipOpp1 = opp1OddsVal > 0 ? 1 / opp1OddsVal : 0;
      const ipOpp2 = opp2OddsVal > 0 ? 1 / opp2OddsVal : 0;
      const totalIp = ipUser + ipOpp1 + ipOpp2;

      const userPctVal = totalIp > 0 ? (ipUser / totalIp) * 100 : 0;
      const opp1PctVal = totalIp > 0 ? (ipOpp1 / totalIp) * 100 : 0;
      const opp2PctVal = totalIp > 0 ? (ipOpp2 / totalIp) * 100 : 0;

      const userStakeVal = (userPctVal / 100) * ratioTotalPool;
      const opp1StakeVal = (opp1PctVal / 100) * ratioTotalPool;
      const opp2StakeVal = (opp2PctVal / 100) * ratioTotalPool;

      return {
        userPct: userPctVal,
        userStake: userStakeVal,
        userSelection: ratioSelection,
        userSelectionName: userSelName,
        userOdds: userOddsVal,
        opponentsCount: 2,
        opponents: [
          { name: "Opponent A", pct: opp1PctVal, stake: opp1StakeVal, selection: ratioSelection === "1" ? "X" : "1" as "1"|"X"|"2", selectionName: opp1SelName, odds: opp1OddsVal },
          { name: "Opponent B", pct: opp2PctVal, stake: opp2StakeVal, selection: ratioSelection === "2" ? "X" : "2" as "1"|"X"|"2", selectionName: opp2SelName, odds: opp2OddsVal }
        ]
      };
    } else {
      // 1 opponent only (User vs 1 Opponent choice)
      let userOddsVal = odds1;
      let oppOddsVal = oddsX;

      let userSelName = "Home Win";
      let oppSelName = "Draw";

      if (ratioSelection === "1") {
        userOddsVal = odds1; userSelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        if (opponentSelection === "X") {
          oppOddsVal = oddsX; oppSelName = "Draw";
        } else {
          oppOddsVal = odds2; oppSelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
        }
      } else if (ratioSelection === "X") {
        userOddsVal = oddsX; userSelName = "Draw";
        if (opponentSelection === "1") {
          oppOddsVal = odds1; oppSelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        } else {
          oppOddsVal = odds2; oppSelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
        }
      } else {
        userOddsVal = odds2; userSelName = ratioMatch ? ratioMatch.awayTeam : "Away Win";
        if (opponentSelection === "1") {
          oppOddsVal = odds1; oppSelName = ratioMatch ? ratioMatch.homeTeam : "Home Win";
        } else {
          oppOddsVal = oddsX; oppSelName = "Draw";
        }
      }

      // Inverse probability ratio formula
      const ipUser = userOddsVal > 0 ? 1 / userOddsVal : 0;
      const ipOpp = oppOddsVal > 0 ? 1 / oppOddsVal : 0;
      const totalIp = ipUser + ipOpp;

      const userPctVal = totalIp > 0 ? (ipUser / totalIp) * 100 : 0;
      const oppPctVal = totalIp > 0 ? (ipOpp / totalIp) * 100 : 0;

      const userStakeVal = (userPctVal / 100) * ratioTotalPool;
      const oppStakeVal = (oppPctVal / 100) * ratioTotalPool;

      return {
        userPct: userPctVal,
        userStake: userStakeVal,
        userSelection: ratioSelection,
        userSelectionName: userSelName,
        userOdds: userOddsVal,
        opponentsCount: 1,
        opponents: [
          { name: "My Opponent", pct: oppPctVal, stake: oppStakeVal, selection: opponentSelection, selectionName: oppSelName, odds: oppOddsVal }
        ]
      };
    }
  };

  const getCreatorRatio = () => {
    return calculateLookuptoStakes().userPct / 100;
  };

  const getCreatorStake = () => {
    return calculateLookuptoStakes().userStake;
  };

  const getOpponentLiability = () => {
    return calculateLookuptoStakes().opponents.reduce((acc, curr) => acc + curr.stake, 0);
  };

  return (
    <div className="min-h-screen bg-[#f0f2f5] dark:bg-[#18191a] text-[#050505] dark:text-[#e4e6eb] font-sans antialiased transition-colors duration-300">
      
      {/* HEADER UPPER NAVIGATION */}
      <nav className="sticky top-0 z-50 bg-white dark:bg-[#242526] h-14 border-b border-gray-200 dark:border-[#3e4042] px-4 flex items-center justify-between shadow-sm transition-colors duration-300">
        
        {/* Left Side elements */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => {
              setSidebarVisible(!sidebarVisible);
              setHamburgerOpen(!hamburgerOpen);
            }}
            className="p-1.5 hover:bg-gray-100 dark:hover:bg-[#323334] rounded-lg transition-colors text-gray-600 dark:text-gray-300 flex items-center justify-center cursor-pointer"
            title="Toggle Shortcuts Sidebar"
          >
            <Menu className="w-5.5 h-5.5" />
          </button>
          <div className="flex items-center gap-1">
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); setActiveTab("home"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className="text-2xl font-black text-[#1877f2] hover:opacity-90 tracking-tight select-none leading-none"
            >
              facelook
            </a>
            <button
              onClick={() => { setActiveTab("hub"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className="text-emerald-500 font-extrabold text-[11px] tracking-widest border border-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 px-1.5 py-0.5 rounded leading-none cursor-pointer transition-colors"
              title="Launch GameHub"
            >
              BET
            </button>
          </div>

          {/* Search bar */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center bg-[#f0f2f5] dark:bg-[#3a3b3c] rounded-full px-3.5 py-1.5 w-64 border border-transparent focus-within:border-[#1877f2] transition-all">
            <Search className="w-4 h-4 text-gray-400 shrink-0 mr-1.5" />
            <input
              type="text"
              value={searchPrompt}
              onChange={(e) => setSearchPrompt(e.target.value)}
              placeholder="Search teams & schedules..."
              className="bg-transparent border-none outline-none text-xs text-gray-800 dark:text-gray-100 placeholder-gray-400 w-full"
            />
          </form>
        </div>

        {/* Center Navigation Tabs */}
        <div className="flex items-center gap-1 md:gap-2 h-full">
          <button 
            onClick={() => setActiveTab("home")}
            className={`w-14 md:w-24 h-full relative flex items-center justify-center transition-all ${
              activeTab === "home" ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
            }`}
            title="Social Feed Feed"
          >
            <HomeIcon className="w-5 md:w-6 h-5 md:h-6" />
            {activeTab === "home" && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#1877f2] rounded-t-full" />}
          </button>
          
          <button 
            onClick={() => {
              if (matches.length > 0 && !watchSelectedMatch) {
                setWatchSelectedMatch(matches[0]);
              }
              setActiveTab("watch");
            }}
            className={`w-14 md:w-24 h-full relative flex items-center justify-center transition-all ${
              activeTab === "watch" ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
            }`}
            title="Spectate Live Matches & Commentary"
          >
            <Tv className="w-5 md:w-6 h-5 md:h-6" />
            {activeTab === "watch" && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#1877f2] rounded-t-full" />}
          </button>

          <button 
            onClick={() => setActiveTab("groups")}
            className={`w-14 md:w-24 h-full relative flex items-center justify-center transition-all ${
              activeTab === "groups" ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
            }`}
            title="Join Clans & Betting Syndicates"
          >
            <Users className="w-5 md:w-6 h-5 md:h-6" />
            {activeTab === "groups" && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#1877f2] rounded-t-full" />}
          </button>

          <button 
            onClick={() => setActiveTab("hub")}
            className={`w-14 md:w-24 h-full relative flex items-center justify-center transition-all ${
              activeTab === "hub" ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
            }`}
            title="Sportsbook Odds Center & LookUpto Slip"
          >
            <Gamepad2 className="w-5 md:w-6 h-5 md:h-6" />
            {activeTab === "hub" && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#1877f2] rounded-t-full" />}
          </button>

          <button 
            onClick={() => setActiveTab("profile")}
            className={`w-14 md:w-24 h-full relative flex items-center justify-center transition-all ${
              activeTab === "profile" ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
            }`}
            title="Page Profile"
          >
            <User className="w-5 md:w-6 h-5 md:h-6" />
            {activeTab === "profile" && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#1877f2] rounded-t-full" />}
          </button>
        </div>

        {/* Right Side Shortcuts */}
        <div className="flex items-center gap-2">
          {currentUser ? (
            <div 
              onClick={() => setAuthModalOpen(true)}
              className="hidden md:flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/45 text-emerald-600 dark:text-emerald-400 text-[10px] font-mono font-bold px-2.5 py-1 rounded-full border border-emerald-200/50 cursor-pointer transition-all"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-ping" />
              <span>{currentUser.email || currentUser.phoneNumber}</span>
            </div>
          ) : (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="py-1 px-3 bg-[#1877f2] hover:bg-blue-600 text-white text-[10px] md:text-xs font-black rounded-lg shadow-xs transition-all flex items-center gap-1 leading-none font-sans cursor-pointer whitespace-nowrap"
            >
              <span>🔑 Register</span>
            </button>
          )}

          {/* Quick wallet readout */}
          <button 
            onClick={() => triggerPinCheck("wallet")}
            className="flex items-center gap-1 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/25 dark:hover:bg-blue-900/40 text-blue-600 dark:text-blue-300 px-3 py-1.5 rounded-full text-xs font-bold transition-all border border-blue-200/50 dark:border-blue-900/40"
          >
            <Wallet className="w-4 h-4 shrink-0" />
            <span className="font-mono">${walletBalance.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </button>

          <button 
            onClick={toggleTheme} 
            className="p-2 bg-gray-100 hover:bg-gray-200 dark:bg-[#3a3b3c] dark:hover:bg-zinc-700 text-gray-600 dark:text-gray-300 rounded-full transition-colors"
            title="Toggle Light/Dark Look"
          >
            {isDarkMode ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>

          {/* 1. APP LAUNCHER SHORTCUTS POPUP (Grid icon button) */}
          <div className="relative">
            <button 
              onClick={() => toggleDropdown("launcher")}
              className={`p-2 rounded-full transition-all cursor-pointer flex items-center justify-center ${
                launcherOpen 
                  ? "bg-blue-100 dark:bg-zinc-700 text-[#1877f2] dark:text-blue-400" 
                  : "bg-gray-100 dark:bg-[#3a3b3c] hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-200"
              }`}
              title="Menu Launcher"
            >
              <Grid className="w-5 h-5 animate-pulse-subtle" />
            </button>

            {launcherOpen && (
              <div className="absolute right-[-100px] sm:right-0 mt-3 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-700 rounded-2xl shadow-2xl w-[92vw] sm:w-[580px] max-h-[80vh] overflow-y-auto z-[120] p-4 text-left animate-in fade-in-50 slide-in-from-top-3 duration-200">
                <h3 className="text-xl font-extrabold text-gray-900 dark:text-white px-2 mb-3">Menu</h3>
                
                {/* Search Menu Input */}
                <div className="relative px-2 mb-4">
                  <div className="flex items-center bg-[#f0f2f5] dark:bg-[#3a3b3c] rounded-full px-3 py-2 border border-transparent focus-within:border-[#1877f2] transition-colors">
                    <Search className="w-4 h-4 text-gray-500 mr-2 shrink-0" />
                    <input 
                      type="text" 
                      placeholder="Search menu"
                      value={launcherSearch}
                      onChange={(e) => setLauncherSearch(e.target.value)}
                      className="bg-transparent text-xs w-full outline-none text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 font-sans"
                    />
                  </div>
                </div>

                {/* 2 Column Layout: Left Column Social/Entertainment, Right Column Create */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  {/* Left segment (Social, Entertainment, Shopping) */}
                  <div className="md:col-span-3 space-y-4 max-h-[50vh] overflow-y-auto pr-2">
                    {/* Social Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 px-2 py-1 uppercase tracking-wider">Social</h4>
                      <div className="space-y-1">
                        <button 
                          onClick={() => { setActiveTab("profile"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-blue-100 dark:bg-blue-900/40 rounded-full text-[#1877f2] dark:text-blue-400 shrink-0 mt-0.5">
                            <User className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Pages</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">Discover and connect with businesses.</p>
                          </div>
                        </button>

                        <button 
                          onClick={() => { setActiveTab("groups"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-pink-100 dark:bg-pink-900/40 rounded-full text-pink-500 shrink-0 mt-0.5">
                            <Users className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Groups</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">Connect with people who share your interests.</p>
                          </div>
                        </button>

                        <button 
                          onClick={() => { setActiveTab("home"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-emerald-100 dark:bg-emerald-900/40 rounded-full text-emerald-500 shrink-0 mt-0.5">
                            <HomeIcon className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">News Feed</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">See relevant posts from people and Pages you follow.</p>
                          </div>
                        </button>

                        <button 
                          onClick={() => { setActiveTab("home"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-indigo-100 dark:bg-indigo-900/40 rounded-full text-indigo-500 shrink-0 mt-0.5">
                            <Sparkles className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Feeds</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">See the most recent posts from your friends, groups, Pages.</p>
                          </div>
                        </button>
                      </div>
                    </div>

                    {/* Entertainment Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 px-2 py-1 uppercase tracking-wider">Entertainment</h4>
                      <div className="space-y-1">
                        <button 
                          onClick={() => { setActiveTab("watch"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-amber-100 dark:bg-amber-900/40 rounded-full text-amber-500 shrink-0 mt-0.5">
                            <Tv className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Gaming Video</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">Watch and connect with your favorite games and streamers.</p>
                          </div>
                        </button>

                        <button 
                          onClick={() => { setActiveTab("hub"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-violet-100 dark:bg-violet-900/40 rounded-full text-violet-500 shrink-0 mt-0.5">
                            <Gamepad2 className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Play games</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">Play your favorite sports betting games and lookupto slips.</p>
                          </div>
                        </button>
                      </div>
                    </div>

                    {/* Shopping Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 px-2 py-1 uppercase tracking-wider">Shopping</h4>
                      <div className="space-y-1">
                        <button 
                          onClick={() => { triggerPinCheck("wallet"); setLauncherOpen(false); }}
                          className="w-full text-left p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors flex items-start gap-3"
                        >
                          <div className="p-2 bg-rose-100 dark:bg-rose-900/40 rounded-full text-rose-500 shrink-0 mt-0.5">
                            <Wallet className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-extrabold text-gray-900 dark:text-white">Orders and payments</p>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-normal leading-relaxed">A seamless, secure way to pay on the apps you already use.</p>
                          </div>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right segment (Create Column) */}
                  <div className="md:col-span-2 border-t md:border-t-0 md:border-l border-gray-100 dark:border-zinc-800 pt-3 md:pt-0 md:pl-4">
                    <h4 className="text-xs font-bold text-gray-900 dark:text-white px-1 mb-2">Create</h4>
                    <div className="space-y-1.5 font-sans">
                      <button 
                        onClick={() => { setLauncherOpen(false); window.scrollTo({ top: 350, behavior: "smooth" }); }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-zinc-800 rounded-xl transition-colors flex items-center gap-2.5"
                      >
                        <div className="w-7 h-7 rounded-full bg-gray-100 dark:bg-zinc-700 flex items-center justify-center text-gray-700 dark:text-gray-200 shrink-0">
                          <Plus className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-250">Post</span>
                      </button>

                      <button 
                        onClick={() => { setLauncherOpen(false); setCreateGroupModalOpen(true); }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-zinc-800 rounded-xl transition-colors flex items-center gap-2.5"
                      >
                        <div className="w-7 h-7 rounded-full bg-gray-100 dark:bg-zinc-700 flex items-center justify-center text-gray-700 dark:text-gray-200 shrink-0">
                          <Users className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-[#1877f2] dark:text-blue-450 flex items-center gap-1.5">
                          <span>Group</span> 
                          <span className="text-[9px] bg-blue-100 dark:bg-blue-900/50 px-1 py-0.5 rounded uppercase font-black text-blue-600 dark:text-blue-400">Syndicate</span>
                        </span>
                      </button>

                      <button 
                        onClick={() => { setLauncherOpen(false); alert("Story creation wizard is ready! Share your top odds slip on your stories feed."); }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-zinc-800 rounded-xl transition-colors flex items-center gap-2.5"
                      >
                        <div className="w-7 h-7 rounded-full bg-gray-100 dark:bg-zinc-700 flex items-center justify-center text-gray-700 dark:text-gray-200 shrink-0">
                          <Sparkles className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-250">Story</span>
                      </button>

                      <button 
                        onClick={() => { setLauncherOpen(false); alert("Upload a sports reaction short Reel video or game summary commentary."); }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-zinc-800 rounded-xl transition-colors flex items-center gap-2.5"
                      >
                        <div className="w-7 h-7 rounded-full bg-gray-100 dark:bg-zinc-700 flex items-center justify-center text-gray-700 dark:text-gray-200 shrink-0">
                          <Tv className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-250">Reel</span>
                      </button>

                      <div className="text-[9px] text-gray-400 dark:text-gray-500 pt-4 px-2 italic">
                        Clicking Group directly launches the facelook P2P Group Creator dialog!
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. MESSENGER CHATS POPUP (MessageSquare icon button) */}
          <div className="relative">
            <button 
              onClick={() => toggleDropdown("messenger")}
              className={`p-2 rounded-full transition-all cursor-pointer flex items-center justify-center relative ${
                messengerOpen 
                  ? "bg-blue-100 dark:bg-zinc-700 text-[#1877f2] dark:text-blue-400" 
                  : "bg-gray-100 dark:bg-[#3a3b3c] hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-200"
              }`}
              title="Chats Messenger"
            >
              <MessageSquare className="w-5 h-5" />
              {!messengerUnlocked && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white dark:border-[#242526]">
                  🔒
                </span>
              )}
            </button>

            {messengerOpen && (
              <div className="absolute right-[-60px] sm:right-0 mt-3 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-700 rounded-2xl shadow-2xl w-[90vw] sm:w-[360px] max-h-[820px] z-[120] flex flex-col overflow-hidden text-left animate-in py-1 duration-150">
                
                {/* Header title */}
                <div className="p-3.5 flex items-center justify-between pb-2">
                  <h3 className="text-lg font-black tracking-tight text-gray-900 dark:text-white">Chats</h3>
                  <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                    <button onClick={() => alert("Messenger global setings")} className="p-1 hover:bg-gray-150 dark:hover:bg-zinc-800 rounded-full text-xs font-bold leading-none cursor-pointer">•••</button>
                    <button className="text-xs p-1 hover:bg-gray-150 dark:hover:bg-zinc-800 rounded-full">⛶</button>
                    <button onClick={() => alert("Write new secure peer-to-peer message")} className="text-xs p-1 hover:bg-gray-150 dark:hover:bg-zinc-800 rounded-full">📝</button>
                  </div>
                </div>

                {/* Messenger search bar */}
                <div className="px-3 pb-2.5">
                  <div className="flex items-center bg-[#f0f2f5] dark:bg-[#3a3b3c] rounded-full px-3 py-1.5 border border-transparent">
                    <Search className="w-3.5 h-3.5 text-gray-400 mr-2 shrink-0" />
                    <input 
                      type="text" 
                      placeholder="Search Messenger" 
                      value={messengerSearchQuery}
                      onChange={(e) => setMessengerSearchQuery(e.target.value)}
                      className="bg-transparent text-xs w-full outline-none text-gray-800 dark:text-gray-200 placeholder-gray-400"
                    />
                  </div>
                </div>

                {/* Sub Tab Buttons */}
                <div className="flex items-center gap-1.5 px-3 mb-2 font-sans select-none text-[11px] font-bold">
                  {(["all", "unread", "groups", "communities"] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setMessengerActiveTab(tab)}
                      className={`px-3 py-1 rounded-full capitalize cursor-pointer transition-all ${
                        messengerActiveTab === tab
                          ? "bg-blue-50 dark:bg-blue-900/30 text-[#1877f2] dark:text-blue-400 font-extrabold"
                          : "text-gray-500 hover:bg-gray-100 dark:hover:bg-zinc-800"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                {/* PIN Lock code notification banner */}
                {!messengerUnlocked ? (
                  <div className="m-3 p-3.5 bg-blue-50 dark:bg-[#1a2e4c] border border-blue-200/50 dark:border-blue-900/60 rounded-xl space-y-2">
                    <div className="flex items-start gap-2.5">
                      <div className="p-1 bg-blue-105 dark:bg-blue-952 text-[#1877f2] dark:text-blue-350 rounded-full mt-0.5">
                        <Info className="w-5 h-5 shrink-0" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-gray-800 dark:text-[#f0f2f5]">Chat history is missing</h4>
                        <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-normal">Enter your PIN to restore chat history.</p>
                      </div>
                    </div>
                    
                    {/* PIN interactive digits panel */}
                    <div className="flex items-center justify-between gap-1 pt-1.5">
                      {messengerPin.map((digit, idx) => (
                        <input
                          key={idx}
                          id={`msg-pin-${idx}`}
                          type="password"
                          maxLength={1}
                          pattern="[0-9]*"
                          inputMode="numeric"
                          value={digit}
                          placeholder="-"
                          onChange={(e) => handlePinChange(idx, e.target.value)}
                          className="w-8 h-9 text-center bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 rounded-lg text-sm font-black text-blue-600 dark:text-blue-400 focus:outline-[#1877f2]"
                        />
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-1 text-[10px]">
                      <button 
                        onClick={() => alert("Universal Decrypt hint: enter any 6 digits (e.g. 123456) in the input boxes to unlock and list details of secure conversations.")}
                        className="text-blue-600 dark:text-blue-400 font-bold hover:underline"
                      >
                        Forgot PIN?
                      </button>
                      <button 
                        onClick={() => setMessengerUnlocked(true)}
                        className="text-[9px] bg-[#1877f2] hover:bg-blue-600 text-white font-mono px-2 py-0.5 rounded font-bold"
                      >
                        Skip & Reveal
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="m-3 p-2 bg-emerald-50 dark:bg-emerald-952/40 border border-emerald-200 dark:border-emerald-900 rounded-xl flex items-center justify-between text-[11px] text-emerald-800 dark:text-emerald-400">
                    <span className="flex items-center gap-1">🟢 Chat synchronization secure</span>
                    <button onClick={() => { setMessengerUnlocked(false); setMessengerPin(["", "", "", "", "", ""]); }} className="text-gray-400 hover:text-gray-900 font-bold">Lock</button>
                  </div>
                )}

                {/* Chats roster list */}
                <div className={`max-h-[350px] overflow-y-auto divide-y divide-gray-100 dark:divide-zinc-800 transition-all ${!messengerUnlocked ? "blur-xs opacity-50 select-none pointer-events-none" : ""}`}>
                  {messengerChats
                    .filter(c => {
                      if (messengerActiveTab === "unread" && c.status !== "online") return false;
                      if (messengerSearchQuery && !c.name.toLowerCase().includes(messengerSearchQuery.toLowerCase())) return false;
                      return true;
                    })
                    .map((chat) => (
                      <div 
                        key={chat.id}
                        onClick={() => alert(`Entering direct chat with ${chat.name}... Hello! Send safe peer bets.`)}
                        className="p-3 hover:bg-gray-50 dark:hover:bg-zinc-850 flex items-center gap-3 cursor-pointer group"
                      >
                        <div className="relative shrink-0 select-none">
                          <img 
                            src={`https://ui-avatars.com/api/?name=${encodeURIComponent(chat.name)}&background=1877f2&color=fff&bold=true`} 
                            className="w-10 h-10 rounded-full border border-gray-100 dark:border-zinc-800"
                            alt={chat.name}
                          />
                          {chat.status === "online" && (
                            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-[#242526]" />
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-baseline justify-between">
                            <h4 className="text-xs font-black text-gray-900 dark:text-gray-100 group-hover:text-[#1877f2] transition-colors">{chat.name}</h4>
                            <span className="text-[10px] font-mono text-gray-400">{chat.time}</span>
                          </div>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate leading-relaxed pt-0.5">
                            {chat.text}
                          </p>
                        </div>

                        {chat.status === "online" && (
                          <div className="w-2.5 h-2.5 bg-blue-600 rounded-full shrink-0" />
                        )}
                      </div>
                    ))}
                </div>

                <div className="p-2 border-t border-gray-100 dark:border-zinc-800 text-center bg-gray-50 dark:bg-zinc-900">
                  <button 
                    onClick={() => alert("Launching standalone Facelook Messenger client module...")}
                    className="text-[11px] font-bold text-[#1877f2] dark:text-blue-450 hover:underline cursor-pointer"
                  >
                    See all in Messenger
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 3. NOTIFICATIONS POPOVER (Bell icon button) */}
          <div className="relative">
            <button 
              onClick={() => toggleDropdown("notifications")}
              className={`p-2 rounded-full transition-all cursor-pointer flex items-center justify-center relative ${
                notificationsOpen 
                  ? "bg-blue-100 dark:bg-zinc-700 text-[#1877f2] dark:text-blue-400" 
                  : "bg-gray-100 dark:bg-[#3a3b3c] hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-200"
              }`}
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {notificationList.filter(n => !n.read).length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-650 text-white font-mono text-[9px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center animate-pulse border-2 border-white dark:border-[#242526]">
                  {notificationList.filter(n => !n.read).length}
                </span>
              )}
            </button>

            {notificationsOpen && (
              <div className="absolute right-[-40px] sm:right-0 mt-3 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-700 rounded-2xl shadow-2xl w-[90vw] sm:w-[350px] max-h-[80vh] overflow-y-auto z-[120] text-left animate-in slide-in-from-top-2 duration-150 py-1.5 flex flex-col">
                
                {/* Header Title with Optional More Dots Toggle menu */}
                <div className="p-3 flex items-center justify-between relative">
                  <h3 className="text-lg font-black tracking-tight text-gray-900 dark:text-white">Notifications</h3>
                  
                  <div className="relative">
                    <button 
                      onClick={() => setNotifOptionsMenuOpen(!notifOptionsMenuOpen)}
                      className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full font-black text-gray-500 cursor-pointer text-sm"
                    >
                      •••
                    </button>

                    {/* Screenshot 1 styled Options Menu */}
                    {notifOptionsMenuOpen && (
                      <div className="absolute right-0 mt-1 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-xl shadow-2xl w-48 py-1 z-[130] text-left">
                        <button 
                          onClick={() => {
                            setNotificationList(notificationList.map(n => ({...n, read: true})));
                            setNotifOptionsMenuOpen(false);
                            alert("All alerts marked read.");
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-gray-50 dark:hover:bg-zinc-700 text-xs font-bold text-gray-850 dark:text-gray-150 flex items-center gap-2"
                        >
                          <Check className="w-3.5 h-3.5 text-green-500" />
                          <span>Mark all as read</span>
                        </button>
                        <button 
                          onClick={() => { setNotifOptionsMenuOpen(false); alert("Opening Notification constraints page..."); }}
                          className="w-full px-3 py-2 text-left hover:bg-gray-50 dark:hover:bg-zinc-700 text-xs font-bold text-gray-850 dark:text-gray-150 flex items-center gap-2"
                        >
                          <Settings className="w-3.5 h-3.5 text-gray-400" />
                          <span>Notification settings</span>
                        </button>
                        <button 
                          onClick={() => { setNotifOptionsMenuOpen(false); }}
                          className="w-full px-3 py-2 text-left hover:bg-gray-50 dark:hover:bg-zinc-700 text-xs font-bold text-gray-850 dark:text-gray-150 flex items-center gap-2"
                        >
                          <Bell className="w-3.5 h-3.5 text-blue-500" />
                          <span>Open Notifications</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub-tabs "All" & "Unread" layout from the screenshots */}
                <div className="flex items-center gap-2 px-3 pb-2 border-b border-gray-100 dark:border-zinc-805 select-none font-sans text-xs">
                  <button 
                    onClick={() => setNotificationsFilterTab("all")}
                    className={`px-3 py-1.5 rounded-full font-black ${
                      notificationsFilterTab === "all" 
                        ? "bg-blue-100 dark:bg-blue-900/35 text-blue-600 dark:text-blue-400" 
                        : "text-gray-500 hover:bg-gray-100 dark:hover:bg-zinc-800"
                    }`}
                  >
                    All
                  </button>
                  <button 
                    onClick={() => setNotificationsFilterTab("unread")}
                    className={`px-3 py-1.5 rounded-full font-black ${
                      notificationsFilterTab === "unread" 
                        ? "bg-blue-100 dark:bg-blue-900/35 text-blue-600 dark:text-blue-400" 
                        : "text-gray-500 hover:bg-gray-100 dark:hover:bg-zinc-800"
                    }`}
                  >
                    Unread
                  </button>
                </div>

                {/* Main scroll list */}
                <div className="max-h-[380px] overflow-y-auto divide-y divide-gray-50 dark:divide-zinc-800/40 font-sans">
                  
                  {/* New notifications section */}
                  <div className="p-3 pb-1 flex items-center justify-between">
                    <span className="text-xs font-extrabold text-gray-905 dark:text-white">New</span>
                    <button onClick={() => alert("Marked recent activities read.")} className="text-[#1877f2] hover:underline text-[11px] font-bold">See all</button>
                  </div>

                  {notificationList
                    .filter(n => {
                      if (notificationsFilterTab === "unread" && n.read) return false;
                      if (n.id === "noti-spec-4" && samuelWerungaStatus === "dismissed") return false;
                      return n.category === "new";
                    })
                    .map((item) => (
                      <div 
                        key={item.id}
                        onClick={() => {
                          setNotificationList(notificationList.map(notif => notif.id === item.id ? { ...notif, read: true } : notif));
                        }}
                        className={`p-3 text-xs flex items-start gap-3 hover:bg-gray-50 dark:hover:bg-zinc-800/60 cursor-pointer ${!item.read ? "bg-blue-50/40 dark:bg-blue-950/15" : ""}`}
                      >
                        <div className="relative shrink-0 select-none">
                          <img src={item.avatar} className="w-11 h-11 rounded-full object-cover" alt="author" />
                          <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[10px] border-2 border-white dark:border-[#242526] ${
                            item.type === "like" ? "bg-blue-500 text-white" : "bg-emerald-500 text-white"
                          }`}>
                            {item.type === "like" ? "👍" : "👤"}
                          </div>
                        </div>

                        <div className="flex-1">
                          <p className="text-gray-800 dark:text-gray-200 leading-normal">
                            <span className="font-extrabold text-gray-900 dark:text-white mr-1">{item.names}</span> 
                            <span className="font-normal text-gray-600 dark:text-gray-300">{item.action}</span>
                          </p>
                          <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 mt-1 block">{item.time} ago</span>

                          {/* Interactive Samuel follow buttons (Specific to Samuel Werunga card in screenshots!) */}
                          {item.id === "noti-spec-4" && (
                            <div className="flex items-center gap-2 pt-2 text-[11.5px] select-none">
                              {samuelWerungaStatus === "follow" ? (
                                <>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); setSamuelWerungaStatus("following"); alert("You succeeded in following back Samuel Werunga!"); }}
                                    className="px-4 py-1.5 bg-[#1877f2] hover:bg-blue-600 font-extrabold text-white rounded-lg transition-transform"
                                  >
                                    Follow Back
                                  </button>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); setSamuelWerungaStatus("dismissed"); }}
                                    className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 font-extrabold text-gray-700 dark:text-gray-150 rounded-lg transition-transform"
                                  >
                                    Dismiss
                                  </button>
                                </>
                              ) : (
                                <span className="bg-emerald-55 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-450 font-black border border-emerald-200 px-2.5 py-1 rounded-lg">
                                  ✓ Following
                                </span>
                              )}
                            </div>
                          )}

                          {/* @ts-ignore */}
                          {item.isProposal && (
                            <div className="mt-2.5 p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/35 border border-indigo-200 dark:border-indigo-800 text-xs text-left">
                              <div className="font-semibold text-indigo-700 dark:text-indigo-300">
                                Proposed Change Details:
                              </div>
                              <div className="mt-1 space-y-1 font-mono text-[10.5px] text-gray-700 dark:text-gray-300">
                                {/* @ts-ignore */}
                                <div>Match: <span className="text-gray-950 dark:text-white font-bold">{item.proposalMatchName}</span></div>
                                {/* @ts-ignore */}
                                <div>Original: <span className="line-through text-red-500 font-semibold">{item.proposalOldMarket}</span></div>
                                {/* @ts-ignore */}
                                <div>Counter-Market: <span className="text-blue-500 font-extrabold">{item.proposalNewMarket}</span></div>
                                {/* @ts-ignore */}
                                <div>Commit Stake: <span className="font-extrabold text-[#1877f2] dark:text-blue-400">${item.proposalStake?.toFixed(2)}</span></div>
                              </div>
                              
                              {/* @ts-ignore */}
                              {item.proposalStatus === "pending" ? (
                                <div className="mt-2 flex gap-1.5 pt-1.5 border-t border-indigo-100 dark:border-indigo-900/65">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      // Confirm/Accept the proposed change!
                                      // @ts-ignore
                                      const stakeAm = item.proposalStake || 0;
                                      if (walletBalance < stakeAm) {
                                        alert(`Insufficient wallet balance to accept this $${stakeAm.toFixed(2)} change.`);
                                        return;
                                      }
                                      setWalletBalance((prev) => prev - stakeAm);
                                      setTransactions([
                                        {
                                          id: `tx-${Date.now()}`,
                                          type: "bet_stake",
                                          amount: stakeAm,
                                          time: "Just now",
                                          // @ts-ignore
                                          target: `Approved Change: ${item.proposalNewMarket} on ${item.proposalMatchName}`,
                                        },
                                        ...transactions,
                                      ]);
                                      // @ts-ignore
                                      alert(`Perfect! You accepted @${item.oppUser}'s customized market proposal: "${item.proposalNewMarket}". Escrow funds ($${stakeAm.toFixed(2)}) committed successfully!`);

                                      // Update proposal state
                                      setNotificationList(prevNotifs => 
                                        prevNotifs.map(notif => 
                                          notif.id === item.id 
                                            // @ts-ignore
                                            ? { ...notif, proposalStatus: "accepted", action: `approved and sealed your request to change the market for ${item.proposalMatchName} to "${item.proposalNewMarket}"` }
                                            : notif
                                        )
                                      );
                                    }}
                                    className="px-2.5 py-1 bg-green-600 hover:bg-green-700 font-extrabold text-white text-[10.5px] rounded-md transition-all cursor-pointer"
                                  >
                                    Accept Change
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      // Decline and Cancel
                                      setNotificationList(prevNotifs => 
                                        prevNotifs.map(notif => 
                                          notif.id === item.id 
                                            // @ts-ignore
                                            ? { ...notif, proposalStatus: "declined", action: `declined your request to change the market on ${item.proposalMatchName} to "${item.proposalNewMarket}" (challenge canceled)` }
                                            : notif
                                        )
                                      );
                                      alert(`The proposal change was declined and canceled.`);
                                    }}
                                    className="px-2.5 py-1 bg-red-600 hover:bg-red-700 font-extrabold text-white text-[10.5px] rounded-md transition-all cursor-pointer"
                                  >
                                    Decline & Cancel
                                  </button>
                                </div>
                              ) : (
                                <div className="mt-2 text-[10.5px] font-bold">
                                  {/* @ts-ignore */}
                                  {item.proposalStatus === "accepted" ? (
                                    <span className="text-green-600 dark:text-green-400 bg-green-500/10 px-2 py-0.5 rounded border border-green-500/20 shadow-xs">
                                      ✓ Accepted & Sealed
                                    </span>
                                  ) : (
                                    <span className="text-red-605 dark:text-red-400 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20 shadow-xs">
                                      ✗ Declined / Canceled
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {!item.read && (
                          <div className="w-2.5 h-2.5 bg-blue-600 rounded-full shrink-0 self-center" />
                        )}
                      </div>
                    ))}

                  {/* Earlier section */}
                  <div className="p-3 pb-1 text-xs font-extrabold text-gray-905 dark:text-white bg-gray-50/50 dark:bg-[#1a1b1c] border-y border-gray-100 dark:border-zinc-800">
                    Earlier
                  </div>

                  {notificationList
                    .filter(n => {
                      if (notificationsFilterTab === "unread" && n.read) return false;
                      return n.category === "earlier";
                    })
                    .map((item) => (
                      <div 
                        key={item.id}
                        onClick={() => {
                          setNotificationList(notificationList.map(notif => notif.id === item.id ? { ...notif, read: true } : notif));
                        }}
                        className={`p-3 text-xs flex items-start gap-3 hover:bg-gray-55/65 dark:hover:bg-zinc-800/60 cursor-pointer ${!item.read ? "bg-blue-50/40 dark:bg-blue-950/15" : ""}`}
                      >
                        <div className="relative shrink-0 select-none">
                          <img src={item.avatar} className="w-11 h-11 rounded-full object-cover" alt="author" />
                          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-[10px] text-white border-2 border-white dark:border-[#242526]">
                            💬
                          </div>
                        </div>

                        <div className="flex-1">
                          <p className="text-gray-800 dark:text-gray-200 leading-normal">
                            <span className="font-extrabold text-gray-900 dark:text-white mr-1">{item.names}</span>
                            <span className="font-normal text-gray-600 dark:text-gray-300">{item.action}</span>
                          </p>
                          <span className="text-[10px] text-gray-400 mt-1 block">{item.time} ago</span>
                        </div>

                        {!item.read && (
                          <div className="w-2.5 h-2.5 bg-blue-600 rounded-full shrink-0 self-center" />
                        )}
                      </div>
                    ))}
                </div>

                {/* Footer of Notifications */}
                <div className="p-2 border-t border-gray-150 dark:border-zinc-805 text-center bg-gray-55/60 dark:bg-[#1a1b1c]">
                  <button 
                    onClick={() => {
                      alert("Successfully retrieved previous daily activities feeds.");
                    }}
                    className="w-full py-1.5 bg-gray-150 dark:bg-[#323334] hover:bg-gray-200 text-gray-700 dark:text-gray-200 font-extrabold text-xs rounded-xl cursor-pointer"
                  >
                    See previous notifications
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 4. PROFILE / ACCOUNT DROPDOWN (Avatar selector popup matching Screenshot 3) */}
          <div className="relative">
            <div 
              onClick={() => toggleDropdown("profile")}
              className="relative cursor-pointer group select-none active:scale-95 transition-transform"
            >
              <img 
                src={PROFILES[activeProfilePage]?.avatar || PROFILES["Collins Dnego"].avatar} 
                className="w-9 h-9 rounded-full object-cover border-2 border-gray-300 dark:border-zinc-700 group-hover:border-[#1877f2] transition-colors" 
                alt="User avatar" 
              />
              <span className="absolute bottom-[-2px] right-[-2px] bg-gray-200 dark:bg-zinc-800 p-0.5 rounded-full border border-white dark:border-zinc-800 text-[8px]">
                ▼
              </span>
            </div>

            {profileMenuOpen && (
              <div className="absolute right-0 mt-3 bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-700 rounded-2xl shadow-2xl w-[90vw] sm:w-[350px] z-[120] p-4 text-left animate-in duration-200">
                
                {/* Profiles section matching Screenshot 3 */}
                <div className="bg-[#f7f8fa] dark:bg-[#1c1d1e] rounded-xl p-2.5 border border-gray-200/55 dark:border-zinc-800 shadow-sm space-y-2 mb-3">
                  
                  <div className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pb-1 border-b border-gray-150 dark:border-zinc-804/50 mb-1">
                    Personal Accounts
                  </div>

                  {/* Option 1: Collins Dnego */}
                  <div 
                    onClick={() => {
                      setActiveProfilePage("Collins Dnego");
                      alert("Switched live session to: Collins Dnego");
                    }}
                    className={`p-2 rounded-lg pointer flex items-center justify-between cursor-pointer transition-all ${
                      activeProfilePage === "Collins Dnego" 
                        ? "bg-white dark:bg-[#242526] border border-[#1877f2] shadow-xs" 
                        : "hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img src="https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff&bold=true" className="w-9 h-9 rounded-full border" alt="cd" />
                      <div className="text-left font-sans min-w-0">
                        <span className="text-xs font-black text-gray-900 dark:text-gray-150 block truncate">Collins Dnego</span>
                        <span className="text-[9px] text-gray-400 block font-normal">Active User Profile</span>
                      </div>
                    </div>
                    {activeProfilePage === "Collins Dnego" && (
                      <span className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px]">✓</span>
                    )}
                  </div>

                  {/* Option 2: Zephaniah Mwangi */}
                  <div 
                    onClick={() => {
                      setActiveProfilePage("Zephaniah Mwangi");
                      alert("Switched live session to: Zephaniah Mwangi's profile");
                    }}
                    className={`p-2 rounded-lg pointer flex items-center justify-between cursor-pointer transition-all ${
                      activeProfilePage === "Zephaniah Mwangi" 
                        ? "bg-white dark:bg-[#242526] border border-[#1877f2] shadow-xs" 
                        : "hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img src="https://ui-avatars.com/api/?name=Zephaniah+Mwangi&background=a855f7&color=fff&bold=true" className="w-9 h-9 rounded-full border" alt="zm" />
                      <div className="text-left font-sans min-w-0">
                        <span className="text-xs font-black text-gray-950 dark:text-gray-200 block truncate">Zephaniah Mwangi</span>
                        <span className="text-[9px] text-gray-400 block font-normal">Predictor Clan-Lead</span>
                      </div>
                    </div>
                    {activeProfilePage === "Zephaniah Mwangi" && (
                      <span className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px]">✓</span>
                    )}
                  </div>

                  <div className="text-[10px] font-mono font-black text-gray-400 uppercase tracking-widest pt-2 pb-1 border-b border-gray-150 dark:border-zinc-804/50 mb-1">
                    Managed Pages
                  </div>

                  {/* Option 3: Baridi SANA */}
                  <div 
                    onClick={() => {
                      setActiveProfilePage("Baridi SANA");
                      alert("Switched live session to page: Baridi SANA");
                    }}
                    className={`p-2 rounded-lg pointer flex items-center justify-between cursor-pointer transition-all ${
                      activeProfilePage === "Baridi SANA" 
                        ? "bg-white dark:bg-[#242526] border border-[#1877f2] shadow-xs" 
                        : "hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img src="https://ui-avatars.com/api/?name=Baridi+Sana&background=1877f2&color=fff&bold=true" className="w-9 h-9 rounded-full border" alt="bs" />
                      <div className="text-left font-sans min-w-0">
                        <span className="text-xs font-black text-gray-900 dark:text-gray-150 block truncate">Baridi SANA</span>
                        <span className="text-[9px] text-gray-400 block font-normal">Official News & Betting Pool</span>
                      </div>
                    </div>
                    {activeProfilePage === "Baridi SANA" && (
                      <span className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px]">✓</span>
                    )}
                  </div>

                  {/* Option 4: Collo Dnego */}
                  <div 
                    onClick={() => {
                      setActiveProfilePage("Collo Dnego");
                      alert("Switched live session to page: Collo Dnego");
                    }}
                    className={`p-2 rounded-lg pointer flex items-center justify-between cursor-pointer transition-all ${
                      activeProfilePage === "Collo Dnego" 
                        ? "bg-white dark:bg-[#242526] border border-[#1877f2] shadow-xs" 
                        : "hover:bg-gray-100 dark:hover:bg-zinc-800/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img src="https://ui-avatars.com/api/?name=Collo+Dnego&background=059669&color=fff&bold=true" className="w-9 h-9 rounded-full border" alt="cd" />
                      <div className="text-left font-sans min-w-0">
                        <span className="text-xs font-black text-gray-900 dark:text-gray-150 block truncate">Collo Dnego</span>
                        <span className="text-[9px] text-gray-400 block font-normal">Managed Fan Club Page</span>
                      </div>
                    </div>
                    {activeProfilePage === "Collo Dnego" && (
                      <span className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px]">✓</span>
                    )}
                  </div>

                  {/* See all profiles button */}
                  <button 
                    onClick={() => alert("Successfully synchronized all live profile manager assets.")}
                    className="w-full py-1.5 px-3 bg-gray-200/55 hover:bg-gray-200 dark:bg-[#2c2d2e] dark:hover:bg-[#3c3d3e] text-gray-800 dark:text-gray-200 font-extrabold text-[12px] rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>See all profiles (4 synchronized)</span>
                  </button>
                </div>

                {/* Primary Settings Menu rows of Screenshot 3 */}
                <div className="space-y-1 py-1 font-sans text-xs">
                  <button 
                    onClick={() => alert("Launching Settings & privacy overlay center")}
                    className="w-full p-2.5 hover:bg-gray-100 dark:hover:bg-zinc-800/60 rounded-xl flex items-center justify-between transition-colors text-gray-800 dark:text-gray-200"
                  >
                    <div className="flex items-center gap-3 font-bold">
                      <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center text-gray-600 dark:text-gray-300">
                        <Settings className="w-4 h-4" />
                      </div>
                      <span>Settings & privacy</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>

                  <button 
                    onClick={() => alert("Connecting live interactive customer support...")}
                    className="w-full p-2.5 hover:bg-gray-100 dark:hover:bg-zinc-800/60 rounded-xl flex items-center justify-between transition-colors text-gray-800 dark:text-gray-200"
                  >
                    <div className="flex items-center gap-3 font-bold">
                      <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center text-gray-600 dark:text-gray-300">
                        <HelpCircle className="w-4 h-4" />
                      </div>
                      <span>Help & support</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>

                  <button 
                    onClick={() => { toggleTheme(); }}
                    className="w-full p-2.5 hover:bg-gray-100 dark:hover:bg-zinc-800/60 rounded-xl flex items-center justify-between transition-colors text-gray-800 dark:text-gray-200"
                  >
                    <div className="flex items-center gap-3 font-bold">
                      <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center text-gray-600 dark:text-gray-300">
                        {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                      </div>
                      <span>Display & accessibility</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>

                  <button 
                    onClick={() => alert("Thanks for your valuable advice! Feedbacks submitted to the admin team.")}
                    className="w-full p-2.5 hover:bg-gray-100 dark:hover:bg-zinc-800/60 rounded-xl flex items-center justify-between transition-colors text-gray-800 dark:text-gray-200"
                  >
                    <div className="flex items-center gap-2 font-bold w-full">
                      <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center text-gray-600 dark:text-gray-300">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div className="flex-1 text-left">
                        <p>Give feedback</p>
                        <span className="text-[9px] text-gray-400 block font-normal">CTRL B</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
                  </button>

                  <button 
                    onClick={() => {
                      setCurrentUser(null);
                      setProfileMenuOpen(false);
                      alert("Successfully logged out of active profile page session.");
                    }}
                    className="w-full p-2.5 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl flex items-center gap-3 transition-colors text-red-600 dark:text-red-400 font-bold"
                  >
                    <div className="w-8 h-8 rounded-full bg-red-100/50 dark:bg-red-950/40 flex items-center justify-center">
                      <LogOut className="w-4 h-4" />
                    </div>
                    <span>Log out</span>
                  </button>
                </div>

                {/* Footer terms exact match to Screenshot 3 */}
                <div className="text-[10px] text-gray-400 dark:text-gray-500 pt-3 border-t border-gray-100 dark:border-zinc-800 mt-2 font-normal leading-relaxed text-center">
                  Privacy · Terms · Advertising · Ad Choices ▷ · Cookies · More · Facelook © 2026
                </div>

              </div>
            )}
          </div>
        </div>
      </nav>

      {/* SEARCH CRAWLED BRIEF NOTIFIER */}
      {searchResponse && (
        <div className="bg-blue-600 text-white text-xs py-2.5 px-4 text-center flex items-center justify-center gap-2 shadow-inner">
          <Sparkles className="w-4 h-4 fill-white" />
          <span><strong>Search grounded result:</strong> {searchResponse}</span>
          <button onClick={() => setSearchResponse("")} className="font-sans font-bold ml-2 underline hover:no-underline">Dismiss</button>
        </div>
      )}

      {/* THREE SECTION GRID LAYOUT */}
      <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-1 md:grid-cols-4 gap-6">
        
        {/* LEFT SHORTCUTS BAR (Hidden on mobile or desktop depending on toggles) */}
        <aside className={`md:col-span-1 space-y-5 bg-white dark:bg-[#242526] md:bg-transparent md:dark:bg-transparent rounded-xl shadow-md md:shadow-none p-4 md:p-0 border border-gray-200 dark:border-[#3e4042] md:border-none duration-300 md:sticky md:top-[80px] md:max-h-[calc(100vh-100px)] md:overflow-y-auto ${
          sidebarVisible ? (hamburgerOpen ? "block" : "hidden md:block") : "hidden"
        }`}>
          {/* User profile */}
          <div className="p-3 bg-white dark:bg-[#242526] rounded-xl shadow-sm border border-gray-150 dark:border-[#3e4042] flex items-center gap-3">
            <img src={PROFILES[activeProfilePage]?.avatar || PROFILES["Collins Dnego"].avatar} className="w-11 h-11 rounded-full border border-gray-200" alt="profile" />
            <div className="text-left font-sans">
              <h3 className="font-black text-[14px] text-gray-800 dark:text-gray-200">{PROFILES[activeProfilePage]?.name || "Collins Dnego"}</h3>
              <p className="text-[10px] text-gray-400 font-mono tracking-wide">{PROFILES[activeProfilePage]?.desc || "Elite LookUpto Bettor"}</p>
            </div>
          </div>

          <div className="space-y-1.5 font-sans">
            {/* 1. Pages - Styled Highlight Selection box matching screenshot 145711, on click switches center layout to Pages Page block */}
            <button 
              onClick={() => { setActiveTab("pages"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className={`w-full flex items-center gap-3 p-3 text-left rounded-2xl text-[13px] font-black transition-all ${
                activeTab === "pages" 
                  ? "bg-blue-100/90 dark:bg-blue-900/40 text-[#1877f2] dark:text-blue-450 shadow-xs ring-2 ring-blue-500/10" 
                  : "bg-blue-50 dark:bg-zinc-800/25 text-[#1877f2] dark:text-blue-300 border border-blue-105/50 dark:border-zinc-700/50"
              }`}
            >
              <div className="p-2.5 bg-blue-550/15 dark:bg-blue-500/20 text-[#1877f2] dark:text-blue-450 rounded-xl shrink-0">
                <Flag className="w-4 h-4 text-amber-500 fill-amber-500" />
              </div>
              <span className="truncate">Pages</span>
            </button>

            {/* 2. LookGroups - Styled Red/Pink style matching screenshot 145711 */}
            <button 
              onClick={() => { setActiveTab("groups"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-xs text-left font-black transition-all ${
                activeTab === "groups"
                  ? "bg-pink-100/80 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400"
                  : "text-gray-850 dark:text-gray-205 hover:bg-gray-100 dark:hover:bg-[#323334]"
              }`}
            >
              <div className="p-2 bg-pink-100 dark:bg-pink-950 text-pink-600 dark:text-pink-400 rounded-xl shrink-0">
                <Users className="w-4 h-4" />
              </div>
              <span className="truncate">LookGroups</span>
            </button>

            {/* 3. Deposit - Green style matching screenshot 145711 */}
            <button 
              onClick={() => triggerPinCheck("wallet")}
              className="w-full flex items-center gap-3 p-2.5 rounded-xl text-xs text-left font-black text-gray-850 dark:text-gray-205 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
            >
              <div className="p-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0">
                <Wallet className="w-4 h-4" />
              </div>
              <span className="truncate">Deposit</span>
            </button>

            {/* 4. Game hub - Royal Blue controller matching screenshot 145711 */}
            <button 
              onClick={() => { setActiveTab("hub"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-xs text-left font-black transition-all ${
                activeTab === "hub"
                  ? "bg-blue-100/80 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                  : "text-gray-850 dark:text-gray-205 hover:bg-gray-100 dark:hover:bg-[#323334]"
              }`}
            >
              <div className="p-2 bg-blue-100 dark:bg-blue-952 text-blue-600 dark:text-blue-400 rounded-xl shrink-0">
                <Gamepad2 className="w-4 h-4" />
              </div>
              <span className="truncate">Game hub</span>
            </button>

            {/* 5. ⭐ AI */}
            <button 
              onClick={() => {
                setNyotaChatOpen(open => !open);
              }}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
            >
              <div className="p-1.5 bg-gradient-to-tr from-blue-100 to-purple-100 dark:from-blue-900/40 dark:to-purple-900/40 text-blue-600 dark:text-purple-400 rounded-full shrink-0">
                <Star className="w-4 h-4 fill-blue-500/20 text-blue-600 dark:text-purple-400" />
              </div>
              <span className="truncate">⭐ AI</span>
            </button>

            {/* 7. Friends */}
            <button 
              onClick={() => {
                alert("Opening peer-to-peer challenger matchups...");
                triggerPinCheck("interactions");
              }}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
            >
              <div className="p-1.5 bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400 rounded-full shrink-0">
                <User className="w-4 h-4 text-sky-605" />
              </div>
              <span className="truncate">Friends</span>
            </button>

            {/* COLLAPSIBLE / EXPANDABLE Short Cuts Menu from Screenshot 145753 */}
            {menuExpanded && (
              <div className="space-y-1.5 pt-0.5 animate-in fade-in slide-in-from-top-2 duration-150">
                {/* Memo */}
                <button 
                  onClick={() => { setActiveTab("memo"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold transition-all ${
                    activeTab === "memo" ? "bg-gray-100 dark:bg-[#323334] text-[#1877f2]" : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334]"
                  }`}
                >
                  <div className="p-1.5 bg-blue-50 dark:bg-blue-950/40 text-blue-500 rounded-full shrink-0">
                    <History className="w-4 h-4" />
                  </div>
                  <span className="truncate">Memo</span>
                </button>

                {/* Saved */}
                <button 
                  onClick={() => { setActiveTab("saved"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold transition-all ${
                    activeTab === "saved" ? "bg-gray-100 dark:bg-[#323334] text-[#1877f2]" : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334]"
                  }`}
                >
                  <div className="p-1.5 bg-purple-50 dark:bg-purple-950/40 text-purple-500 rounded-full shrink-0">
                    <Bookmark className="w-4 h-4" />
                  </div>
                  <span className="truncate">Saved Videos & Posts</span>
                </button>

                {/* Reels */}
                <button 
                  onClick={() => { setActiveTab("watch"); window.scrollTo({ top: 350, behavior: "smooth" }); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-rose-50 dark:bg-rose-950/40 text-rose-500 rounded-full shrink-0">
                    <Film className="w-4 h-4" />
                  </div>
                  <span className="truncate">Reels</span>
                </button>

                {/* Marketplace */}
                <button 
                  onClick={() => alert("Sports bet-points Marketplace is loading...")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-amber-50 dark:bg-amber-950/40 text-amber-500 rounded-full shrink-0">
                    <Store className="w-4 h-4" />
                  </div>
                  <span className="truncate">Marketplace</span>
                </button>

                {/* Ads Manager */}
                <button 
                  onClick={() => alert("Campaign Ads manager is initializing.")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 rounded-full shrink-0">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <span className="truncate">Ads Manager</span>
                </button>

                {/* Birthdays */}
                <button 
                  onClick={() => alert("Samuel Werunga is celebrate a birthday milestone today!")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-red-50 dark:bg-red-950/40 text-red-500 rounded-full shrink-0">
                    <Gift className="w-4 h-4" />
                  </div>
                  <span className="truncate">Birthdays</span>
                </button>

                {/* Events */}
                <button 
                  onClick={() => alert("LookUpto direct challenge events center")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-sky-50 dark:bg-sky-950/40 text-sky-500 rounded-full shrink-0">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <span className="truncate">Events</span>
                </button>

                {/* Feeds */}
                <button 
                  onClick={() => alert("Global feeds dashboard filters")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-lime-50 dark:bg-lime-950/40 text-lime-600 rounded-full shrink-0">
                    <Rss className="w-4 h-4" />
                  </div>
                  <span className="truncate">Feeds</span>
                </button>

                {/* Gaming Video */}
                <button 
                  onClick={() => { setActiveTab("watch"); window.scrollTo({ top: 350, behavior: "smooth" }); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-teal-50 dark:bg-teal-950/40 text-teal-600 rounded-full shrink-0">
                    <Tv className="w-4 h-4" />
                  </div>
                  <span className="truncate">Gaming Video</span>
                </button>

                {/* Messenger */}
                <button 
                  onClick={() => toggleDropdown("messenger")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-[#f3e8ff] dark:bg-[#201530] text-purple-600 rounded-full shrink-0">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <span className="truncate">Messenger</span>
                </button>

                {/* Messenger Kids */}
                <button 
                  onClick={() => alert("Safe Kids interactive forum disabled in sandbox betting app environment.")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-500 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all opacity-60"
                >
                  <div className="p-1.5 bg-emerald-50 dark:bg-[#152e1f] text-emerald-550 rounded-full shrink-0">
                    <Smile className="w-4 h-4" />
                  </div>
                  <span className="truncate">Messenger Kids</span>
                </button>

                {/* Orders and payments */}
                <button 
                  onClick={() => triggerPinCheck("wallet")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-blue-50 dark:bg-blue-952/40 text-blue-600 rounded-full shrink-0">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <span className="truncate">Orders and payments</span>
                </button>

                {/* Pages tab in the menu - Clicking toggles pages disclosure listing "Baridi SANA Page"! */}
                <div>
                  <button 
                    onClick={() => setPagesMenuOpen(!pagesMenuOpen)}
                    className="w-full flex items-center justify-between p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full shrink-0">
                        <Flag className="w-4 h-4 text-amber-500" />
                      </div>
                      <span className="truncate">Pages</span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-bold transition-transform duration-100 mr-1">
                      {pagesMenuOpen ? "▲" : "▼"}
                    </span>
                  </button>

                  {/* SUB-MENU DISCLOSURE: Includes Baridi SANA Page as explicitly requested! */}
                  {pagesMenuOpen && (
                    <div className="border-l-2 border-blue-500/30 dark:border-blue-500/20 pl-4 py-1 ml-5 space-y-1 text-xs">
                      <button 
                        onClick={() => { setActiveTab("profile"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                        className="w-full flex items-center gap-2 p-2 hover:bg-blue-50/60 dark:hover:bg-blue-900/20 rounded-lg text-left text-blue-600 dark:text-blue-400 transition-all font-black"
                      >
                        <span className="text-[9px]">🔵</span> 
                        <span>Baridi SANA Page</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Play games */}
                <button 
                  onClick={() => { setActiveTab("hub"); window.scrollTo({ top: 350, behavior: "smooth" }); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-blue-600 dark:text-blue-400 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-blue-105 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-full shrink-0">
                    <Gamepad2 className="w-4 h-4" />
                  </div>
                  <span className="truncate">Play games</span>
                </button>

                {/* Recent ad activity */}
                <button 
                  onClick={() => alert("No custom tracking statistics reported recently.")}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#323334] transition-all"
                >
                  <div className="p-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-full shrink-0">
                    <Activity className="w-4 h-4" />
                  </div>
                  <span className="truncate">Recent ad activity</span>
                </button>
              </div>
            )}

            {/* See more / See less button */}
            <button
              onClick={() => setMenuExpanded(!menuExpanded)}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg text-xs text-left font-black text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#1f2021] transition-all cursor-pointer"
            >
              <div className="p-1.5 bg-gray-200 dark:bg-[#3a3b3c] hover:bg-gray-300 rounded-full shrink-0 text-center flex items-center justify-center">
                {menuExpanded ? <ChevronUp className="w-3.5 h-3.5 text-gray-700 dark:text-gray-200" /> : <ChevronDown className="w-3.5 h-3.5 text-gray-700 dark:text-gray-200" />}
              </div>
              <span className="text-gray-900 dark:text-gray-200 font-extrabold">
                {menuExpanded ? "See less" : "See more"}
              </span>
            </button>
          </div>

          {/* Settle direct friends for challenges */}
          {activeTab === "groups" ? (
            <div className="space-y-4 px-1.5 py-3 bg-gray-55/40 dark:bg-zinc-900/10 rounded-2xl border border-gray-200 dark:border-zinc-820 shadow-xs">
              <div className="flex justify-between items-center mb-3 px-1 pb-1.5 border-b border-gray-150 dark:border-[#3e4042]">
                <h4 className="text-[10px] font-mono font-black uppercase text-gray-400 tracking-wider">GROUPS YOU JOINED</h4>
              </div>
              <div className="space-y-2.5">
                {groups.map((grp) => {
                  let initials = "ER";
                  let bgClass = "bg-rose-500 text-white";
                  let truncatedName = grp.name;
                  
                  if (grp.id === "g-1") {
                    initials = "ER";
                    bgClass = "bg-rose-600 text-white";
                  } else if (grp.id === "g-2") {
                    initials = "MD";
                    bgClass = "bg-[#2eb85c] text-white";
                  } else if (grp.id === "g-3") {
                    initials = "ZE";
                    bgClass = "bg-[#2080f0] text-white";
                  } else {
                    initials = grp.name.substring(0, 2).toUpperCase();
                    bgClass = "bg-[#ff1a53] text-white";
                  }

                  const isActive = activeGroupId === grp.id;

                  return (
                    <div
                      key={grp.id}
                      onClick={() => {
                        setActiveGroupId(grp.id);
                        setActiveTab("groups");
                      }}
                      className={`p-3 rounded-2xl flex items-center gap-3 cursor-pointer transition-all select-none border border-transparent ${
                        isActive
                          ? "bg-[#1877f2]/10 dark:bg-[#1877f2]/15 border-blue-500/20 shadow-xs"
                          : "hover:bg-gray-100/60 dark:hover:bg-zinc-800/35"
                      }`}
                    >
                      {/* Initials circle */}
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center font-black text-xs shrink-0 shadow-sm ${bgClass}`}>
                        {initials}
                      </div>

                      <div className="text-left font-sans min-w-0 flex-1">
                        <span className={`block text-xs font-extrabold tracking-tight leading-tight truncate ${isActive ? "text-[#1877f2] dark:text-blue-400" : "text-gray-800 dark:text-gray-200"}`}>
                          {truncatedName}
                        </span>
                        <span className="text-[10px] text-gray-500 font-mono block mt-0.5">
                          {(grp.membersCount / 1000).toFixed(1)}k members
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Create Group Button at bottom as shown in collo2.png */}
              <button
                onClick={() => setCreateGroupModalOpen(true)}
                className="w-full mt-3 py-2.5 bg-gray-100 hover:bg-gray-200 dark:bg-[#18191a] dark:hover:bg-[#323334] text-gray-850 dark:text-gray-100 text-xs font-sans font-extrabold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs border border-gray-200 dark:border-zinc-800"
              >
                + Create New Group
              </button>
            </div>
          ) : (
            <div>
              <div className="flex justify-between items-center mb-2.5 px-1 pb-1 border-b border-gray-150 dark:border-[#3e4042]">
                <h4 className="text-[10px] font-mono font-black uppercase text-gray-400 tracking-wider">Challenger Contacts</h4>
                {interactionsUnlocked ? (
                  <span className="text-[9px] text-green-500 font-bold uppercase tracking-widest font-mono">LIVE CONNECTED</span>
                ) : (
                  <button 
                    onClick={() => triggerPinCheck("interactions")}
                    className="text-[9px] text-blue-500 hover:underline font-bold flex items-center gap-1 font-mono"
                  >
                    <Lock className="w-2.5 h-2.5" /> Unlock P2P
                  </button>
                )}
              </div>

              {interactionsUnlocked ? (
                <div className="space-y-1">
                  {friendsList.map((fr) => (
                    <button
                      key={fr.id}
                      onClick={() => handleSelectOpponent(fr)}
                      className={`w-full flex items-center justify-between p-2 rounded-lg text-xs leading-none text-left transition-all ${
                        ratioOpponent?.id === fr.id
                          ? "bg-blue-500/10 text-[#1877f2] font-extrabold border-l-4 border-l-blue-600"
                          : "hover:bg-gray-100 dark:hover:bg-[#323334] text-gray-700 dark:text-gray-300"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <img src={fr.avatar} className="w-7 h-7 rounded-full" alt={fr.name} />
                          <span className={`absolute bottom-0 right-0 w-2 h-2 rounded-full border border-white ${
                            fr.status === "online" ? "bg-green-500" : fr.status === "idle" ? "bg-amber-500" : "bg-gray-300"
                          }`} />
                        </div>
                        <div>
                          <span className="block font-bold mb-0.5">{fr.name}</span>
                          <span className="text-[8px] text-gray-400">{fr.mutualFriends} mutual friends</span>
                        </div>
                      </div>
                      {ratioOpponent?.id === fr.id && <span className="text-[9px] bg-[#1877f2] text-white px-1.5 py-0.5 rounded uppercase font-bold leading-none scale-75">Target</span>}
                    </button>
                  ))}
                </div>
              ) : (
                <div 
                  onClick={() => triggerPinCheck("interactions")}
                  className="p-5 text-center text-xs text-blue-600 dark:text-blue-400 border border-dashed border-blue-200 dark:border-blue-900/50 hover:bg-blue-50/50 dark:hover:bg-blue-950/10 rounded-xl cursor-pointer"
                >
                  <Lock className="w-6 h-6 mx-auto mb-2 opacity-50 text-blue-500" />
                  <span className="font-bold">Unlock Contacts to Begin P2P Challenge Matching</span>
                </div>
              )}
            </div>
          )}
        </aside>

        {/* CENTER MAIN INTERACTIVE CONTENT AREA */}
        <main className={`${
          !sidebarVisible 
            ? (activeTab === "profile" ? "md:col-span-4 lg:col-span-4" : "md:col-span-3 lg:col-span-3") 
            : (activeTab === "profile" ? "md:col-span-3 lg:col-span-3" : "md:col-span-3 lg:col-span-2")
        } space-y-6`}>
          
          {/* DYNAMIC SHIFTED PROFILE TAB VIEW */}
          {activeTab === "profile" && (
            <ProfileView 
              walletBalance={walletBalance}
              onUpdateWallet={(amount) => setWalletBalance(amount)}
              triggerToast={(msg) => alert(msg)}
              activeProfilePage={activeProfilePage}
            />
          )}

          {/* 1. SOCIAL FEED TAB VIEW */}
          {activeTab === "home" && (
            <div className="space-y-6 text-left">
              {/* Facebook-style Stories Panel */}
              <div className="flex gap-2.5 overflow-x-auto pb-1.5 scrollbar-thin select-none">
                {/* User Story */}
                <div className="w-24 h-36 bg-white dark:bg-[#242526] rounded-xl shadow-sm border border-gray-150 dark:border-[#3e4042] shrink-0 text-center relative overflow-hidden group flex flex-col justify-between p-2">
                  <div className="h-2/3 bg-gray-100 rounded-lg overflow-hidden relative">
                    <img src="https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff" className="w-full h-full object-cover transition-transform group-hover:scale-105" alt="profile" />
                  </div>
                  <div className="absolute top-[80px] left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-blue-600 border-4 border-white dark:border-[#242526] flex items-center justify-center text-white">
                    <Plus className="w-4 h-4 fill-white font-bold" />
                  </div>
                  <p className="text-[10px] font-black text-gray-800 dark:text-gray-200">My Story</p>
                </div>

                {/* Friends wins summaries */}
                <div className="w-24 h-36 bg-gradient-to-t from-pink-900 to-indigo-950 rounded-xl shrink-0 relative overflow-hidden p-2.5 select-none text-white flex flex-col justify-between border border-[#3e4042]">
                  <span className="text-[14px] bg-pink-500 rounded-full w-6 h-6 flex justify-center items-center leading-none font-black text-xs border border-white">🔥</span>
                  <div className="text-left font-sans">
                    <p className="text-[9px] font-mono text-pink-300">David T.</p>
                    <p className="text-[10px] font-black leading-tight">Won $340 Draw Ratio Bet!</p>
                  </div>
                </div>

                <div className="w-24 h-36 bg-gradient-to-t from-emerald-900 to-teal-950 rounded-xl shrink-0 relative overflow-hidden p-2.5 select-none text-white flex flex-col justify-between border border-[#3e4042]">
                  <span className="text-[14px] bg-emerald-500 rounded-full w-6 h-6 flex justify-center items-center leading-none font-black text-xs border border-white">💰</span>
                  <div className="text-left font-sans">
                    <p className="text-[9px] font-mono text-teal-300">Sarah L.</p>
                    <p className="text-[10px] font-black leading-tight">matched liability $150 wins!</p>
                  </div>
                </div>
              </div>

              {/* Composer Box (Matches standard Facebook input with Lookupto Ratio Engine parameters) */}
              <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-4 border border-gray-250 dark:border-[#3e4042] transition-colors duration-300">
                <div className="flex gap-3 items-start pb-3 border-b border-gray-150 dark:border-zinc-800">
                  <img src="https://ui-avatars.com/api/?name=Collins+Dnego&background=1877f2&color=fff" className="w-9.5 h-9.5 rounded-full" alt="profile" />
                  
                  <div className="flex-1 space-y-3">
                    <input
                      type="text"
                      value={composerText}
                      onChange={(e) => setComposerText(e.target.value)}
                      placeholder="What's on your mind, Collins?"
                      className="w-full bg-transparent text-sm text-gray-900 dark:text-white placeholder-gray-400 outline-none border-none py-1.5 focus:ring-0"
                    />
                  </div>
                </div>

                {composerTaggedFriends.length > 0 && (
                  <div className="pt-2 text-xs text-blue-600 font-bold flex flex-wrap gap-1">
                    With: {composerTaggedFriends.map((f, i) => (
                       <span key={i} className="bg-blue-50 px-2 py-0.5 rounded-full">{f}</span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-3">
                  <div className="flex gap-2 text-xs font-semibold text-gray-500 dark:text-gray-450 overflow-x-auto">
                    <button className="flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-[#323334] px-3 py-1.5 rounded-md text-red-500 transition-colors whitespace-nowrap"><span>🎥</span> Live Game</button>
                    <button className="flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-[#323334] px-3 py-1.5 rounded-md text-green-500 transition-colors whitespace-nowrap"><span>📷</span> Photo/Video</button>
                    <button onClick={() => setTagModalOpen(true)} className="flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-[#323334] px-3 py-1.5 rounded-md text-blue-500 transition-colors whitespace-nowrap"><span>👥</span> Tag Friends</button>
                  </div>
                  <button
                    onClick={handlePublishStandardPost}
                    disabled={!composerText.trim()}
                    className="py-1.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-md transition-colors shrink-0"
                  >
                    Post Standard Info
                  </button>
                </div>
              </div>

              {/* Community Feed List */}
              <div className="space-y-4">
                {feedPosts.map((post) => (
                  <div key={post.id} className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-5 border border-gray-200 dark:border-[#3e4042] transition-colors duration-300">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        <img src={post.avatar} className="w-10 h-10 rounded-full border border-gray-200" alt="avatar" />
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-extrabold text-sm text-[#050505] dark:text-[#e4e6eb] leading-tight">{post.author}</h4>
                            {post.betCard && (
                              <span className="text-[9px] uppercase font-mono tracking-widest bg-amber-500/10 text-amber-600 dark:text-amber-400 px-1.5 py-0.5 rounded font-extrabold leading-none">Ratio bet propose</span>
                            )}
                          </div>
                          <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">{post.time}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed mb-4">{post.content}</p>

                    {/* If Betting challenge card attaches */}
                    {post.betCard && (
                      <div className="bg-gray-55/60 dark:bg-[#18191a] border border-gray-150 dark:border-zinc-800 rounded-xl overflow-hidden mb-4">
                        <div className="bg-gradient-to-r from-[#1877f2] to-blue-800 p-3.5 flex items-center justify-between text-white select-none">
                          <span className="text-xs font-mono font-bold tracking-tight">ESCROW POOL: {post.betCard.match}</span>
                          <span className="text-[10px] font-mono font-bold">Total escrow: ${post.betCard.totalPool.toFixed(2)}</span>
                        </div>
                        <div className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="text-xs space-y-1.5 leading-relaxed font-mono text-gray-500">
                            <div>Prediction target: <strong className="text-[#1877f2] dark:text-blue-400">{post.betCard.prediction}</strong></div>
                            <div>Creator stake holding: <strong className="text-gray-800 dark:text-gray-300">${post.betCard.stakes.creator.toFixed(2)}</strong></div>
                            <div>Opponent liability required: <strong className="text-red-500 font-extrabold">${post.betCard.stakes.opponents.toFixed(2)}</strong></div>
                            <div className="font-extrabold text-amber-600 dark:text-amber-500 pt-1 border-t border-gray-200 dark:border-zinc-700">🏛️ Org. Escrow Tax (2% upon full hold): ${(post.betCard.totalPool * 0.02).toFixed(2)}</div>
                          </div>

                          {post.betCard.status === "OPEN" ? (
                            <button
                              onClick={() => handleAcceptBetFromPost(post)}
                              className="w-full sm:w-auto py-2 px-5 bg-[#31a24c] hover:bg-[#2b8f41] text-white text-xs font-bold rounded-lg shadow-md transition-colors leading-none font-sans"
                            >
                              Match & Guarantee Spot
                            </button>
                          ) : (
                            <span className="w-full sm:w-auto text-center py-2 px-5 bg-gray-200 dark:bg-zinc-800 text-gray-400 dark:text-zinc-650 text-xs font-bold rounded-lg cursor-not-allowed uppercase tracking-widest">
                              🔒 Matches Secured
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Facebook essentials Like and dynamic Comment */}
                    <div className="flex items-center justify-between border-t border-gray-100 dark:border-zinc-800 pt-3">
                      <button 
                        onClick={() => handleLikePost(post.id)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-gray-150/40 dark:hover:bg-[#323334] rounded-lg text-xs font-bold transition-all transition-colors ${
                          post.hasLiked ? "text-blue-600 dark:text-blue-400" : "text-gray-500"
                        }`}
                      >
                        <ThumbsUp className={`w-4 h-4 ${post.hasLiked ? "fill-blue-500" : ""}`} /> Like ({post.likes})
                      </button>
                      
                      <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-gray-150/40 dark:hover:bg-[#323334] rounded-lg text-xs font-bold text-gray-500 transition-all transition-colors">
                        <MessageSquare className="w-4 h-4" /> Comment ({post.comments.length})
                      </button>

                      <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-gray-150/40 dark:hover:bg-[#323334] rounded-lg text-xs font-bold text-[#65676b] dark:text-gray-400 transition-all transition-colors">
                        <Share2 className="w-4 h-4" /> Share
                      </button>

                      <button 
                        onClick={() => setTagModalOpen(true)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-gray-150/40 dark:hover:bg-[#323334] rounded-lg text-xs font-bold text-[#65676b] dark:text-gray-400 transition-all transition-colors"
                      >
                        <UserCheck className="w-4 h-4" /> Tag
                      </button>

                      <button 
                        onClick={() => handleSaveItem('post', post.content, post.avatar)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-gray-150/40 dark:hover:bg-[#323334] rounded-lg text-xs font-bold text-[#65676b] dark:text-gray-400 transition-all transition-colors"
                      >
                        <Bookmark className="w-4 h-4" /> Save
                      </button>
                    </div>

                    {/* Comments block */}
                    {post.comments.length > 0 && (
                      <div className="mt-4 space-y-3 p-3.5 bg-gray-50 dark:bg-[#18191a] border border-gray-150 dark:border-zinc-800 rounded-lg">
                        {post.comments.map((comment, index) => (
                          <div key={index} className="text-xs text-left">
                            <span className="font-extrabold text-gray-800 dark:text-gray-250 mr-1.5">{comment.author}</span>
                            <span className="text-gray-650 dark:text-gray-300 leading-normal">{comment.content}</span>
                            <span className="block text-[10px] text-gray-400 mt-1">{comment.time}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. LIVE SPECTACLE WATCH VIEW */}
          {activeTab === "watch" && (
            <WatchView 
              selectedMatch={watchSelectedMatch} 
              onSelectOdd={handleSelectOdd}
              walletBalance={walletBalance}
              onSaveItem={handleSaveItem}
              onTagItem={() => setTagModalOpen(true)}
            />
          )}

          {/* M. MEMO TAB VIEW */}
          {activeTab === "memo" && (
            <div className="space-y-6 text-left animate-in fade-in duration-200 w-full max-w-2xl mx-auto">
              
              <div className="flex bg-white dark:bg-[#242526] p-1 rounded-xl shadow-sm border border-gray-200 dark:border-zinc-800 font-sans">
                <button
                  onClick={() => setMemoFeedMode("feed")}
                  className={`flex-1 p-2 rounded-lg text-sm font-black transition-all ${
                    memoFeedMode === "feed" ? "bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-gray-100 shadow-sm" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
                  }`}
                >
                  Memo Feed
                </button>
                <button
                  onClick={() => setMemoFeedMode("compose")}
                  className={`flex-1 p-2 rounded-lg text-sm font-black transition-all ${
                    memoFeedMode === "compose" ? "bg-blue-600 text-white shadow-sm" : "text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800"
                  }`}
                >
                  Post a Memo
                </button>
              </div>

              {memoFeedMode === "feed" && (
                <div className="space-y-4">
                  {memos.map(memo => (
                    <div key={memo.id} className="bg-white dark:bg-[#242526] rounded-xl shadow-sm border border-gray-200 dark:border-zinc-800 overflow-hidden font-sans">
                      <div className="p-4 flex items-center justify-between border-b border-gray-100 dark:border-zinc-800">
                        <div className="flex items-center gap-3">
                          <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(memo.author)}&background=1877f2&color=fff`} alt={memo.author} className="w-10 h-10 rounded-full" />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-bold text-gray-900 dark:text-gray-100">{memo.author}</h4>
                              <span className="text-[10px] uppercase font-black tracking-wider px-1.5 py-0.5 rounded-full border border-gray-200 dark:border-zinc-700 bg-gray-50 dark:bg-zinc-800 text-gray-600 dark:text-gray-300">
                                {memo.type === "fundraising" ? "Fundraising" : memo.type === "thanksgiving" ? "Thanksgiving" : "Success"} Memo
                              </span>
                            </div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-xs text-gray-500">{memo.timestamp}</span>
                              <span className="px-1.5 py-0.5 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] rounded-full flex items-center gap-1"><Users className="w-3 h-3" /> Past Opponent</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <p className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-3">{memo.text}</p>
                        {memo.tagged && (
                          <div className="mb-3 text-xs text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-900/20 px-3 py-1.5 rounded-lg inline-flex">
                            Tagged: {memo.tagged}
                          </div>
                        )}
                        <img src={memo.photo} alt="Memo reference" className="w-full h-auto rounded-xl border border-gray-100 dark:border-zinc-800" />
                      </div>
                      <div className="px-4 py-3 bg-gray-50 dark:bg-[#18191a] border-t border-gray-100 dark:border-zinc-800 flex justify-end gap-2">
                        <button 
                          onClick={() => handleSaveItem('memo', memo.text, memo.photo)}
                          className="flex items-center gap-1 px-4 py-1.5 bg-gray-200 hover:bg-gray-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-gray-800 dark:text-white rounded-full text-xs font-black transition-colors cursor-pointer"
                        >
                          <Bookmark className="w-3.5 h-3.5" /> Save
                        </button>
                        <button className="flex items-center gap-1 px-4 py-1.5 bg-gray-200 hover:bg-gray-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-gray-800 dark:text-white rounded-full text-xs font-black transition-colors cursor-pointer">
                          <Heart className="w-3.5 h-3.5" /> Support
                        </button>
                      </div>
                    </div>
                  ))}
                  {memos.length === 0 && (
                    <div className="p-8 text-center bg-white dark:bg-[#242526] rounded-xl border border-gray-200 dark:border-zinc-800">
                      <History className="w-10 h-10 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">No memos from your past opponents yet.</p>
                    </div>
                  )}
                </div>
              )}

               {memoFeedMode === "compose" && (
                <div className="bg-white dark:bg-[#242526] rounded-2xl shadow-sm border border-gray-200 dark:border-zinc-800 overflow-hidden font-sans">
                  <div className="bg-blue-600 p-4 shrink-0 text-white flex items-center justify-between">
                    <div>
                      <h3 className="font-black text-lg">Post a Memo</h3>
                      <p className="text-xs text-blue-100 font-medium">Visible only to users you've challenged with</p>
                    </div>
                  </div>
                  
                  <div className="p-5 space-y-5">
                    <div>
                      <label className="block text-[11px] font-black text-gray-500 uppercase tracking-wider mb-2">Memo Type</label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {["fundraising", "thanksgiving", "success"].map((type) => (
                          <button
                            key={type}
                            onClick={() => setMemoComposeType(type as any)}
                            className={`p-2.5 rounded-xl text-xs font-black capitalize transition-all border outline-none cursor-pointer ${
                              memoComposeType === type 
                                ? "bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/30 dark:border-blue-700 dark:text-blue-400 ring-1 ring-blue-500/50" 
                                : "bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100 dark:bg-zinc-800 dark:border-zinc-700 dark:text-gray-300 dark:hover:bg-zinc-700"
                            }`}
                          >
                            {type} Flow
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    {memoComposeType === "thanksgiving" && (
                      <div className="animate-in fade-in duration-200">
                        <label className="block text-[11px] font-black text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5"><Users className="w-3 h-3"/> Tag Past Opponent</label>
                        <input 
                          type="text" 
                          placeholder="Type their username to link profile..." 
                          value={memoComposeTagged}
                          onChange={(e) => setMemoComposeTagged(e.target.value)}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-zinc-700 bg-gray-50 dark:bg-[#18191a] text-gray-900 dark:text-white text-sm outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-zinc-800 transition-all font-medium"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-[11px] font-black text-gray-500 uppercase tracking-wider mb-2">Story details</label>
                      <textarea 
                        rows={4} 
                        placeholder={
                          memoComposeType === "fundraising" ? "Describe why you are raising funds and ask for help from your verified peers..." :
                          memoComposeType === "thanksgiving" ? "Write a thank you note for honoring the escrow perfectly..." :
                          "Share your verified success or win story from a recent pool..."
                        }
                        value={memoComposeText}
                        onChange={(e) => setMemoComposeText(e.target.value)}
                        className="w-full p-3 rounded-xl border border-gray-200 dark:border-zinc-700 bg-gray-50 dark:bg-[#18191a] text-gray-900 dark:text-white text-sm outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-zinc-800 transition-all font-medium resize-none shadow-inner"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs flex justify-between items-center tracking-wider mb-2 text-gray-500">
                        <span className="font-black text-[11px] uppercase">Attach Camera Photo</span>
                        <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-400 dark:border-emerald-800">Must be high quality</span>
                      </label>
                      
                      {!memoComposePhoto ? (
                        <div className="border-2 border-dashed border-gray-300 dark:border-zinc-600 rounded-xl p-8 flex flex-col items-center justify-center hover:bg-gray-50 dark:hover:bg-[#323334] transition-colors relative cursor-pointer bg-gray-50/50 dark:bg-[#18191a]">
                          <input 
                            type="file" 
                            accept="image/*" 
                            onChange={handleMemoPhotoSelect}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-zinc-700 flex items-center justify-center mb-3">
                            <Camera className="w-6 h-6 text-gray-500 dark:text-gray-400" />
                          </div>
                          <p className="text-sm font-black text-gray-700 dark:text-gray-300">Tap to upload proof photo</p>
                          <p className="text-[10px] text-gray-500 mt-1 font-bold">Only camera photos (high pixels). Fake/AI prohibited.</p>
                        </div>
                      ) : memoIsCompressing ? (
                        <div className="border border-gray-200 dark:border-zinc-700 rounded-xl p-8 text-center bg-gray-50 dark:bg-[#18191a] shadow-inner">
                          <div className="w-8 h-8 mx-auto border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-3"></div>
                          <p className="text-xs font-black text-blue-600 dark:text-blue-400">Compressing & Validating quality...</p>
                        </div>
                      ) : (
                        <div className="relative rounded-xl overflow-hidden border border-gray-200 dark:border-zinc-700 group hover:shadow-lg transition-all animate-in fade-in zoom-in-95 duration-200">
                          <img src={memoComposePhoto} alt="Selected" className="w-full h-56 object-cover" />
                          <button 
                            onClick={() => setMemoComposePhoto(null)}
                            title="Remove photo"
                            className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-rose-500 rounded-full text-white backdrop-blur-sm transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          <div className="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-between">
                            <span className="text-[10px] text-white flex items-center gap-1 font-black"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> HIGH-RES VERIFIED</span>
                            <span className="text-[10px] text-white font-mono bg-black/50 px-1.5 py-0.5 rounded font-black tracking-wider shadow">2.4MB Compressed</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 dark:bg-[#18191a] border-t border-gray-100 dark:border-zinc-800 flex justify-end gap-3 shrink-0">
                    <button 
                      onClick={() => setMemoFeedMode("feed")}
                      className="px-5 py-2 rounded-xl font-bold text-sm text-gray-600 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-zinc-700 transition-colors cursor-pointer outline-none"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleMemoSubmit}
                      disabled={!memoComposePhoto || !memoComposeText.trim() || memoIsCompressing}
                      className="px-6 py-2 rounded-xl font-black text-sm bg-[#1877f2] hover:bg-blue-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-sm text-white transition-all outline-none flex items-center gap-2"
                    >
                       <Send className="w-3.5 h-3.5" /> Post Memo
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* S. SAVED TAB VIEW */}
          {activeTab === "saved" && (
            <div className="space-y-6 text-left animate-in fade-in duration-200 w-full max-w-2xl mx-auto font-sans">
              
              <div className="bg-white dark:bg-[#242526] rounded-2xl shadow-sm border border-gray-200 dark:border-zinc-800 overflow-hidden">
                <div className="p-4 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-gray-50 dark:bg-[#18191a]">
                  <h3 className="font-black text-lg text-gray-900 dark:text-white flex items-center gap-2">
                    <Bookmark className="w-5 h-5 text-purple-500" />
                    Saved
                  </h3>
                </div>
                
                <div className="p-4 space-y-4">
                  {savedItems.length === 0 ? (
                    <div className="text-center p-8 text-gray-500 dark:text-gray-400">
                      <Bookmark className="w-10 h-10 mx-auto text-gray-300 dark:text-zinc-600 mb-2" />
                      <p className="font-bold">No saved items yet.</p>
                      <p className="text-xs">Save videos, posts, memos and pics to see them here.</p>
                    </div>
                  ) : (
                    savedItems.map(item => (
                      <div key={item.id} className="flex gap-4 p-4 rounded-xl border border-gray-100 dark:border-zinc-800 hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors cursor-pointer group">
                        <div className="w-20 h-20 bg-gray-200 dark:bg-zinc-700 rounded-lg flex-shrink-0 overflow-hidden flex items-center justify-center">
                          {item.thumb ? (
                             <img src={item.thumb} alt="thumbnail" className="w-full h-full object-cover" />
                          ) : item.icon === "Tv" ? (
                             <Tv className="w-8 h-8 text-gray-400 dark:text-gray-500" />
                          ) : (
                             <Camera className="w-8 h-8 text-gray-400 dark:text-gray-500" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-sm text-gray-900 dark:text-gray-100 line-clamp-2">{item.title}</h4>
                          <span className="text-xs text-gray-500 mt-1 block uppercase tracking-wider font-black">
                            {item.type} • {item.date}
                          </span>
                        </div>
                        <button className="text-gray-400 hover:text-rose-500 p-2 opacity-0 group-hover:opacity-100 transition-all rounded-full hover:bg-rose-50 dark:hover:bg-rose-950/30">
                          <Bookmark className="w-4 h-4 fill-current" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 3. TEAMS SYNDICATES GROUPS VIEW */}
          {activeTab === "groups" && (
            <GroupsView 
              walletBalance={walletBalance} 
              onUpdateWallet={(amt) => {
                setWalletBalance((prev) => prev + amt);
                setTransactions([
                  { id: `tx-${Date.now()}`, type: amt > 0 ? "bet_win" : "bet_stake", amount: Math.abs(amt), time: "Just now", target: "Joined clan syndicate pool" },
                  ...transactions
                ]);
              }}
              activeGroupId={activeGroupId}
              setActiveGroupId={setActiveGroupId}
              groups={groups}
              setGroups={setGroups}
              onNavigateTab={(tab) => setActiveTab(tab as any)}
              setCreateGroupModalOpen={setCreateGroupModalOpen}
            />
          )}

          {/* 4. MAIN ODDS CENTER AND LOOKUPTO SPORTSBOOK HUB */}
          {activeTab === "hub" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start animate-in fade-in duration-200">
              
              {/* Main Hub Content (Full Width) */}
              <div className="lg:col-span-3 space-y-6 relative">
              
              {/* Premium upgrade promo visual banner */}
              <div className="bg-gradient-to-r from-teal-900 to-indigo-950 p-5 rounded-xl text-white text-left relative overflow-hidden h-40 border border-gray-300 dark:border-[#3e4042]">
                <div className="flex justify-between items-start z-10 relative">
                  <div className="max-w-md">
                    <span className="bg-[#ffd000] text-black text-[10px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 rounded">WORLDCUP '26 GRAND CENTRAL</span>
                    <p className="text-xl font-black mt-2 leading-tight">
                      LookUpto Engine handles zero margins. Propose challenges directly to friends or launch to global stakers.
                    </p>
                  </div>
                  
                  <button
                    type="button"
                    onClick={() => setIsHubMenuOpen(true)}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-black rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer font-black shadow-xs leading-none active:scale-95 shrink-0"
                  >
                    <Menu className="w-3.5 h-3.5 animate-pulse" />
                    <span>Browse Directory Menu</span>
                  </button>
                </div>
                
                <div className="flex gap-2.5 mt-3 pt-3 border-t border-white/15 relative z-10">
                  <button onClick={() => setFlModalOpen(true)} className="py-1.5 px-4 bg-yellow-500 hover:bg-yellow-600 text-black font-extrabold text-xs rounded transition-all flex items-center gap-1">🎖️ Review Escrow Pools</button>
                </div>
              </div>

              {/* SLIDING DIRECTORY HAMBURGER MENU */}
              {isHubMenuOpen && (
                <div className="absolute inset-0 z-[100] flex select-none overflow-hidden rounded-xl">
                  {/* Backdrop */}
                  <div 
                    onClick={() => setIsHubMenuOpen(false)} 
                    className="absolute inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
                  />
                  
                  {/* Menu Panel */}
                  <div className="relative w-80 max-w-[90vw] h-full bg-white dark:bg-[#1c1d1f] shadow-2xl flex flex-col border-r border-gray-250 dark:border-zinc-800 animate-in slide-in-from-left duration-250 text-left z-10 rounded-l-xl">
                    {/* Header */}
                    <div className="p-4 border-b border-gray-150 dark:border-zinc-800 bg-gray-50 dark:bg-[#18191a] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🎯</span>
                        <div>
                          <h4 className="text-xs font-black uppercase tracking-wider text-gray-950 dark:text-white">Stadium Directory</h4>
                          <span className="text-[9.5px] font-mono text-gray-500 dark:text-gray-400">Live P2P Sports Exchange</span>
                        </div>
                      </div>
                      <button 
                        onClick={() => setIsHubMenuOpen(false)}
                        className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-zinc-800 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
                        type="button"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Content Scroll Area */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-5 scrollbar-thin">
                      
                      {/* Section 1: Standard Directories & Tabs */}
                      <div className="space-y-1.5">
                        <span className="block text-[9px] uppercase font-mono tracking-wider font-extrabold text-[#1877f2] dark:text-blue-400 mb-2">
                          ⚡ General Shortcuts
                        </span>
                        
                        {/* All Games */}
                        <button
                          type="button"
                          onClick={() => {
                            setHubActiveFilter("all");
                            setSelectedMatchForHub(null);
                            setIsHubMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border text-[11px] font-black flex items-center justify-between transition-all cursor-pointer ${
                            hubActiveFilter === "all"
                              ? "bg-blue-600 border-blue-600 text-white shadow-sm"
                              : "bg-gray-55 dark:bg-[#242526] hover:bg-gray-100 dark:hover:bg-[#323334] border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>🎮</span>
                            <span>All Games Tab</span>
                          </div>
                          <span className="text-[10px] font-mono opacity-80">{matches.length}</span>
                        </button>

                        {/* Highlights Games */}
                        <button
                          type="button"
                          onClick={() => {
                            setHubActiveFilter("highlights");
                            setSelectedMatchForHub(null);
                            setIsHubMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border text-[11px] font-black flex items-center justify-between transition-all cursor-pointer ${
                            hubActiveFilter === "highlights"
                              ? "bg-blue-600 border-blue-600 text-white shadow-sm"
                              : "bg-gray-55 dark:bg-[#242526] hover:bg-gray-100 dark:hover:bg-[#323334] border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>⭐</span>
                            <span>Highlights Games</span>
                          </div>
                          <span className="text-[10px] font-mono opacity-80">
                            {matches.filter(m => m.flActiveCount > 1300).length}
                          </span>
                        </button>

                        {/* Leagues Live Games */}
                        <button
                          type="button"
                          onClick={() => {
                            setHubActiveFilter("live");
                            setSelectedMatchForHub(null);
                            setIsHubMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border text-[11px] font-black flex items-center justify-between transition-all cursor-pointer ${
                            hubActiveFilter === "live"
                              ? "bg-blue-600 border-blue-600 text-white shadow-sm"
                              : "bg-gray-55 dark:bg-[#242526] hover:bg-gray-100 dark:hover:bg-[#323334] border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping mr-1" />
                            <span>Leagues Live Games</span>
                          </div>
                          <span className="text-[10px] font-mono opacity-80">
                            {matches.filter(m => m.status === "LIVE").length}
                          </span>
                        </button>

                        {/* Upcoming Games */}
                        <button
                          type="button"
                          onClick={() => {
                            setHubActiveFilter("upcoming");
                            setSelectedMatchForHub(null);
                            setIsHubMenuOpen(false);
                          }}
                          className={`w-full p-2.5 rounded-xl border text-[11px] font-black flex items-center justify-between transition-all cursor-pointer ${
                            hubActiveFilter === "upcoming"
                              ? "bg-blue-600 border-blue-600 text-white shadow-sm"
                              : "bg-gray-55 dark:bg-[#242526] hover:bg-gray-100 dark:hover:bg-[#323334] border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-gray-300"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Upcoming Fixtures</span>
                          </div>
                          <span className="text-[10px] font-mono opacity-80">
                            {matches.filter(m => m.status === "UPCOMING").length}
                          </span>
                        </button>
                      </div>

                      {/* Section 2: Countries directory dropdown with League standings */}
                      <div className="space-y-3">
                        <span className="block text-[9px] uppercase font-mono tracking-wider font-extrabold text-[#1877f2] dark:text-blue-400">
                          🗺️ Countries & Leagues Rankings
                        </span>

                        <div className="space-y-1.5">
                          {[
                            { name: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", leagues: ["English Premier League"] },
                            { name: "Spain", flag: "🇪🇸", leagues: ["Spanish La Liga"] },
                            { name: "Kenya", flag: "🇰🇪", leagues: ["Kenya Premier League (Ligi Bigi)"] },
                            { name: "USA", flag: "🇺🇸", leagues: ["NBA Playoffs"] },
                            { name: "Germany", flag: "🇩🇪", leagues: ["German Bundesliga"] },
                            { name: "Italy", flag: "🇮🇹", leagues: ["Italian Serie A"] }
                          ].map((countryObj) => {
                            const isCountryExpanded = hubExpandedCountry === countryObj.name;
                            return (
                              <div key={countryObj.name} className="border border-gray-150 dark:border-zinc-800/80 rounded-xl overflow-hidden bg-gray-55/20">
                                {/* Country Row Trigger */}
                                <button
                                  type="button"
                                  onClick={() => setHubExpandedCountry(isCountryExpanded ? null : countryObj.name)}
                                  className="w-full p-2.5 flex items-center justify-between text-xs font-bold hover:bg-gray-100 dark:hover:bg-[#323334] text-gray-800 dark:text-gray-200 transition-colors cursor-pointer"
                                >
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm">{countryObj.flag}</span>
                                    <span>{countryObj.name}</span>
                                  </div>
                                  <div className="flex items-center gap-1 text-[10px] text-gray-400">
                                    <span>{countryObj.leagues.length} {countryObj.leagues.length === 1 ? "League" : "Leagues"}</span>
                                    {isCountryExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                  </div>
                                </button>

                                {/* Country Leagues dropdown */}
                                {isCountryExpanded && (
                                  <div className="p-2 border-t border-gray-150 dark:border-zinc-800 bg-white dark:bg-[#18191a] space-y-2 animate-in slide-in-from-top-1.5 duration-100">
                                    {countryObj.leagues.map((league) => {
                                      const isActiveLeague = hubActiveFilter === `league:${league}`;
                                      const isRankingExpanded = hubExpandedLeagueRanking === league;
                                      return (
                                        <div key={league} className="space-y-1.5">
                                          <div className="flex items-center gap-1">
                                            {/* Filter games of this league */}
                                            <button
                                              type="button"
                                              onClick={() => {
                                                setHubActiveFilter(`league:${league}`);
                                                setSelectedMatchForHub(null);
                                                setIsHubMenuOpen(false);
                                              }}
                                              className={`flex-1 text-left p-2 rounded-lg text-[10.5px] font-black tracking-tight flex items-center gap-1.5 transition-all cursor-pointer ${
                                                isActiveLeague
                                                  ? "bg-blue-50 text-blue-600 dark:bg-blue-900/25 dark:text-blue-400"
                                                  : "hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-750 dark:text-gray-300"
                                              }`}
                                            >
                                              <span>🏆</span>
                                              <span className="truncate">{league}</span>
                                            </button>

                                            {/* Standings Ranking Dropdown trigger for league */}
                                            <button
                                              type="button"
                                              onClick={() => setHubExpandedLeagueRanking(isRankingExpanded ? null : league)}
                                              className={`p-1.5 rounded-lg border text-[10px] font-extrabold shrink-0 flex items-center gap-1 transition-all cursor-pointer ${
                                                isRankingExpanded 
                                                  ? "bg-amber-500 border-amber-500 text-black shadow-xs font-black"
                                                  : "border-gray-200 dark:border-zinc-800 text-gray-500 hover:text-gray-950 dark:hover:text-white"
                                              }`}
                                              title="Toggle Standings League Table Dropdown"
                                            >
                                              <span>Rankings</span>
                                              {isRankingExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                            </button>
                                          </div>

                                          {/* League rankings standings table inside Dropdown */}
                                          {isRankingExpanded && (
                                            <div className="p-2 bg-gray-55 dark:bg-[#1e1f21] rounded-lg border border-dashed border-gray-250 dark:border-zinc-800 text-[10px] space-y-1.5 animate-in fade-in duration-150">
                                              <div className="flex justify-between items-center text-[8.5px] font-mono uppercase tracking-widest font-black text-gray-400 pb-1 border-b border-gray-200 dark:border-zinc-800">
                                                <span>Pos / Team</span>
                                                <div className="flex gap-3">
                                                  <span>P</span>
                                                  <span>PTS</span>
                                                  <span className="w-12 text-center">FORM</span>
                                                </div>
                                              </div>

                                              {(leagueStandings[league] || []).map((row) => (
                                                <div key={row.team} className="flex justify-between items-center py-1 font-sans">
                                                  <div className="flex items-center gap-1.5 truncate max-w-[130px]">
                                                    <span className="font-mono text-[9px] font-bold text-gray-400 w-3">{row.pos}.</span>
                                                    <span className="font-extrabold tracking-tight text-gray-800 dark:text-gray-200 truncate">{row.team}</span>
                                                  </div>
                                                  <div className="flex items-center gap-3 font-mono">
                                                    <span className="text-gray-400">{row.played}</span>
                                                    <span className="font-black text-blue-600 dark:text-blue-400 w-5 text-right">{row.points}</span>
                                                    
                                                    {/* Form circles */}
                                                    <div className="flex gap-0.5 w-12 shrink-0 justify-end">
                                                      {row.form.slice(0, 3).map((f, i) => (
                                                        <span 
                                                          key={i} 
                                                          className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[7.5px] font-black text-white shrink-0 ${
                                                            f === "W" 
                                                              ? "bg-emerald-500" 
                                                              : f === "L" 
                                                                ? "bg-red-500" 
                                                                : "bg-gray-400"
                                                          }`}
                                                        >
                                                          {f}
                                                        </span>
                                                      ))}
                                                    </div>
                                                  </div>
                                                </div>
                                              ))}
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                    </div>

                    {/* Footer attribution */}
                    <div className="p-4 bg-gray-50 dark:bg-[#18191a] border-t border-gray-150 dark:border-zinc-800 text-center select-none">
                      <p className="text-[9px] text-gray-450 dark:text-gray-455 font-mono">
                        🏟️ Direct LookUpto Matching Engine • Built with Integrity
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Sub navigation categories */}
              <div className="flex bg-white dark:bg-[#242526] p-1.5 border border-gray-200 dark:border-[#3e4042] rounded-xl overflow-x-auto gap-2 text-xs font-bold items-center select-none">
                {["Soccer", "Table Tennis", "Boxing", "Basketball", "Tennis"].map((sport) => (
                  <button
                    key={sport}
                    onClick={() => {
                      setHubActiveFilter("all");
                      setSelectedHubSport(sport);
                      setSelectedMatchForHub(null);
                    }}
                    className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                      selectedHubSport === sport && hubActiveFilter === "all"
                        ? "bg-blue-600 text-white"
                        : "hover:bg-gray-150/40 dark:hover:bg-[#323334] text-gray-550 dark:text-gray-400"
                    }`}
                  >
                    {sport}
                  </button>
                ))}
              </div>

              {/* Sports matches table lists */}
              <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md border border-gray-200 dark:border-[#3e4042] transition-colors duration-300 text-left overflow-hidden">
                {selectedMatchForHub ? (
                  <div className="divide-y divide-gray-150 dark:divide-zinc-805">
                    {/* Inline Game Hub Header */}
                    <div className="p-4 bg-gray-50 dark:bg-[#18191a] border-b border-gray-200 dark:border-zinc-800 flex justify-between items-center flex-wrap gap-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedMatchForHub(null)}
                          className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-250 text-xs font-black rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-xs border border-gray-300 dark:border-zinc-700"
                          title="Back to all soccer fixtures"
                        >
                          ← Back to All Fixtures
                        </button>
                        <span className="text-xs font-bold text-gray-800 dark:text-white uppercase tracking-wider hidden sm:inline ml-1">
                          Stadium Match Center
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-[#a3e635] text-[#121314] text-[9.5px] font-black uppercase px-2 py-0.5 rounded font-mono tracking-wider shadow-xs">
                          ★ Betika! Live Hub
                        </span>
                      </div>
                    </div>

                    {/* Integrated mini-scoreboard header inside container */}
                    <div className="p-4 sm:p-5 bg-gradient-to-b from-gray-50/50 to-white dark:from-[#1e1f21]/35 dark:to-[#242526] border-b border-gray-200 dark:border-zinc-850 text-center select-none relative">
                      <div className="text-[9.5px] text-emerald-600 dark:text-[#a3e635] font-mono font-bold tracking-widest uppercase mb-1">
                        🏆 {selectedMatchForHub.league}
                      </div>

                      <div className="grid grid-cols-7 items-center justify-between gap-1 mt-2">
                        {/* Home Team */}
                        <div className="col-span-3 text-right">
                          <span className="block text-[9px] text-gray-400 font-mono">HOME TEAM</span>
                          <span className="font-extrabold text-xs sm:text-sm text-gray-900 dark:text-white block truncate leading-tight mt-0.5">
                            {selectedMatchForHub.homeTeam}
                          </span>
                        </div>

                        {/* SCORE & TIME */}
                        <div className="col-span-1 flex flex-col items-center justify-center">
                          <div className="text-sm font-black text-blue-600 dark:text-[#a3e635] font-mono tracking-wider">
                            {selectedMatchForHub.status === "LIVE" ? (selectedMatchForHub.score || "1:0") : "0:0"}
                          </div>
                          <div className="text-[8.5px] text-red-500 font-mono font-bold whitespace-nowrap animate-pulse mt-0.5 bg-red-100 dark:bg-red-950/40 px-1 py-0.5 rounded leading-none">
                            {selectedMatchForHub.status === "LIVE" ? "45:10'" : "UPCOMING"}
                          </div>
                        </div>

                        {/* Away Team */}
                        <div className="col-span-3 text-left">
                          <span className="block text-[9px] text-gray-400 font-mono">AWAY TEAM</span>
                          <span className="font-extrabold text-xs sm:text-sm text-gray-900 dark:text-white block truncate leading-tight mt-0.5">
                            {selectedMatchForHub.awayTeam}
                          </span>
                        </div>
                      </div>

                      {/* Quick Statistics Banner */}
                      <div className="mt-3.5 pt-3 border-t border-gray-150 dark:border-zinc-800 flex justify-center items-center gap-4 text-[10px] text-gray-500 font-mono">
                        <span className="flex items-center gap-1">🟨 1 yellow card</span>
                        <span className="flex items-center gap-1">📊 3 corners</span>
                        <span className="text-emerald-500 text-[9.5px] font-bold">● Match Live Tracker Connected</span>
                      </div>
                    </div>

                    {/* Category Selection Tabs inside container */}
                    <div className="bg-gray-50/75 dark:bg-[#1c1d1f]/35 px-4 py-2.5 border-b border-gray-150 dark:border-zinc-805 overflow-x-auto flex gap-1.5 select-none scrollbar-none">
                      {(["All Markets", "Main", "First Half", "Goals", "Cards and Corners"] as const).map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setInlineHubTab(tab)}
                          className={`px-3 py-1.5 text-[10.5px] font-extrabold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                            inlineHubTab === tab
                              ? "bg-blue-600 text-white dark:bg-[#a3e635] dark:text-black shadow-xs"
                              : "bg-gray-200/50 text-gray-600 dark:bg-[#252628] dark:text-gray-400 hover:text-gray-800 dark:hover:text-white"
                          }`}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>

                    {/* Accordions Stack inside container */}
                    <div className="divide-y divide-gray-150 dark:divide-zinc-805 bg-white dark:bg-[#242526]">
                      {/* ACCORDION 1: 1x2 Outcome */}
                      {(inlineHubTab === "All Markets" || inlineHubTab === "Main" || inlineHubTab === "First Half") && (
                        <div>
                          <div 
                            onClick={() => setInlineHubCollapsed(prev => ({ ...prev, oneXtwo: !prev.oneXtwo }))}
                            className="w-full px-4 py-3 bg-gray-50/60 dark:bg-[#18191a]/30 hover:bg-gray-100 dark:hover:bg-[#323334] flex justify-between items-center text-[10.5px] font-black uppercase tracking-wide cursor-pointer transition-colors"
                          >
                            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <span>⚡</span> 1X2 Standard Outcome
                            </span>
                            {inlineHubCollapsed.oneXtwo ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-500" />}
                          </div>

                          {!inlineHubCollapsed.oneXtwo && (
                            <div className="grid grid-cols-3 gap-3 p-4 bg-white dark:bg-[#242526] animate-in fade-in duration-100">
                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, `${selectedMatchForHub.homeTeam} (Home Win)`, selectedMatchForHub.odds["1"])}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase select-none">1 (Home Win)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">{selectedMatchForHub.homeTeam}</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{selectedMatchForHub.odds["1"].toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Draw", selectedMatchForHub.odds.X)}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase select-none">X (Draw Match)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">Draw Match</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{selectedMatchForHub.odds.X.toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, `${selectedMatchForHub.awayTeam} (Away Win)`, selectedMatchForHub.odds["2"])}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase select-none">2 (Away Win)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">{selectedMatchForHub.awayTeam}</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{selectedMatchForHub.odds["2"].toFixed(2)}</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* ACCORDION 2: Who Will Score 2nd Goal */}
                      {(inlineHubTab === "All Markets" || inlineHubTab === "Goals") && (
                        <div>
                          <div 
                            onClick={() => setInlineHubCollapsed(prev => ({ ...prev, nextGoal: !prev.nextGoal }))}
                            className="w-full px-4 py-3 bg-gray-50/60 dark:bg-[#18191a]/30 hover:bg-gray-100 dark:hover:bg-[#323334] flex justify-between items-center text-[10.5px] font-black uppercase tracking-wide cursor-pointer transition-colors"
                          >
                            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <span>⚽</span> Who Will Score 2nd Goal
                            </span>
                            {inlineHubCollapsed.nextGoal ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-500" />}
                          </div>

                          {!inlineHubCollapsed.nextGoal && (
                            <div className="grid grid-cols-3 gap-3 p-4 bg-white dark:bg-[#242526] animate-in fade-in duration-100">
                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, `${selectedMatchForHub.homeTeam} to Score 2nd Goal`, Math.max(1.15, selectedMatchForHub.odds["1"] * 0.9))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">1 (Home Team)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">{selectedMatchForHub.homeTeam}</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{Math.max(1.15, selectedMatchForHub.odds["1"] * 0.9).toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "No 2nd Goal Scored", Math.max(2.1, selectedMatchForHub.odds.X * 0.8))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">None (No Scorer)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">No 2nd Scorer</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{Math.max(2.1, selectedMatchForHub.odds.X * 0.8).toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, `${selectedMatchForHub.awayTeam} to Score 2nd Goal`, Math.max(1.15, selectedMatchForHub.odds["2"] * 0.9))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">2 (Away Team)</span>
                                <span className="text-gray-800 dark:text-gray-200 text-xs font-black block truncate mt-0.5">{selectedMatchForHub.awayTeam}</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1">@{Math.max(1.15, selectedMatchForHub.odds["2"] * 0.9).toFixed(2)}</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* ACCORDION 3: Total Goals Margin 2.5 */}
                      {(inlineHubTab === "All Markets" || inlineHubTab === "Goals") && (
                        <div>
                          <div 
                            onClick={() => setInlineHubCollapsed(prev => ({ ...prev, totalOverUnder: !prev.totalOverUnder }))}
                            className="w-full px-4 py-3 bg-gray-50/60 dark:bg-[#18191a]/30 hover:bg-gray-100 dark:hover:bg-[#323334] flex justify-between items-center text-[10.5px] font-black uppercase tracking-wide cursor-pointer transition-colors"
                          >
                            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <span>🥅</span> Total Goals Margin (Over / Under 2.5)
                            </span>
                            {inlineHubCollapsed.totalOverUnder ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-500" />}
                          </div>

                          {!inlineHubCollapsed.totalOverUnder && (
                            <div className="grid grid-cols-2 gap-3 p-4 bg-white dark:bg-[#242526] animate-in fade-in duration-100">
                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Total Goals: Over 2.5", Math.max(1.35, selectedMatchForHub.odds["1"] * 0.75))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">Over 2.5 Goals</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">Over 2.5 Scored Goals</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@{Math.max(1.35, selectedMatchForHub.odds["1"] * 0.75).toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Total Goals: Under 2.5", Math.max(1.45, selectedMatchForHub.odds["2"] * 0.85))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">Under 2.5 Goals</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">Under 2.5 Scored Goals</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@{Math.max(1.45, selectedMatchForHub.odds["2"] * 0.85).toFixed(2)}</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* ACCORDION 4: GG / NG Both Teams to Score */}
                      {(inlineHubTab === "All Markets" || inlineHubTab === "Main" || inlineHubTab === "Goals") && (
                        <div>
                          <div 
                            onClick={() => setInlineHubCollapsed(prev => ({ ...prev, btts: !prev.btts }))}
                            className="w-full px-4 py-3 bg-gray-50/60 dark:bg-[#18191a]/30 hover:bg-gray-100 dark:hover:bg-[#323334] flex justify-between items-center text-[10.5px] font-black uppercase tracking-wide cursor-pointer transition-colors"
                          >
                            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <span>🤝</span> Both Teams to Score (GG / NG)
                            </span>
                            {inlineHubCollapsed.btts ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-500" />}
                          </div>

                          {!inlineHubCollapsed.btts && (
                            <div className="grid grid-cols-2 gap-3 p-4 bg-white dark:bg-[#242526] animate-in fade-in duration-100">
                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Both Teams to Score: Yes (GG)", Math.max(1.4, selectedMatchForHub.odds.X * 0.4))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">YES (GG)</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">Both sides will score</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@{Math.max(1.4, selectedMatchForHub.odds.X * 0.4).toFixed(2)}</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Both Teams to Score: No (NG)", Math.max(1.3, selectedMatchForHub.odds["1"] * 0.7))}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase">NO (NG)</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">At least one sheets clean</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@{Math.max(1.3, selectedMatchForHub.odds["1"] * 0.7).toFixed(2)}</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* ACCORDION 5: Corners Over/Under 9.5 */}
                      {(inlineHubTab === "All Markets" || inlineHubTab === "Cards and Corners") && (
                        <div>
                          <div 
                            onClick={() => setInlineHubCollapsed(prev => ({ ...prev, corners: !prev.corners }))}
                            className="w-full px-4 py-3 bg-gray-50/60 dark:bg-[#18191a]/30 hover:bg-gray-100 dark:hover:bg-[#323334] flex justify-between items-center text-[10.5px] font-black uppercase tracking-wide cursor-pointer transition-colors"
                          >
                            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                              <span>🚩</span> Total Match Corners Over/Under 9.5
                            </span>
                            {inlineHubCollapsed.corners ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-500" />}
                          </div>

                          {!inlineHubCollapsed.corners && (
                            <div className="grid grid-cols-2 gap-3 p-4 bg-white dark:bg-[#242526] animate-in fade-in duration-100">
                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Match Corners: Over 9.5", 1.85)}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase font-mono">Over 9.5 Corners</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">10 or more corners to occur</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@1.85</span>
                              </button>

                              <button 
                                onClick={() => handleSelectOdd(selectedMatchForHub, "Match Corners: Under 9.5", 1.92)}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-left transition-all group font-sans relative cursor-pointer"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold uppercase font-mono">Under 9.5 Corners</span>
                                <span className="text-gray-850 dark:text-gray-200 text-xs font-black block mt-1">9 or fewer corners to occur</span>
                                <span className="text-sm font-black text-blue-600 dark:text-[#a3e635] block mt-1.5">@1.92</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Integrated footer with close button */}
                    <div className="p-4 bg-gray-50 dark:bg-[#18191a] border-t border-gray-200 dark:border-zinc-805 flex justify-between items-center">
                      <span className="text-[10px] text-gray-450 dark:text-gray-400 font-mono select-none">
                        🛡️ Zero house margin • Pure ratio peer-to-peer stakers
                      </span>
                      <button
                        onClick={() => setSelectedMatchForHub(null)}
                        className="py-1 px-3 bg-red-600/10 hover:bg-red-600/20 text-red-650 dark:text-red-400 font-bold text-[10px] uppercase rounded transition-all cursor-pointer"
                      >
                        Close Live Markets
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="p-4 bg-gray-50 dark:bg-[#18191a] border-b border-gray-200 dark:border-zinc-800 flex justify-between items-center flex-wrap gap-2 select-none">
                      <h3 className="text-xs sm:text-sm font-bold text-gray-800 dark:text-white flex items-center gap-1.5">
                        {hubActiveFilter === "all" ? (
                          <>⚽ Highlights Live & Upcoming {selectedHubSport} Fixtures</>
                        ) : hubActiveFilter === "highlights" ? (
                          <>⭐ Top Highlights Games Directory</>
                        ) : hubActiveFilter === "upcoming" ? (
                          <>📅 Upcoming Stadium Fixtures</>
                        ) : hubActiveFilter === "live" ? (
                          <>🟢 Active Live Sports Games</>
                        ) : hubActiveFilter.startsWith("league:") ? (
                          <>🏆 {hubActiveFilter.replace("league:", "")} Matches & Stats</>
                        ) : (
                          <>🗺️ {hubActiveFilter.replace("country:", "")} Matches</>
                        )}
                      </h3>
                      <button onClick={fetchRealSportsGames} className="p-1.5 hover:bg-gray-200 dark:hover:bg-zinc-800 rounded-md transition-colors text-blue-500 cursor-pointer" title="Sync live odds">
                        <RefreshCw className="w-4 h-4 animate-spin-once" />
                      </button>
                    </div>

                    {hubActiveFilter !== "all" && (
                      <div className="p-3 bg-amber-500/10 dark:bg-amber-500/5 border-b border-amber-500/20 flex justify-between items-center flex-wrap gap-2 text-xs select-none animate-in fade-in slide-in-from-top-1 duration-200">
                        <div className="flex items-center gap-2 text-amber-700 dark:text-amber-450 font-bold">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
                          <span>
                            Directory Match: <span className="underline font-black uppercase text-[10px] tracking-tight">{
                              hubActiveFilter === "highlights"
                                ? "Highlights Games"
                                : hubActiveFilter === "upcoming"
                                  ? "Upcoming Only"
                                  : hubActiveFilter === "live"
                                    ? "Live Only"
                                    : hubActiveFilter.replace("league:", "League: ").replace("country:", "Country: ")
                            }</span>
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setHubActiveFilter("all");
                            setSelectedMatchForHub(null);
                          }}
                          className="px-2.5 py-1 bg-amber-500 text-black hover:bg-amber-600 font-black uppercase text-[9px] tracking-wider rounded transition-all cursor-pointer active:scale-95 shadow-sm shrink-0"
                        >
                          Show Standard Sports Tab
                        </button>
                      </div>
                    )}

                    {isFeedLoading ? (
                      <div className="p-12 text-center text-xs text-gray-500 flex flex-col items-center justify-center gap-2">
                        <RefreshCw className="w-6 h-6 animate-spin text-blue-500" />
                        <span>Retrieving recent odds and fixtures dynamically...</span>
                      </div>
                    ) : getFilteredMatches().length === 0 ? (
                      <div className="p-12 text-center text-xs text-gray-500">
                        No active games matching this directory shortcut right now. Select "All Games Tab" or sync to find others!
                      </div>
                    ) : (
                      <div className="divide-y divide-gray-150 dark:divide-zinc-805">
                        {getFilteredMatches().map((m) => (
                          <div key={m.id} className="p-4 sm:flex items-center justify-between gap-4 hover:bg-gray-55/35 dark:hover:bg-zinc-800/10 transition-colors">
                            <div className="flex-1 space-y-2 text-left">
                              <div className="flex items-center gap-2 flex-wrap text-[10px] font-mono font-bold leading-none">
                                <span className="text-gray-400">{m.league}</span>
                                <span className={m.status === "LIVE" ? "text-red-500 animate-pulse bg-red-100 dark:bg-red-950/40 px-1 py-0.5 rounded" : "text-blue-500 bg-blue-100 dark:bg-blue-950/40 px-1 py-0.5 rounded"}>
                                  {m.status} • {m.time}
                                </span>
                              </div>

                              <div 
                                onClick={() => {
                                  setSelectedMatchForHub(m);
                                }}
                                className="flex items-center justify-between max-w-sm cursor-pointer group"
                                title="Click to open Game Hub & view all 30+ markets"
                              >
                                <h4 className="text-sm font-black text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-[#a3e635] transition-colors duration-150">{m.homeTeam}</h4>
                                <span className="text-xs text-gray-400 font-mono mx-2 select-none">Vs</span>
                                <h4 className="text-sm font-black text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-[#a3e635] transition-colors duration-150">{m.awayTeam}</h4>
                              </div>

                              <p className="text-[11px] text-gray-500 leading-normal max-w-md italic mb-2">{m.trivia}</p>

                              {/* Dynamic FL Active Count Button */}
                              <div className="pt-1 select-none">
                                <button
                                  onClick={() => {
                                    setSelectedMatchForEscrowPool(m);
                                    setFlModalOpen(true);
                                  }}
                                  className="inline-flex items-center gap-1.5 py-1 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-lg text-[10px] font-mono font-black border border-amber-500/20 transition-all cursor-pointer"
                                >
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                                  <span>🔥 FL Count: {m.flActiveCount} active stakers</span>
                                  <span className="opacity-70 ml-1.5 underline">View & Match Liability →</span>
                                </button>
                              </div>
                            </div>

                            {/* Odds columns */}
                            <div className="grid grid-cols-3 gap-2.5 shrink-0 mt-3 sm:mt-0 max-w-xs w-full sm:w-auto">
                              <button
                                onClick={() => handleSelectOdd(m, m.homeTeam, m.odds["1"])}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-center transition-all group"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold">1</span>
                                <span className="text-sm font-black text-gray-800 dark:text-white">{m.odds["1"].toFixed(2)}</span>
                              </button>
                              
                              <button
                                onClick={() => handleSelectOdd(m, "Draw", m.odds.X)}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-center transition-all group"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold">X</span>
                                <span className="text-sm font-black text-gray-800 dark:text-white">{m.odds.X.toFixed(2)}</span>
                              </button>

                              <button
                                onClick={() => handleSelectOdd(m, m.awayTeam, m.odds["2"])}
                                className="p-3 bg-gray-50 hover:bg-blue-50 dark:bg-[#18191a] dark:hover:bg-[#323334] rounded-lg border border-gray-200 dark:border-zinc-800 text-center transition-all group"
                              >
                                <span className="block text-[8px] text-gray-400 group-hover:text-blue-500 font-mono font-bold">2</span>
                                <span className="text-sm font-black text-gray-800 dark:text-white">{m.odds["2"].toFixed(2)}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        )}

          {/* 5. PAGES DIRECTORY VIEW (Differentiating Personal & Page Profile Accounts) */}
          {activeTab === "pages" && (
            <div className="space-y-6 text-left animate-in fade-in duration-200">
              
              {/* Cover intro */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 rounded-2xl text-white relative overflow-hidden shadow-lg">
                <div className="absolute right-0 top-0 opacity-10 transform translate-x-12 -translate-y-12">
                  <Compass className="w-96 h-96" />
                </div>
                <div className="relative z-10 max-w-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="bg-blue-500 text-white text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border border-blue-400">
                      Directory Hub
                    </span>
                    <span className="bg-amber-500 text-black text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full">
                      Page vs Profile Manager
                    </span>
                  </div>
                  <h2 className="text-2xl font-black tracking-tight font-sans">
                    Switchable Pages & Profile Hub
                  </h2>
                  <p className="text-xs text-blue-100 font-medium leading-relaxed font-sans">
                    Under standard social protocols, a <strong>Personal Profile Account</strong> represents your human identity (like Collins Dnego or Zephaniah Mwangi), while a <strong>Page Profile Account</strong> is a public-facing entity (like Baridi SANA or Collo Dnego) handled by administrators. Switch between them instantly below.
                  </p>
                </div>
              </div>

              {/* Main Matrix Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Visual section: Personal Profile accounts managed */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center px-1">
                    <h3 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-blue-500" />
                      <span>Personal Accounts (Switchable)</span>
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-gray-100 dark:bg-zinc-800 text-gray-500 rounded-full font-bold">Standard</span>
                  </div>

                  <div className="space-y-3 font-sans">
                    {Object.entries(PROFILES)
                      .filter(([_, p]) => p.type === "user")
                      .map(([key, p]) => {
                        const isActive = activeProfilePage === key;
                        return (
                          <div 
                            key={key} 
                            className={`p-4 rounded-2xl bg-white dark:bg-[#242526] border transition-all ${
                              isActive 
                                ? "border-blue-500 shadow-md ring-2 ring-blue-500/10" 
                                : "border-gray-200 dark:border-zinc-700 hover:border-gray-300 dark:hover:border-zinc-650"
                            }`}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <img src={p.avatar} alt={p.name} className="w-12 h-12 rounded-full border border-gray-150 shadow-xs object-cover" />
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-1">
                                    <span>{p.name}</span>
                                    {isActive && <CheckCircle className="w-3.5 h-3.5 text-blue-500" />}
                                  </h4>
                                  <span className="text-[10px] bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-extrabold px-1.5 py-0.5 rounded uppercase font-mono tracking-wide">
                                    Profile Account
                                  </span>
                                  <p className="text-[11px] text-gray-500 dark:text-gray-400 pt-1 line-clamp-1">
                                    {p.desc}
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            <div className="mt-4 pt-3 border-t border-gray-100 dark:border-zinc-800 flex items-center justify-between">
                              <span className="text-[10px] text-gray-400 font-mono">
                                ID: {key.toLowerCase().replace(/\s/g, "_")}
                              </span>
                              <button
                                onClick={() => {
                                  setActiveProfilePage(key);
                                  alert(`Successfully switched active user: ${p.name}`);
                                }}
                                disabled={isActive}
                                className={`text-[11px] font-black py-1.5 px-3.5 rounded-xl cursor-pointer transition-all ${
                                  isActive
                                    ? "bg-blue-105 text-blue-500 dark:bg-blue-950/25 dark:text-blue-400 cursor-default"
                                    : "bg-blue-600 hover:bg-blue-700 text-white shadow-xs active:scale-95"
                                }`}
                              >
                                {isActive ? "Currently Active" : "Log In as User"}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Visual section: Page Profile accounts managed */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center px-1">
                    <h3 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5">
                      <Flag className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <span>Managed Pages (Switchable)</span>
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-yellow-105 text-amber-500 rounded-full font-bold">Public Page</span>
                  </div>

                  <div className="space-y-3 font-sans">
                    {Object.entries(PROFILES)
                      .filter(([_, p]) => p.type === "page")
                      .map(([key, p]) => {
                        const isActive = activeProfilePage === key;
                        return (
                          <div 
                            key={key} 
                            className={`p-4 rounded-2xl bg-white dark:bg-[#242526] border transition-all ${
                              isActive 
                                ? "border-amber-500 shadow-md ring-2 ring-amber-500/10" 
                                : "border-gray-200 dark:border-zinc-700 hover:border-gray-300 dark:hover:border-zinc-650"
                            }`}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <img src={p.avatar} alt={p.name} className="w-12 h-12 rounded-full border border-gray-150 shadow-xs object-cover" />
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-1">
                                    <span>{p.name}</span>
                                    {isActive && <CheckCircle className="w-3.5 h-3.5 text-amber-500" />}
                                  </h4>
                                  <span className="text-[10px] bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 font-extrabold px-1.5 py-0.5 rounded uppercase font-mono tracking-wide text-amber-600">
                                    Page Profile
                                  </span>
                                  <p className="text-[11px] text-gray-500 dark:text-gray-400 pt-1 line-clamp-1">
                                    {p.desc}
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-gray-100 dark:border-zinc-800 flex items-center justify-between">
                              <span className="text-[10px] text-gray-400 font-mono">
                                ID: {key.toLowerCase().replace(/\s/g, "_")}
                              </span>
                              <div className="flex gap-2">
                                <button
                                  onClick={() => {
                                    setActiveTab("profile");
                                    setActiveProfilePage(key);
                                    window.scrollTo({ top: 0, behavior: "smooth" });
                                  }}
                                  className="text-[11px] font-bold py-1.5 px-3 bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-200 rounded-xl transition-all"
                                >
                                  View Page
                                </button>
                                <button
                                  onClick={() => {
                                    setActiveProfilePage(key);
                                    alert(`Successfully switched active identity to page: ${p.name}`);
                                  }}
                                  disabled={isActive}
                                  className={`text-[11px] font-black py-1.5 px-3.5 rounded-xl cursor-pointer transition-all ${
                                    isActive
                                      ? "bg-amber-105 text-amber-600 dark:bg-amber-950/25 dark:text-amber-400 cursor-default"
                                      : "bg-amber-500 hover:bg-amber-600 text-black shadow-xs active:scale-95"
                                  }`}
                                >
                                  {isActive ? "Currently Active" : "Switch Identity"}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

              </div>

              {/* Informational Compare card */}
              <div className="p-4 bg-gray-50 dark:bg-[#1a1b1c] rounded-2xl border border-gray-150 dark:border-zinc-800 font-sans space-y-3">
                <h3 className="text-xs font-black text-gray-900 dark:text-gray-150 uppercase tracking-wide">
                  💡 High Fidelity Identity Architecture
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <h4 className="font-bold text-blue-600 flex items-center gap-1">
                      <span>👤 Profile Accounts (e.g. Zephaniah Mwangi)</span>
                    </h4>
                    <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                      These represent normal users. They hold LookUpto client wallets, follow other sports predictors, publish staker proposals, and manage individual fan pages.
                    </p>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-amber-550 flex items-center gap-1">
                      <span>🚩 Page Profile Accounts (e.g. Baridi SANA, Collo Dnego)</span>
                    </h4>
                    <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                      Represent public fan clubs, corporate staker channels, or official community spaces. They have custom follower bases, post specific news, and are switchable directly in the live session perspective.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}
        </main>

        {/* RIGHT SIDEBAR - Ads and Quick Shortcuts */}
        {activeTab !== "profile" && (
          <aside className="md:col-span-1 space-y-6 md:sticky md:top-[80px] md:max-h-[calc(100vh-100px)] md:overflow-y-auto">

          {/* Embedded LookUpto Escrow Calculator Engine */}
          <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-4 border border-gray-250 dark:border-[#3e4042] text-left transition-colors duration-300">
            <div className="flex items-center justify-between font-black text-gray-800 dark:text-white pb-2.5 border-b border-gray-150 dark:border-zinc-800 mb-4">
              <h3 className="text-xs sm:text-sm font-black flex items-center gap-1.5">
                📊 lookUpto Escrow Engine
              </h3>
              {ratioOddValue > 0 && (
                <button 
                  onClick={() => { setRatioMatchName(""); setRatioOddName(""); setRatioOddValue(0); }}
                  className="text-[10px] text-gray-400 hover:text-red-500 font-bold uppercase transition-colors cursor-pointer"
                  type="button"
                >
                  Reset
                </button>
              )}
            </div>

            {ratioOddValue > 0 ? (
              <div className="space-y-4 animate-in fade-in duration-200">
                
                {/* Selected match card */}
                {ratioMatch && (
                  <div className="p-3 bg-blue-50/70 dark:bg-zinc-800/40 rounded-xl border border-dashed border-blue-200 dark:border-zinc-700 text-xs text-left">
                    <span className="block text-[8px] uppercase font-mono tracking-widest font-black text-gray-400 dark:text-gray-500 mb-1">
                      Target Match & Prediction Option Selected
                    </span>
                    <div className="font-extrabold text-[#1877f2] dark:text-blue-400 text-xs leading-tight mb-0.5 truncate">
                      🏟️ {ratioMatch.homeTeam} vs {ratioMatch.awayTeam}
                    </div>
                    <div className="text-[10.5px] font-bold text-gray-700 dark:text-gray-300">
                      Prediction: <span className="text-emerald-500">{ratioOddName}</span> (@{ratioOddValue.toFixed(2)})
                    </div>
                  </div>
                )}

                {/* Total Challenge Pool budget */}
                <div className="space-y-3">
                  <div className="text-left">
                    <label className="block text-[9px] text-gray-400 font-bold uppercase mb-1">Total Pool size ($)</label>
                    <input
                      type="number"
                      value={ratioTotalPool}
                      onChange={(e) => setRatioTotalPool(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full bg-gray-50 dark:bg-[#18191a] border border-gray-200 dark:border-zinc-800 rounded-lg p-2 font-black font-mono text-center text-gray-900 dark:text-white outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                  <div className="text-left">
                    <label className="block text-[9px] text-gray-400 font-bold uppercase mb-1">No. of Opponents</label>
                    <div className="grid grid-cols-2 gap-1.5 text-[9.5px] font-bold">
                      <button
                        type="button"
                        onClick={() => setNumOpponents(1)}
                        className={`py-2 rounded-lg border text-center transition-all cursor-pointer ${
                          numOpponents === 1
                            ? "bg-blue-600 border-blue-600 text-white"
                            : "bg-gray-50 dark:bg-[#18191a] border-gray-200 dark:border-zinc-805 text-gray-600 dark:text-gray-400 hover:bg-gray-100"
                        }`}
                      >
                        1v1 Mode
                      </button>
                      <button
                        type="button"
                        onClick={() => setNumOpponents(2)}
                        className={`py-2 rounded-lg border text-center transition-all cursor-pointer ${
                          numOpponents === 2
                            ? "bg-blue-600 border-blue-600 text-white"
                            : "bg-gray-50 dark:bg-[#18191a] border-gray-200 dark:border-zinc-805 text-gray-600 dark:text-gray-400 hover:bg-gray-100"
                        }`}
                      >
                        3-way Mode
                      </button>
                    </div>
                  </div>
                </div>

                {/* Opponent Selection list if 1v1 mode */}
                {numOpponents === 1 && ratioMatch && (
                  <div className="text-left space-y-1">
                    <label className="block text-[9px] uppercase font-mono tracking-wider font-extrabold text-gray-450 mb-1">
                      Opponent selection target
                    </label>
                    <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono font-bold">
                      {["1", "X", "2"].filter(sel => sel !== ratioSelection).map((sel) => {
                        const selName = sel === "1" ? "Home" : sel === "X" ? "Draw" : "Away";
                        const selOdds = sel === "1" ? ratioMatch.odds["1"] : sel === "X" ? ratioMatch.odds.X : ratioMatch.odds["2"];
                        return (
                          <button
                            key={sel}
                            type="button"
                            onClick={() => setOpponentSelection(sel as "1"|"X"|"2")}
                            className={`py-1.5 px-2 rounded-lg border text-center transition-all cursor-pointer ${
                              opponentSelection === sel
                                ? "bg-blue-600 border-blue-600 text-white"
                                : "bg-gray-50 dark:bg-[#18191a] border-gray-200 dark:border-zinc-800 text-gray-750 dark:text-gray-300 hover:bg-gray-100"
                            }`}
                          >
                            {selName} (@{selOdds.toFixed(2)})
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Rules & Banter comment input */}
                <div className="text-left">
                  <label className="block text-[9px] uppercase font-mono tracking-wider font-extrabold text-gray-400 mb-1">
                    Banter & Specific Challenge Rules
                  </label>
                  <textarea
                    value={composerText}
                    onChange={(e) => setComposerText(e.target.value)}
                    placeholder="e.g. Backing my prediction, winner takes all the escrow!"
                    className="w-full bg-gray-50 dark:bg-[#18191a] text-gray-900 dark:text-white border border-gray-200 dark:border-zinc-800 rounded-lg p-2 text-xs outline-none focus:ring-1 focus:ring-blue-500 max-h-20 resize-none"
                  />
                </div>

                {/* Stakes Split Readout directly calculated from same engine states */}
                <div className="bg-blue-50 dark:bg-blue-950/25 p-3 rounded-lg border border-blue-105 dark:border-blue-900/30 text-left space-y-1.5 font-mono text-xs">
                  <div className="flex justify-between font-extrabold border-b border-blue-200/40 pb-1 mb-1 text-blue-700 dark:text-blue-300">
                    <span>You ({calculateLookuptoStakes().userSelectionName}):</span>
                    <span>{calculateLookuptoStakes().userPct.toFixed(1)}% = ${getCreatorStake().toFixed(2)}</span>
                  </div>
                  {calculateLookuptoStakes().opponents.map((opp, idx) => (
                    <div key={idx} className="flex justify-between text-gray-700 dark:text-gray-300">
                      <span>{opp.name} ({opp.selectionName}):</span>
                      <span>{opp.pct.toFixed(1)}% = ${opp.stake.toFixed(2)}</span>
                    </div>
                  ))}
                  {isSendoffEnabled && (
                    <div className="flex justify-between font-bold text-purple-600 dark:text-purple-400 border-t border-dashed border-gray-200 dark:border-zinc-800 pt-1.5">
                      <span>📣 Sendoff Spot (1%):</span>
                      <span>${(ratioTotalPool * 0.01).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-amber-600 dark:text-amber-500 border-t border-dashed border-gray-200 dark:border-zinc-800 pt-1.5 mt-1.5">
                    <span>🏛️ Org. Escrow Tax (2% upon full hold):</span>
                    <span>${(ratioTotalPool * 0.02).toFixed(2)}</span>
                  </div>
                  <div className="pt-1.5 border-t border-gray-150 dark:border-zinc-850 flex justify-between font-black text-gray-800 dark:text-gray-100">
                    <span>Escrow Lock Value:</span>
                    <span>${ratioTotalPool.toFixed(2)}</span>
                  </div>
                </div>

                {/* Sponsor Peer Sendoffs Option */}
                <div className="space-y-2.5 bg-gray-50/50 dark:bg-zinc-800/10 p-3 rounded-xl border border-gray-200 dark:border-zinc-800 text-left">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-gray-455 cursor-pointer" htmlFor="sidebar-sendoff-cb">
                      Sponsor Sendoff Spots
                    </label>
                    <input
                      type="checkbox"
                      id="sidebar-sendoff-cb"
                      checked={isSendoffEnabled}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setIsSendoffEnabled(checked);
                        if (!checked) setPostToGlobal(false);
                      }}
                      className="w-4 h-4 rounded text-blue-600 border-gray-300 focus:ring-blue-500 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={sendoffsCount}
                      onChange={(e) => setSendoffsCount(Math.max(1, parseInt(e.target.value) || 1))}
                      disabled={!isSendoffEnabled}
                      min="1"
                      className="w-20 bg-white dark:bg-[#18191a] text-gray-900 dark:text-white border border-gray-150 dark:border-zinc-800 rounded-lg p-1.5 font-mono text-xs text-center outline-none disabled:opacity-50"
                    />
                    <span className="text-[10px] text-gray-500 font-semibold italic">
                      {isSendoffEnabled ? `x 5 = ${sendoffsCount * 5} spots syndicates` : `1v1 regular mode active`}
                    </span>
                  </div>

                  {isSendoffEnabled && (
                    <div className="p-2.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-left animate-in slide-in-from-top-1">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[9.5px] uppercase font-mono tracking-wider font-extrabold text-purple-600 dark:text-purple-400 cursor-pointer flex items-center gap-1" htmlFor="sidebar-global-channels-cb">
                          <span>🌐</span> Post to Global Sportsbook
                        </label>
                        <input
                          type="checkbox"
                          id="sidebar-global-channels-cb"
                          checked={postToGlobal}
                          onChange={(e) => setPostToGlobal(e.target.checked)}
                          className="w-4 h-4 rounded text-purple-600 border-purple-500/30 focus:ring-purple-500 cursor-pointer"
                        />
                      </div>
                      <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-normal">
                        Promote challenge inside other stakers feeds.
                      </p>
                    </div>
                  )}
                </div>

                {/* Action buttons */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={handlePostBetChallenge}
                    className="py-2.5 bg-blue-650 hover:bg-blue-700 hover:scale-[1.01] active:scale-[0.98] text-white text-[11px] font-black rounded-lg transition-all text-center cursor-pointer shadow-xs leading-none"
                  >
                    Publish Bet
                  </button>
                  <button
                    type="button"
                    onClick={() => setInviteModalOpen(true)}
                    className="py-2.5 bg-[#31a24c] hover:bg-[#2b8f41] hover:scale-[1.01] active:scale-[0.98] text-white text-[11px] font-black rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer shadow-xs leading-none"
                  >
                    <span>📲</span> Invite Buddy
                  </button>
                </div>

              </div>
            ) : (
              <div className="py-7 text-center select-none">
                <div className="inline-flex p-2.5 bg-blue-50 dark:bg-blue-900/15 text-blue-600 dark:text-blue-400 rounded-full animate-bounce mb-2">
                  <Gamepad2 className="w-6 h-6" />
                </div>
                <h4 className="text-xs font-extrabold text-gray-700 dark:text-gray-300">
                  No Odd Option Selected
                </h4>
                <p className="text-[10.5px] text-gray-400 leading-normal mt-1 max-w-[200px] mx-auto">
                  Click on any match decimal odd on the left to load dynamic LookUpto calculations.
                </p>
              </div>
            )}
          </div>

          {/* BRAND AD ADVERTISEMENT BANNER CAROUSELS */}
          {/* BRAND AD ADVERTISEMENT BANNER CAROUSELS */}
          <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md overflow-hidden p-1.5 border border-gray-200 dark:border-[#3e4042]">
            <div className="bg-gray-100 dark:bg-[#18191a] h-44 rounded-lg flex flex-col justify-center items-center p-4 relative select-none">
              <div className="text-center space-y-2">
                <span className="text-emerald-500 text-[10px] font-mono font-bold uppercase tracking-wide border border-emerald-500 px-2.5 py-1 rounded">SPONSOR INTERACTION</span>
                <h4 className="text-lg font-black leading-tight text-gray-800 dark:text-gray-200">Zero bookmaker take advantage</h4>
                <p className="text-xs text-gray-500 leading-normal max-w-xs mx-auto">
                  Matched peer escrow locks funds on-chain instantly, paying out 100% of the ratio pools standard value. No house margins!
                </p>
              </div>
            </div>
          </div>

          {/* Quick Odds selectors panel on right side desktop situated at viewable position */}
          {matches.length > 0 && (
            <div className="bg-white dark:bg-[#242526] rounded-xl shadow-md p-4 border border-gray-200 dark:border-[#3e4042] text-left">
              <h4 className="text-xs font-mono font-black uppercase text-gray-400 tracking-wider mb-2.5 flex items-center gap-1.5">
                <span>⚡</span> Live Odds Shortcuts
              </h4>
              <div className="space-y-3.5 max-h-[350px] overflow-y-auto pr-1">
                {matches.slice(0, 4).map((m) => (
                  <div key={m.id} className="p-3 bg-gray-50 dark:bg-[#18191a] border border-gray-250 dark:border-zinc-850 rounded-xl">
                    <span className="block text-[8px] font-mono font-black text-gray-400 tracking-widest uppercase mb-1">{m.status} • {m.league}</span>
                    <div 
                      onClick={() => {
                        setSelectedMatchForHub(m);
                        setActiveTab("hub");
                      }}
                      className="flex justify-between items-start mb-2 cursor-pointer group"
                      title="Click to open Game Hub & view all 30+ markets"
                    >
                      <strong className="text-xs text-gray-850 dark:text-gray-200 group-hover:text-blue-600 dark:group-hover:text-[#a3e635] leading-tight block max-w-[150px] truncate transition-colors">{m.homeTeam} v {m.awayTeam}</strong>
                      <span className="text-[9px] text-red-500 font-black shrink-0 font-mono bg-red-50 dark:bg-red-950/20 px-1 py-0.5 rounded border border-red-200/20">{m.time}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button onClick={() => handleSelectOdd(m, m.homeTeam, m.odds["1"])} className="py-1.5 bg-white dark:bg-[#242526] hover:bg-blue-50 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 text-[10px] font-mono font-extrabold text-[#1877f2] dark:text-blue-400 rounded-lg shadow-xs hover:border-blue-500/50 transition-colors cursor-pointer">
                        1 @{m.odds["1"].toFixed(2)}
                      </button>
                      <button onClick={() => handleSelectOdd(m, "Draw", m.odds.X)} className="py-1.5 bg-white dark:bg-[#242526] hover:bg-blue-50 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 text-[10px] font-mono font-extrabold text-[#1877f2] dark:text-blue-400 rounded-lg shadow-xs hover:border-blue-500/50 transition-colors cursor-pointer">
                        X @{m.odds.X.toFixed(2)}
                      </button>
                      <button onClick={() => handleSelectOdd(m, m.awayTeam, m.odds["2"])} className="py-1.5 bg-white dark:bg-[#242526] hover:bg-blue-50 dark:hover:bg-zinc-800 border border-gray-200 dark:border-zinc-800 text-[10px] font-mono font-extrabold text-[#1877f2] dark:text-blue-400 rounded-lg shadow-xs hover:border-blue-500/50 transition-colors cursor-pointer">
                        2 @{m.odds["2"].toFixed(2)}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>
        )}

      </div>

      {/* ALL MODAL ESCROW PORTALS */}
      <PasswordModal
        isOpen={passwordModalOpen}
        onClose={() => setPasswordModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      <FLPoolModal
        isOpen={flModalOpen}
        onClose={() => {
          setFlModalOpen(false);
          setSelectedMatchForEscrowPool(null);
        }}
        walletBalance={walletBalance}
        onMatchChallenge={handleMatchFromFlModal}
        filterMatchName={selectedMatchForEscrowPool ? `${selectedMatchForEscrowPool.homeTeam} vs ${selectedMatchForEscrowPool.awayTeam}` : undefined}
      />



      <InviteModal
        isOpen={inviteModalOpen}
        onClose={() => setInviteModalOpen(false)}
        isSendoffEnabled={isSendoffEnabled}
        sendoffsCount={sendoffsCount}
        matchName={ratioMatchName}
        onSendInvites={handleInviteFriendsCallback}
      />

      {/* TAG FRIENDS MODAL */}
      {tagModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[2200] flex justify-center items-center p-4">
          <div className="bg-white dark:bg-[#242526] rounded-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 font-sans">
            <div className="p-4 border-b border-gray-100 dark:border-zinc-800 flex justify-between items-center">
              <h3 className="font-extrabold text-gray-900 dark:text-white">Tag Friends</h3>
              <button onClick={() => setTagModalOpen(false)} className="bg-gray-100 dark:bg-zinc-800 p-1.5 rounded-full text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-2">
              <input 
                type="text" 
                placeholder="Search friends..." 
                className="w-full bg-gray-100 dark:bg-[#3a3b3c] border-none rounded-xl px-4 py-2 text-sm text-gray-900 dark:text-white outline-none mb-2"
              />
              <div className="max-h-64 overflow-y-auto w-full px-1 space-y-1">
                {[
                  "Alex Morgan", "Sarah Chen", "Erick Chelody", "Abuu Kiprotich", "Collins Dnego"
                ].map(friend => {
                  const isTagged = composerTaggedFriends.includes(friend);
                  return (
                    <button 
                      key={friend}
                      onClick={() => {
                        if (isTagged) {
                          setComposerTaggedFriends(prev => prev.filter(f => f !== friend));
                        } else {
                          setComposerTaggedFriends(prev => [...prev, friend]);
                        }
                      }}
                      className="w-full text-left flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors"
                    >
                      <span className={`text-sm font-bold ${isTagged ? 'text-blue-600 dark:text-blue-400' : 'text-gray-900 dark:text-white'}`}>{friend}</span>
                      {isTagged && <CheckCircle2 className="w-5 h-5 text-blue-500" />}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="p-4 border-t border-gray-100 dark:border-zinc-800 bg-gray-50 dark:bg-[#18191a]">
              <button 
                onClick={() => setTagModalOpen(false)}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RESIZABLE ACCEPT CHALLENGE WINDOW */}
      {challengeWindowOpen && challengeWindowData && (() => {
        const calcAcceptLiability = () => {
          const oppStake = challengeWindowData.oppStake;
          const estimatedSumOfOdds = 3.4;
          const estimatedOdds = 2.10;
          const calcRatio = estimatedOdds / estimatedSumOfOdds;
          return oppStake * (1 - calcRatio);
        };
        const activeDebitValue = calcAcceptLiability();
        
        return (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-[2100] flex justify-center items-center p-4">
            <div 
              style={{ width: `${challengeWindowWidth}px`, height: `${challengeWindowHeight}px` }} 
              className="bg-white dark:bg-[#242526] rounded-2xl shadow-2xl border-2 border-blue-500/30 dark:border-zinc-700/80 flex flex-col relative overflow-hidden animate-in zoom-in-95 duration-150"
            >
              {/* Resize grabber handle in bottom-right floor */}
              <div 
                onMouseDown={startResize}
                className="absolute bottom-0 right-0 w-6 h-6 cursor-se-resize z-[2201] flex items-end justify-end p-0.5"
                title="Drag to resize window"
              >
                <svg className="w-4 h-4 text-gray-400 dark:text-gray-500 hover:text-blue-500 transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                  <line x1="21" y1="21" x2="9" y2="9" strokeLinecap="round" />
                  <line x1="21" y1="15" x2="15" y2="21" strokeLinecap="round" />
                </svg>
              </div>

              {/* Header block with elegant gradient styling */}
              <div className="px-5 py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-650 text-white flex justify-between items-center shrink-0 border-b border-white/10 select-none">
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">🤝</span>
                  <div>
                    <h3 className="font-extrabold text-sm tracking-wide">P2P Escrow - Accept Challenge</h3>
                    <p className="text-[10px] opacity-80 font-mono">Interactive Settlement Workspace</p>
                  </div>
                </div>
                <button 
                  onClick={() => setChallengeWindowOpen(false)}
                  className="p-1 hover:bg-white/15 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>

              {/* Body Content - scrollable parameters */}
              <div className="flex-1 overflow-y-auto p-5 text-left space-y-4 font-sans text-gray-800 dark:text-gray-200">
                <div>
                  <span className="text-[10px] bg-blue-500/10 text-[#1877f2] dark:text-blue-450 px-2 py-0.5 rounded font-mono font-bold uppercase">
                    Game Matchup Details
                  </span>
                  <h2 className="text-base font-black text-gray-900 dark:text-white mt-1 flex items-center gap-2">
                    🏟️ {challengeWindowData.matchName}
                  </h2>
                </div>

                {/* Roller Container details */}
                <div className="p-3.5 bg-gray-50 dark:bg-black/15 border border-gray-150 dark:border-zinc-800 rounded-xl space-y-1.5 font-mono text-xs">
                  <div className="flex justify-between items-center pb-1.5 border-b border-gray-200/50 dark:border-zinc-850">
                    <span className="text-gray-400">Roller Name:</span>
                    <span className="text-gray-850 dark:text-white font-extrabold">@{challengeWindowData.oppUser}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Range:</span>
                    <span className="text-red-500 font-bold">
                      {challengeWindowData.oppStake >= 100 ? "Professional High Roller ($100 - $500)" : "Casual Match Escrow ($10 - $99)"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Total proposed stake:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">${challengeWindowData.oppStake.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Proposed Market:</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-bold">{challengeWindowData.prediction}</span>
                  </div>
                </div>

                {/* Markets highlighted in Red and Blue */}
                <div>
                  <span className="text-[10px] uppercase font-mono text-gray-400 font-black block mb-2">
                    🎯 Odd Market Position Comparison
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg border border-red-500/20 bg-red-500/5 text-left">
                      <span className="text-[9px] font-bold text-red-500 uppercase block mb-1">🔴 Roller Odd Market</span>
                      <span className="font-extrabold text-xs text-red-600 dark:text-red-400 block font-mono">
                        {challengeWindowData.prediction}
                      </span>
                    </div>
                    <div className="p-3 rounded-lg border border-blue-500/20 bg-blue-500/5 text-left">
                      <span className="text-[9px] font-bold text-blue-500 uppercase block mb-1">🔵 Proposer (Acceptor) Odd Market</span>
                      {isRequestingChange && requestedMarketInput ? (
                        <span className="font-extrabold text-xs text-blue-600 dark:text-blue-450 block font-mono">
                          {requestedMarketInput}
                        </span>
                      ) : (
                        <span className="font-extrabold text-xs text-gray-500 dark:text-gray-400 block font-mono italic">
                          Counter-bet recommendation
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Request Market Change Button */}
                <div className="p-3.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-black/5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-black text-gray-800 dark:text-gray-200 uppercase font-mono">
                      🔄 Counter-bet specification
                    </span>
                    <button
                      onClick={() => {
                        const state = !isRequestingChange;
                        setIsRequestingChange(state);
                        if (state) {
                          setRequestedMarketInput("Over 2.5 Goals @2.40");
                        } else {
                          setRequestedMarketInput("");
                        }
                      }}
                      className={`text-[10px] px-2.5 py-1 font-bold rounded-lg transition-all cursor-pointer ${
                        isRequestingChange 
                          ? "bg-red-500/10 text-red-600 hover:bg-red-500/20" 
                          : "bg-blue-600 hover:bg-blue-700 text-white"
                      }`}
                    >
                      {isRequestingChange ? "Cancel Counter Proposal" : "Request Market Change"}
                    </button>
                  </div>
                  
                  <p className="text-[10.5px] text-gray-400 leading-normal mb-2">
                    Request custom odds market change to ignore recommendation and set your own chosen market outcome structure.
                  </p>

                  {isRequestingChange && (
                    <div className="space-y-2 animate-in slide-in-from-top-1.5 duration-100">
                      <label className="text-[10px] text-gray-400 font-mono block">Change To Selected Market Choice:</label>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <select 
                          value={requestedMarketInput} 
                          onChange={(e) => setRequestedMarketInput(e.target.value)}
                          className="flex-1 bg-white dark:bg-[#1c1d1e] border border-gray-201 dark:border-zinc-800 p-1.5 text-xs rounded-md font-mono focus:ring-1 focus:ring-blue-500 text-gray-800 dark:text-gray-200 focus:outline-none"
                        >
                          <option value="Over 2.5 Goals @2.40">Over 2.5 Goals @2.40</option>
                          <option value="Under 2.5 Goals @1.85">Under 2.5 Goals @1.85</option>
                          <option value="Both Teams To Score @1.90">Both Teams To Score @1.90</option>
                          <option value="Draw (No Bet) @2.10">Draw (No Bet) @2.10</option>
                          <option value="Handicap (+1) @1.65">Handicap (+1) @1.65</option>
                        </select>
                        <input
                          type="text"
                          value={requestedMarketInput}
                          onChange={(e) => setRequestedMarketInput(e.target.value)}
                          placeholder="Or type custom prediction choice..."
                          className="flex-1 bg-white dark:bg-[#1c1d1e] border border-gray-201 dark:border-zinc-800 p-1.5 text-xs rounded-md focus:ring-1 focus:ring-blue-500 text-gray-900 dark:text-white focus:outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Yes No Cancel confirmation wrapper block */}
                <div className="p-3.5 bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-900/45 rounded-xl space-y-1">
                  <span className="font-extrabold text-[11px] text-yellow-800 dark:text-yellow-400 block mb-0.5">
                    ⚠️ Are you sure to accept the challenge?
                  </span>
                  <div className="text-[10.5px] text-gray-600 dark:text-gray-300 leading-normal">
                    {isRequestingChange ? (
                      <span>
                        Market counter-proposal registered: <strong className="text-blue-600 dark:text-blue-400 font-mono">"{requestedMarketInput}"</strong>. 
                        This submits a pending request notification directly to @{challengeWindowData.oppUser} to Accept or Decline. 
                        <strong className="text-gray-950 dark:text-white font-extrabold"> Balance NOT debited immediately!</strong>
                      </span>
                    ) : (
                      <span>
                        Standard matched bet configuration: <strong className="text-indigo-600 dark:text-indigo-400 font-mono">"{challengeWindowData.prediction}"</strong>. 
                        A stake of <strong className="text-red-500 font-black">${activeDebitValue.toFixed(2)}</strong> will be <strong className="text-red-500 font-black">debited immediately</strong> and locked in global escrow pool.
                        <div className="font-extrabold text-amber-600 dark:text-amber-500 pt-1 mt-1 border-t border-yellow-200 dark:border-yellow-900/45">🏛️ Org. Escrow Tax (2% upon full hold): ${((activeDebitValue + challengeWindowData.oppStake) * 0.02).toFixed(2)}</div>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Resizable Footer controls */}
              <div className="p-4 bg-gray-50 dark:bg-[#1c1d1e] border-t border-gray-200 dark:border-zinc-800/80 flex justify-between items-center shrink-0 select-none">
                <div className="text-[11px] font-mono">
                  {isRequestingChange ? (
                    <span className="text-amber-600 dark:text-amber-400 font-extrabold flex items-center gap-1">⏰ Pending counter decision</span>
                  ) : (
                    <span className="text-gray-500">Debited from main: <strong className="text-red-500 font-black">${(activeDebitValue + ((activeDebitValue + challengeWindowData.oppStake) * 0.02)).toFixed(2)}</strong></span>
                  )}
                </div>

                <div className="flex gap-1.5">
                  <button
                    onClick={() => {
                      if (!isRequestingChange) {
                        // Regular match - debit immediately
                        const totalTaxFloat = (activeDebitValue + challengeWindowData.oppStake) * 0.02;
                        const totalRequiredToPayForFloat = activeDebitValue + totalTaxFloat;

                        if (walletBalance < totalRequiredToPayForFloat) {
                          alert(`Your wallet balance is insufficient ($${walletBalance.toFixed(2)}) to lock this $${activeDebitValue.toFixed(2)} liability and $${totalTaxFloat.toFixed(2)} Org Tax.`);
                          return;
                        }
                        setWalletBalance((prev) => prev - totalRequiredToPayForFloat);
                        setTransactions([
                          {
                            id: `tx-${Date.now()}`,
                            type: "bet_stake",
                            amount: activeDebitValue,
                            time: "Just now",
                            target: `Matched Escrow: @${challengeWindowData.oppUser} on ${challengeWindowData.matchName}`,
                          },
                          {
                            id: `tx-tax-${Date.now()}`,
                            type: "withdraw" as const,
                            amount: totalTaxFloat,
                            time: "Just now",
                            target: `Org. Escrow Tax (2% full hold)`,
                          },
                          ...transactions,
                        ]);
                        alert(`Successfully matched the P2P liability of @${challengeWindowData.oppUser} for $${activeDebitValue.toFixed(2)}! Safe escrow locked immediately.`);
                      } else {
                        // Proposal requested change
                        const newProposalNotification = {
                          id: `noti-prop-${Date.now()}`,
                          names: `@${challengeWindowData.oppUser}`,
                          action: `requested custom market changes for ${challengeWindowData.matchName}`,
                          time: "Just now",
                          read: false,
                          category: "new",
                          type: "mention",
                          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(challengeWindowData.oppUser)}&background=ffc107`,
                          isProposal: true,
                          oppUser: challengeWindowData.oppUser,
                          proposalMatchName: challengeWindowData.matchName,
                          proposalOldMarket: challengeWindowData.prediction,
                          proposalNewMarket: requestedMarketInput,
                          proposalStake: activeDebitValue,
                          proposalStatus: "pending" as const,
                        };
                        setNotificationList([newProposalNotification, ...notificationList]);
                        alert(`Counter proposal registered for "${requestedMarketInput}". Opponent will be notified immediately. No funds debited yet!`);
                      }
                      setChallengeWindowOpen(false);
                    }}
                    className="py-1.5 px-4 bg-[#31a24c] hover:bg-[#2b8f41] text-white font-extrabold text-xs rounded-lg shadow-xs cursor-pointer"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setChallengeWindowOpen(false)}
                    className="py-1.5 px-3 bg-gray-200 hover:bg-gray-300 dark:bg-zinc-850 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-200 font-extrabold text-xs rounded-lg shadow-xs cursor-pointer"
                  >
                    No
                  </button>
                  <button
                    onClick={() => setChallengeWindowOpen(false)}
                    className="py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-lg shadow-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      <WalletModal
        isOpen={walletModalOpen}
        onClose={() => setWalletModalOpen(false)}
        walletBalance={walletBalance}
        onDeposit={(amt) => {
          setWalletBalance((prev) => prev + amt);
          setTransactions([
            { id: `tx-${Date.now()}`, type: "deposit", amount: amt, time: "Just now", target: "Simulated MPESA deposit" },
            ...transactions
          ]);
        }}
        onWithdraw={(amt) => {
          setWalletBalance((prev) => prev - amt);
          setTransactions([
            { id: `tx-${Date.now()}`, type: "withdraw", amount: amt, time: "Just now", target: "Simulated MPESA withdrawal" },
            ...transactions
          ]);
        }}
        transactions={transactions}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthSuccess={(phoneNumber, email, provider) => {
          setCurrentUser({ phoneNumber, email, provider });
          setAuthModalOpen(false);
        }}
      />

      {/* CREATE NEW SPORTS SYNDICATE GROUP MODAL */}
      {createGroupModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[130] p-4 font-sans animate-in fade-in duration-150">
          <div className="bg-white dark:bg-[#242526] border border-gray-200 dark:border-zinc-800 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Header */}
            <div className="p-5 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-gray-50 dark:bg-[#1c1d1e]">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-500/10 text-blue-600 rounded-xl">
                  <Plus className="w-5 h-5 text-[#1877f2]" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-gray-900 dark:text-white leading-tight">
                    Create Sports Syndicate Group
                  </h3>
                  <p className="text-xs text-gray-400">Launch a private betting clan matching pool</p>
                </div>
              </div>
              <button 
                onClick={() => setCreateGroupModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-150 dark:hover:bg-zinc-800 rounded-full transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content Form */}
            <div className="p-6 overflow-y-auto space-y-4 text-left">
              
              {/* Group Name input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase text-gray-405 dark:text-gray-400 tracking-wider">
                  Syndicate Name *
                </label>
                <input 
                  type="text"
                  placeholder="e.g., El Classico High Rollers, Nairobi Bets Syndicate..."
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-[#18191a] text-sm rounded-xl px-4 py-3 border border-gray-200 dark:border-zinc-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Group Category selection */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase text-gray-450 dark:text-gray-400 tracking-wider">
                  Category
                </label>
                <select 
                  value={newGroupCategory}
                  onChange={(e) => setNewGroupCategory(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-[#18191a] text-sm rounded-xl px-4 py-3 border border-gray-200 dark:border-zinc-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 outline-none focus:ring-2 focus:ring-[#1877f2] cursor-pointer"
                >
                  <option value="Local leagues">⚽ Local Leagues</option>
                  <option value="VIP syndicates">💎 VIP Syndicates</option>
                  <option value="Zero margins">🔥 Zero Margins</option>
                  <option value="High stakers">⚡ High Stakers</option>
                </select>
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase text-gray-450 dark:text-gray-400 tracking-wider">
                  Clan Description
                </label>
                <textarea 
                  rows={2}
                  placeholder="Tell potential matchers about your sports specialities, rules, or target margins..."
                  value={newGroupDescription}
                  onChange={(e) => setNewGroupDescription(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-[#18191a] text-sm rounded-xl px-4 py-3 border border-gray-200 dark:border-zinc-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              {/* Preset Image Selectors */}
              <div className="space-y-3">
                
                {/* Cover presets */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <label className="font-bold text-gray-500 dark:text-gray-450 uppercase text-[10px] tracking-wider">Cover Image URL</label>
                    <span className="text-[10px] text-gray-400 font-medium">Click quick presets (optional)</span>
                  </div>
                  <input
                    type="text"
                    placeholder="Custom cover address..."
                    value={newGroupCoverImage}
                    onChange={(e) => setNewGroupCoverImage(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-[#18191a] text-xs font-mono rounded-xl px-4 py-2.5 border border-gray-205 dark:border-zinc-850 text-gray-900 dark:text-gray-105 outline-none focus:ring-1 focus:ring-[#1877f2]"
                  />
                  <div className="grid grid-cols-3 gap-1.5 mt-1.5">
                    <button 
                      type="button"
                      onClick={() => setNewGroupCoverImage("https://images.unsplash.com/photo-1540747737956-37872404a82f?q=80&w=600")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupCoverImage.includes("1540747737956") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      ⚽ Stadium Lights
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewGroupCoverImage("https://images.unsplash.com/photo-1518063319789-7217e6706b04?q=80&w=600")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupCoverImage.includes("1518063319789") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      🏃 Turf Field
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewGroupCoverImage("https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=600")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupCoverImage.includes("1508098682722") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      🏐 Sporting Ball
                    </button>
                  </div>
                </div>

                {/* Avatar presets */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <label className="font-bold text-gray-500 dark:text-gray-450 uppercase text-[10px] tracking-wider">Avatar / Logo Icon</label>
                    <span className="text-[10px] text-gray-400 font-medium">Click quick presets (optional)</span>
                  </div>
                  <input
                    type="text"
                    placeholder="Custom logo address..."
                    value={newGroupAvatar}
                    onChange={(e) => setNewGroupAvatar(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-[#18191a] text-xs font-mono rounded-xl px-4 py-2.5 border border-gray-205 dark:border-zinc-850 text-gray-900 dark:text-gray-105 outline-none focus:ring-1 focus:ring-[#1877f2]"
                  />
                  <div className="grid grid-cols-3 gap-1.5 mt-1.5">
                    <button 
                      type="button"
                      onClick={() => setNewGroupAvatar("https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=150")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupAvatar.includes("1517649763962") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      ⚽ Classic Match
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewGroupAvatar("https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=150")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupAvatar.includes("1461896836934") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      🏃 Trophy Race
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewGroupAvatar("https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=150")}
                      className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer ${
                        newGroupAvatar.includes("1546182990") ? "bg-[#1877f2]/10 border-[#1877f2] text-[#1877f2]" : "bg-gray-50 dark:bg-[#1c1d1e] border-gray-200 dark:border-zinc-800 hover:bg-gray-100 text-gray-500 dark:text-gray-400"
                      }`}
                    >
                      🦁 Mascot Shield
                    </button>
                  </div>
                </div>

              </div>

            </div>

            {/* Footer Buttons */}
            <div className="p-4 bg-gray-50 dark:bg-[#1c1d1e] border-t border-gray-100 dark:border-zinc-800 flex justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setCreateGroupModalOpen(false)}
                className="px-4 py-2.5 bg-gray-250 hover:bg-gray-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-850 dark:text-gray-200 text-xs font-black rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCreateGroupSubmit}
                disabled={!newGroupName.trim()}
                className={`px-5 py-2.5 text-xs font-black rounded-xl transition-all shadow flex items-center gap-1.5 cursor-pointer ${
                  newGroupName.trim() 
                    ? "bg-[#1877f2] hover:bg-blue-600 text-white transform hover:scale-[1.02]" 
                    : "bg-gray-150 dark:bg-zinc-850 text-gray-400 dark:text-gray-600 cursor-not-allowed"
                }`}
              >
                <span>🚀 Launch Syndicate</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ⭐ AI FLOATING CHAT WIDGET */}
      <div className="fixed bottom-6 right-6 z-[200] flex flex-col items-end">
        {nyotaChatOpen && (
          <div className="mb-4 w-80 sm:w-96 h-[500px] bg-white dark:bg-[#242526] rounded-2xl shadow-2xl flex flex-col border border-gray-200 dark:border-zinc-700 overflow-hidden animate-in fade-in slide-in-from-bottom-5">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-xl shadow-inner border border-white/30 backdrop-blur-sm">
                  <Star className="w-6 h-6 fill-white text-white" />
                </div>
                <div>
                  <h3 className="text-white font-black leading-tight flex items-center gap-1">⭐ AI</h3>
                  <p className="text-white/80 text-[10px] font-medium leading-none">Your intelligent betting sidekick</p>
                </div>
              </div>
              <button 
                onClick={() => setNyotaChatOpen(false)}
                className="text-white hover:bg-white/20 p-1.5 rounded-full transition-colors"
                title="Close AI Engine"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-[#18191a]">
              {nyotaMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white rounded-br-none shadow-sm' 
                      : 'bg-white dark:bg-[#3a3b3c] text-gray-800 dark:text-gray-100 rounded-bl-none shadow-sm border border-gray-100 dark:border-zinc-800'
                  }`}>
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                  </div>
                </div>
              ))}
              {nyotaLoading && (
                <div className="flex justify-start">
                  <div className="bg-white dark:bg-[#3a3b3c] w-12 h-8 rounded-2xl rounded-bl-none shadow border border-gray-100 dark:border-zinc-800 flex items-center justify-center gap-1">
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></span>
                  </div>
                </div>
              )}
            </div>

            {/* Input Area */}
            <form onSubmit={handleNyotaSubmit} className="p-3 bg-white dark:bg-[#242526] border-t border-gray-100 dark:border-zinc-800 shrink-0">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={nyotaInput}
                  onChange={(e) => setNyotaInput(e.target.value)}
                  placeholder="Ask ⭐ AI anything..."
                  disabled={nyotaLoading}
                  className="w-full bg-[#f0f2f5] dark:bg-[#3a3b3c] text-sm text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400 rounded-full pl-4 pr-12 py-2.5 outline-none focus:ring-2 focus:ring-blue-500/50"
                  autoFocus
                />
                <button 
                  type="submit"
                  disabled={!nyotaInput.trim() || nyotaLoading}
                  className="absolute right-1.5 p-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-full transition-colors"
                >
                  <Send className="w-4 h-4 ml-0.5 mt-0.5" />
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Floating Toggle Button */}
        <button
          onClick={() => setNyotaChatOpen(!nyotaChatOpen)}
          className={`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 z-[201] overflow-hidden relative group ${
            nyotaChatOpen 
              ? 'bg-gray-800 dark:bg-white text-white dark:text-gray-900 border-2 border-transparent' 
              : 'bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 text-white shadow-blue-500/30 ring-4 ring-white dark:ring-[#18191a]'
          }`}
        >
          {nyotaChatOpen ? (
            <X className="w-6 h-6 animate-in spin-in-12 duration-200" />
          ) : (
            <div className="relative">
              <Star className="w-7 h-7 fill-white text-white animate-pulse" />
            </div>
          )}
        </button>
      </div>

    </div>
  );
}
